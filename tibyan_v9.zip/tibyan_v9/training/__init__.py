#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Training Module
================================================================================
Complete Training System with Multiple Methods:
- GRPO++ (Group Relative Policy Optimization)
- GSPO (Group-based PPO)
- RLVR (Reinforcement Learning with Verifiable Rewards)
- Self-Rewarding Language Model
- Forward-Only Training (for mobile/CPU)
- QLoRA Training
- Federated Training
"""

from .grpo_plus import GRPOPlusTrainer, GRPOPlusConfig
from .gspo import GSPOTrainer, GSPOConfig
from .rlvr import RLVRTrainer, RLVRConfig
from .self_rewarding import SelfRewardingTrainer
from .forward_only import ForwardOnlyTrainer, EvolutionStrategyTrainer
from .qlora import QLoRATrainer
from .federated import FederatedTrainer
from .trainer import TibyanTrainer, TrainingConfig
from .losses import (
    CrossEntropyLoss,
    LabelSmoothingLoss,
    GRPOLoss,
    AuxiliaryLoss,
)

__all__ = [
    # Main trainers
    'TibyanTrainer',
    'TrainingConfig',
    
    # RL trainers
    'GRPOPlusTrainer',
    'GRPOPlusConfig',
    'GSPOTrainer',
    'GSPOConfig',
    'RLVRTrainer',
    'RLVRConfig',
    'SelfRewardingTrainer',
    
    # Efficient training
    'ForwardOnlyTrainer',
    'EvolutionStrategyTrainer',
    'QLoRATrainer',
    'FederatedTrainer',
    
    # Losses
    'CrossEntropyLoss',
    'LabelSmoothingLoss',
    'GRPOLoss',
    'AuxiliaryLoss',
]
