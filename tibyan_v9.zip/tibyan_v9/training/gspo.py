#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - GSPO Trainer
================================================================================

Group-based PPO (GSPO) Training

A variant of PPO that uses group-based comparison instead of
individual sample comparison.

Key innovations:
1. Group-level advantage estimation
2. Better sample efficiency
3. Reduced variance

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass


@dataclass
class GSPOConfig:
    """GSPO Configuration"""
    group_size: int = 4
    clip_ratio: float = 0.2
    value_coef: float = 0.5
    entropy_coef: float = 0.01
    gamma: float = 1.0
    gae_lambda: float = 0.95
    learning_rate: float = 1e-5
    batch_size: int = 8
    max_new_tokens: int = 256


class GSPOTrainer:
    """
    Group-based PPO Trainer
    
    Similar to GRPO++ but with standard PPO structure.
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: GSPOConfig,
        reward_function,
        value_model: Optional[nn.Module] = None,
        device: Optional[torch.device] = None
    ):
        self.model = model
        self.config = config
        self.reward_function = reward_function
        self.value_model = value_model
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        self.model = self.model.to(self.device)
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=config.learning_rate)
        
        self.global_step = 0
    
    def compute_gae(
        self,
        rewards: torch.Tensor,
        values: torch.Tensor,
        dones: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute Generalized Advantage Estimation"""
        advantages = []
        returns = []
        
        gae = 0
        for t in reversed(range(len(rewards))):
            if t == len(rewards) - 1:
                next_value = 0
            else:
                next_value = values[t + 1]
            
            delta = rewards[t] + self.config.gamma * next_value * (1 - dones[t]) - values[t]
            gae = delta + self.config.gamma * self.config.gae_lambda * (1 - dones[t]) * gae
            
            advantages.insert(0, gae)
            returns.insert(0, gae + values[t])
        
        return torch.stack(advantages), torch.stack(returns)
    
    def train_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """Single training step"""
        # Forward pass
        outputs = self.model(**batch)
        loss = outputs['loss'] if isinstance(outputs, dict) else outputs
        
        # Backward
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        self.optimizer.step()
        
        self.global_step += 1
        
        return {'loss': loss.item(), 'step': self.global_step}
    
    def train(self, train_dataset, **kwargs) -> Dict[str, Any]:
        """Main training loop"""
        from torch.utils.data import DataLoader
        
        dataloader = DataLoader(train_dataset, batch_size=self.config.batch_size, shuffle=True)
        
        total_loss = 0.0
        num_batches = 0
        
        for batch in dataloader:
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                    for k, v in batch.items()}
            
            metrics = self.train_step(batch)
            total_loss += metrics['loss']
            num_batches += 1
            
            if kwargs.get('max_steps', -1) > 0 and num_batches >= kwargs['max_steps']:
                break
        
        return {'total_loss': total_loss / num_batches, 'num_steps': num_batches}
