#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Federated Training
================================================================================

Federated Learning for Distributed Training

Enables training across multiple devices/servers without sharing data.

Key features:
- FedAvg aggregation
- FedProx optimization
- Privacy-preserving
- Heterogeneous device support

Use cases:
- Training on user devices (mobile)
- Multi-datacenter training
- Privacy-sensitive applications

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from typing import Optional, Dict, Any, List, Callable, Tuple
from dataclasses import dataclass
import copy
import logging
import random

logger = logging.getLogger(__name__)


@dataclass
class FederatedConfig:
    """Federated Learning Configuration"""
    # Client configuration
    num_clients: int = 10
    clients_per_round: int = 5
    local_epochs: int = 1
    local_batch_size: int = 8
    local_learning_rate: float = 1e-4
    
    # Aggregation
    aggregation_method: str = "fedavg"  # fedavg, fedprox, scaffold
    proximal_mu: float = 0.01  # For FedProx
    
    # Communication
    num_rounds: int = 100
    min_clients_per_round: int = 2
    
    # Privacy
    differential_privacy: bool = False
    dp_noise_scale: float = 0.01
    dp_clip_norm: float = 1.0


class FederatedClient:
    """
    Federated Learning Client
    
    Represents a single client (device/server) in federated learning.
    Each client trains locally on their private data.
    """
    
    def __init__(
        self,
        client_id: int,
        model: nn.Module,
        local_data: Dataset,
        config: FederatedConfig,
        device: Optional[torch.device] = None
    ):
        self.client_id = client_id
        self.model = copy.deepcopy(model)
        self.local_data = local_data
        self.config = config
        self.device = device or torch.device('cpu')
        
        self.model = self.model.to(self.device)
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=config.local_learning_rate
        )
        
        self.dataloader = DataLoader(
            local_data,
            batch_size=config.local_batch_size,
            shuffle=True
        )
    
    def train_local(
        self,
        global_model_state: Dict[str, torch.Tensor],
        num_epochs: Optional[int] = None
    ) -> Tuple[Dict[str, torch.Tensor], int, float]:
        """
        Train locally for specified epochs.
        
        Args:
            global_model_state: Global model state to start from
            num_epochs: Number of local epochs
            
        Returns:
            Tuple of (updated_state, num_samples, average_loss)
        """
        num_epochs = num_epochs or self.config.local_epochs
        
        # Load global model state
        self.model.load_state_dict(global_model_state)
        self.model.train()
        
        total_loss = 0.0
        num_batches = 0
        num_samples = len(self.local_data)
        
        for epoch in range(num_epochs):
            for batch in self.dataloader:
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                        for k, v in batch.items()}
                
                # Forward
                outputs = self.model(**batch)
                loss = outputs['loss'] if isinstance(outputs, dict) else outputs
                
                # FedProx: add proximal term
                if self.config.aggregation_method == "fedprox":
                    proximal_term = 0.0
                    for name, param in self.model.named_parameters():
                        global_param = global_model_state[name].to(self.device)
                        proximal_term += ((param - global_param) ** 2).sum()
                    loss = loss + (self.config.proximal_mu / 2) * proximal_term
                
                # Backward
                self.optimizer.zero_grad()
                loss.backward()
                
                # Gradient clipping for DP
                if self.config.differential_privacy:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config.dp_clip_norm
                    )
                
                self.optimizer.step()
                
                total_loss += loss.item()
                num_batches += 1
        
        # Get updated state
        updated_state = copy.deepcopy(self.model.state_dict())
        
        # Add DP noise
        if self.config.differential_privacy:
            for name in updated_state:
                noise = torch.randn_like(updated_state[name]) * self.config.dp_noise_scale
                updated_state[name] = updated_state[name] + noise
        
        avg_loss = total_loss / num_batches if num_batches > 0 else 0.0
        
        return updated_state, num_samples, avg_loss


class FederatedTrainer:
    """
    Federated Learning Trainer
    
    Coordinates training across multiple clients.
    
    Algorithm (FedAvg):
    1. Server distributes global model to clients
    2. Each client trains locally on private data
    3. Clients send model updates to server
    4. Server aggregates updates
    5. Repeat
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: FederatedConfig,
        client_datasets: List[Dataset],
        device: Optional[torch.device] = None
    ):
        """
        Initialize federated trainer.
        
        Args:
            model: Global model
            config: Federated configuration
            client_datasets: List of datasets for each client
            device: Device
        """
        self.model = model
        self.config = config
        self.client_datasets = client_datasets
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        self.model = self.model.to(self.device)
        
        # Create clients
        self.clients = [
            FederatedClient(
                client_id=i,
                model=model,
                local_data=dataset,
                config=config,
                device=device
            )
            for i, dataset in enumerate(client_datasets)
        ]
        
        # Training state
        self.current_round = 0
        self.global_model_state = copy.deepcopy(self.model.state_dict())
        self.client_losses = {}
    
    def select_clients(self) -> List[FederatedClient]:
        """Select clients for current round"""
        num_select = min(
            self.config.clients_per_round,
            len(self.clients)
        )
        return random.sample(self.clients, num_select)
    
    def aggregate_updates(
        self,
        client_updates: List[Tuple[Dict[str, torch.Tensor], int]]
    ) -> Dict[str, torch.Tensor]:
        """
        Aggregate client updates using FedAvg.
        
        Args:
            client_updates: List of (state_dict, num_samples) from clients
            
        Returns:
            Aggregated model state
        """
        if self.config.aggregation_method == "fedavg":
            return self._fedavg_aggregate(client_updates)
        elif self.config.aggregation_method == "fedprox":
            return self._fedavg_aggregate(client_updates)  # FedProx uses same aggregation
        else:
            return self._fedavg_aggregate(client_updates)
    
    def _fedavg_aggregate(
        self,
        client_updates: List[Tuple[Dict[str, torch.Tensor], int]]
    ) -> Dict[str, torch.Tensor]:
        """FedAvg aggregation: weighted average by sample count"""
        total_samples = sum(n for _, n in client_updates)
        
        aggregated_state = {}
        
        # Get parameter names from first client
        param_names = client_updates[0][0].keys()
        
        for name in param_names:
            weighted_sum = None
            
            for state, num_samples in client_updates:
                weight = num_samples / total_samples
                param = state[name].to(self.device)
                
                if weighted_sum is None:
                    weighted_sum = weight * param
                else:
                    weighted_sum = weighted_sum + weight * param
            
            aggregated_state[name] = weighted_sum
        
        return aggregated_state
    
    def train_round(self) -> Dict[str, Any]:
        """
        Execute one federated round.
        
        Returns:
            Round metrics
        """
        # Select clients
        selected_clients = self.select_clients()
        
        logger.info(f"Round {self.current_round}: {len(selected_clients)} clients selected")
        
        # Train on each client
        client_updates = []
        round_losses = []
        
        for client in selected_clients:
            state, num_samples, avg_loss = client.train_local(
                self.global_model_state
            )
            client_updates.append((state, num_samples))
            round_losses.append(avg_loss)
            
            self.client_losses[client.client_id] = avg_loss
        
        # Aggregate updates
        self.global_model_state = self.aggregate_updates(client_updates)
        
        # Update global model
        self.model.load_state_dict(self.global_model_state)
        
        self.current_round += 1
        
        return {
            'round': self.current_round,
            'num_clients': len(selected_clients),
            'avg_loss': sum(round_losses) / len(round_losses),
            'client_losses': self.client_losses.copy()
        }
    
    def train(
        self,
        num_rounds: Optional[int] = None,
        eval_function: Optional[Callable] = None,
        eval_frequency: int = 10
    ) -> Dict[str, Any]:
        """
        Main federated training loop.
        
        Args:
            num_rounds: Number of rounds (uses config if None)
            eval_function: Function to evaluate global model
            eval_frequency: Evaluate every N rounds
            
        Returns:
            Training metrics
        """
        num_rounds = num_rounds or self.config.num_rounds
        
        all_metrics = []
        
        for round_idx in range(num_rounds):
            metrics = self.train_round()
            all_metrics.append(metrics)
            
            # Evaluation
            if eval_function and round_idx % eval_frequency == 0:
                eval_metrics = eval_function(self.model)
                metrics['eval'] = eval_metrics
                logger.info(f"Round {round_idx} - Eval: {eval_metrics}")
        
        return {
            'num_rounds': num_rounds,
            'final_loss': all_metrics[-1]['avg_loss'],
            'all_metrics': all_metrics
        }
    
    def get_global_model(self) -> nn.Module:
        """Get the current global model"""
        self.model.load_state_dict(self.global_model_state)
        return self.model


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def create_iid_partition(
    dataset: Dataset,
    num_clients: int
) -> List[Dataset]:
    """
    Partition dataset IID across clients.
    
    Each client gets roughly the same distribution.
    """
    from torch.utils.data import Subset
    
    total_size = len(dataset)
    indices = list(range(total_size))
    random.shuffle(indices)
    
    partition_size = total_size // num_clients
    
    partitions = []
    for i in range(num_clients):
        start_idx = i * partition_size
        if i == num_clients - 1:
            end_idx = total_size
        else:
            end_idx = start_idx + partition_size
        
        partitions.append(Subset(dataset, indices[start_idx:end_idx]))
    
    return partitions


def create_non_iid_partition(
    dataset: Dataset,
    num_clients: int,
    num_classes_per_client: int = 2
) -> List[Dataset]:
    """
    Partition dataset non-IID across clients.
    
    Each client gets data from only certain classes.
    This simulates real-world data heterogeneity.
    """
    from torch.utils.data import Subset
    
    # Group by class
    class_indices = {}
    
    for idx, (_, label) in enumerate(dataset):
        if hasattr(dataset, 'targets'):
            label = dataset.targets[idx]
        
        if label not in class_indices:
            class_indices[label] = []
        class_indices[label].append(idx)
    
    # Assign classes to clients
    all_classes = list(class_indices.keys())
    random.shuffle(all_classes)
    
    partitions = []
    classes_per_client = []
    
    for i in range(num_clients):
        start = (i * num_classes_per_client) % len(all_classes)
        end = start + num_classes_per_client
        client_classes = all_classes[start:end]
        classes_per_client.append(client_classes)
        
        client_indices = []
        for cls in client_classes:
            client_indices.extend(class_indices.get(cls, []))
        
        partitions.append(Subset(dataset, client_indices))
    
    return partitions


def estimate_communication_cost(
    model_params: int,
    num_rounds: int,
    clients_per_round: int,
    precision_bytes: int = 4
) -> Dict[str, float]:
    """
    Estimate communication cost for federated training.
    
    Args:
        model_params: Number of model parameters
        num_rounds: Number of training rounds
        clients_per_round: Clients participating per round
        precision_bytes: Bytes per parameter
        
    Returns:
        Communication cost estimates
    """
    # Model size in bytes
    model_size_bytes = model_params * precision_bytes
    
    # Per round: upload + download for each client
    bytes_per_round = model_size_bytes * 2 * clients_per_round
    
    # Total
    total_bytes = bytes_per_round * num_rounds
    
    return {
        'model_size_mb': model_size_bytes / 1e6,
        'bytes_per_round_mb': bytes_per_round / 1e6,
        'total_gb': total_bytes / 1e9,
        'total_rounds': num_rounds
    }
