#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - RLVR Trainer
================================================================================

Reinforcement Learning with Verifiable Rewards (RLVR)

Key innovation: Use verifiable/programmable rewards instead of
learned reward models. Better for tasks with clear success criteria.

Examples of verifiable rewards:
- Code execution: Does the code run? Does it pass tests?
- Math: Is the answer correct?
- Translation: Does it match reference?

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Callable, Tuple
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class RLVRConfig:
    """RLVR Configuration"""
    verification_steps: int = 3
    reward_scale: float = 1.0
    penalty_scale: float = 0.5
    learning_rate: float = 1e-5
    batch_size: int = 8
    max_new_tokens: int = 256
    group_size: int = 4
    use_soft_verification: bool = True


class RLVRTrainer:
    """
    Reinforcement Learning with Verifiable Rewards
    
    The key idea: Use deterministic, verifiable rewards instead of
    learned reward models. This avoids reward hacking and provides
    cleaner training signals.
    
    Verifiable reward examples:
    1. Code: Execute and check output
    2. Math: Check if answer equals correct answer
    3. Format: Check if output matches required format
    4. Safety: Check for harmful content
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: RLVRConfig,
        verifiers: List[Callable],
        tokenizer: Optional[Any] = None,
        device: Optional[torch.device] = None
    ):
        """
        Initialize RLVR trainer.
        
        Args:
            model: Model to train
            config: RLVR configuration
            verifiers: List of verification functions
            tokenizer: Tokenizer for decoding
            device: Device
        """
        self.model = model
        self.config = config
        self.verifiers = verifiers
        self.tokenizer = tokenizer
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        self.model = self.model.to(self.device)
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=config.learning_rate)
        
        self.global_step = 0
    
    def verify_output(
        self,
        output: str,
        prompt: str,
        verification_type: str = "all"
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Verify output using all verifiers.
        
        Args:
            output: Generated output
            prompt: Original prompt
            verification_type: Which verifiers to use
            
        Returns:
            Tuple of (reward, verification_details)
        """
        total_reward = 0.0
        details = {}
        
        for i, verifier in enumerate(self.verifiers):
            try:
                result = verifier(output, prompt)
                
                if isinstance(result, tuple):
                    reward, info = result
                else:
                    reward = float(result)
                    info = {}
                
                total_reward += reward * self.config.reward_scale
                details[f'verifier_{i}'] = {'reward': reward, 'info': info}
                
            except Exception as e:
                logger.warning(f"Verifier {i} failed: {e}")
                details[f'verifier_{i}'] = {'error': str(e)}
        
        return total_reward, details
    
    def compute_verifiable_rewards(
        self,
        outputs: List[str],
        prompts: List[str]
    ) -> torch.Tensor:
        """
        Compute verifiable rewards for all outputs.
        
        Args:
            outputs: Generated outputs
            prompts: Original prompts
            
        Returns:
            Reward tensor
        """
        rewards = []
        
        for output, prompt in zip(outputs, prompts):
            reward, _ = self.verify_output(output, prompt)
            rewards.append(reward)
        
        return torch.tensor(rewards, device=self.device)
    
    def train_step(
        self,
        batch: Dict[str, torch.Tensor]
    ) -> Dict[str, float]:
        """Training step with verifiable rewards"""
        # Generate outputs
        with torch.no_grad():
            generated = self.model.generate(
                batch['input_ids'],
                max_new_tokens=self.config.max_new_tokens,
                do_sample=True
            )
        
        # Decode for verification
        if self.tokenizer:
            outputs = self.tokenizer.batch_decode(generated, skip_special_tokens=True)
            prompts = self.tokenizer.batch_decode(batch['input_ids'], skip_special_tokens=True)
        else:
            outputs = [''] * len(generated)
            prompts = [''] * len(batch['input_ids'])
        
        # Compute verifiable rewards
        rewards = self.compute_verifiable_rewards(outputs, prompts)
        
        # Compute loss (policy gradient with verifiable rewards)
        outputs_dict = self.model(**batch)
        logits = outputs_dict['logits']
        
        # Simple policy gradient loss
        log_probs = F.log_softmax(logits, dim=-1)
        
        # Get log probs of generated tokens
        if generated.shape[1] > batch['input_ids'].shape[1]:
            gen_log_probs = log_probs[:, :generated.shape[1] - batch['input_ids'].shape[1], :]
            # Expand rewards for sequence
            expanded_rewards = rewards.unsqueeze(1).expand(-1, gen_log_probs.shape[1])
            
            # Policy gradient loss
            loss = -(log_probs.mean(dim=-1) * expanded_rewards).mean()
        else:
            loss = outputs_dict['loss'] if 'loss' in outputs_dict else torch.tensor(0.0, device=self.device)
        
        # Backward
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        self.optimizer.step()
        
        self.global_step += 1
        
        return {
            'loss': loss.item(),
            'mean_reward': rewards.mean().item(),
            'step': self.global_step
        }
    
    def train(
        self,
        train_dataset,
        num_epochs: int = 1,
        max_steps: int = -1,
        **kwargs
    ) -> Dict[str, Any]:
        """Main training loop"""
        from torch.utils.data import DataLoader
        
        dataloader = DataLoader(
            train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True
        )
        
        total_loss = 0.0
        total_reward = 0.0
        num_batches = 0
        
        for epoch in range(num_epochs):
            for batch in dataloader:
                batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                        for k, v in batch.items()}
                
                metrics = self.train_step(batch)
                total_loss += metrics['loss']
                total_reward += metrics['mean_reward']
                num_batches += 1
                
                if max_steps > 0 and num_batches >= max_steps:
                    break
            
            if max_steps > 0 and num_batches >= max_steps:
                break
        
        return {
            'total_loss': total_loss / num_batches,
            'mean_reward': total_reward / num_batches,
            'num_steps': num_batches
        }


# =============================================================================
# BUILT-IN VERIFIERS
# =============================================================================

def create_code_verifier(test_cases: List[Dict]) -> Callable:
    """
    Create a code verification function.
    
    Args:
        test_cases: List of test cases with 'input' and 'expected_output'
        
    Returns:
        Verification function
    """
    def verify(output: str, prompt: str) -> Tuple[float, Dict]:
        # Extract code from output
        try:
            # Execute code and check test cases
            # This is simplified - in production, use sandboxed execution
            passed = 0
            total = len(test_cases)
            
            for test in test_cases:
                # Would execute code and compare output
                passed += 1  # Placeholder
            
            reward = passed / total if total > 0 else 0.0
            return reward, {'passed': passed, 'total': total}
            
        except Exception as e:
            return 0.0, {'error': str(e)}
    
    return verify


def create_math_verifier(answers: List[str]) -> Callable:
    """
    Create a math verification function.
    
    Args:
        answers: Expected answers for each problem
        
    Returns:
        Verification function
    """
    def verify(output: str, prompt: str) -> float:
        # Extract final answer from output
        # Check if it matches expected
        for answer in answers:
            if answer in output:
                return 1.0
        return 0.0
    
    return verify


def create_format_verifier(format_pattern: str) -> Callable:
    """
    Create a format verification function.
    
    Args:
        format_pattern: Regex pattern for valid format
        
    Returns:
        Verification function
    """
    import re
    pattern = re.compile(format_pattern)
    
    def verify(output: str, prompt: str) -> float:
        if pattern.match(output):
            return 1.0
        return 0.0
    
    return verify
