#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Loss Functions
================================================================================

Complete collection of loss functions for training:
- Cross Entropy with label smoothing
- GRPO Loss
- Auxiliary losses (MoE, KL, etc.)
- Contrastive losses
- Distillation losses

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple
import math


class CrossEntropyLoss(nn.Module):
    """
    Cross Entropy Loss with optional label smoothing.
    """
    
    def __init__(
        self,
        label_smoothing: float = 0.0,
        ignore_index: int = -100,
        reduction: str = 'mean'
    ):
        super().__init__()
        
        self.label_smoothing = label_smoothing
        self.ignore_index = ignore_index
        self.reduction = reduction
    
    def forward(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute cross entropy loss.
        
        Args:
            logits: Model outputs [batch, seq_len, vocab_size]
            labels: Target labels [batch, seq_len]
            
        Returns:
            Loss value
        """
        vocab_size = logits.size(-1)
        
        # Flatten
        logits = logits.view(-1, vocab_size)
        labels = labels.view(-1)
        
        # Create mask for ignored indices
        mask = labels != self.ignore_index
        
        if self.label_smoothing > 0:
            # Label smoothing
            nll_loss = F.cross_entropy(
                logits[mask],
                labels[mask],
                reduction='none'
            )
            
            smooth_loss = -F.log_softmax(logits[mask], dim=-1).mean(dim=-1)
            
            loss = (1 - self.label_smoothing) * nll_loss + self.label_smoothing * smooth_loss
        else:
            loss = F.cross_entropy(
                logits[mask],
                labels[mask],
                reduction='none'
            )
        
        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        return loss


class LabelSmoothingLoss(nn.Module):
    """
    Dedicated Label Smoothing Loss.
    """
    
    def __init__(
        self,
        vocab_size: int,
        smoothing: float = 0.1,
        ignore_index: int = -100
    ):
        super().__init__()
        
        self.vocab_size = vocab_size
        self.smoothing = smoothing
        self.ignore_index = ignore_index
        
        self.confidence = 1.0 - smoothing
    
    def forward(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """Compute label smoothed loss"""
        logits = logits.view(-1, self.vocab_size)
        labels = labels.view(-1)
        
        mask = labels != self.ignore_index
        
        # Create smoothed targets
        smooth_targets = torch.zeros_like(logits)
        smooth_targets.fill_(self.smoothing / (self.vocab_size - 1))
        smooth_targets[mask, labels[mask]] = self.confidence
        
        # KL divergence loss
        loss = F.kl_div(
            F.log_softmax(logits[mask], dim=-1),
            smooth_targets[mask],
            reduction='batchmean'
        )
        
        return loss


class GRPOLoss(nn.Module):
    """
    GRPO Loss: Group Relative Policy Optimization Loss
    
    Computes the policy gradient loss with group-level advantages.
    """
    
    def __init__(
        self,
        clip_range: float = 0.2,
        kl_coef: float = 0.1,
        entropy_coef: float = 0.01
    ):
        super().__init__()
        
        self.clip_range = clip_range
        self.kl_coef = kl_coef
        self.entropy_coef = entropy_coef
    
    def forward(
        self,
        log_probs_new: torch.Tensor,
        log_probs_old: torch.Tensor,
        advantages: torch.Tensor,
        ref_log_probs: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Compute GRPO loss.
        
        Args:
            log_probs_new: Current policy log probs
            log_probs_old: Old policy log probs
            advantages: Computed advantages
            ref_log_probs: Reference model log probs (for KL)
            
        Returns:
            Dictionary with losses
        """
        # Probability ratio
        log_ratio = log_probs_new - log_probs_old
        ratio = torch.exp(log_ratio)
        
        # Clipped surrogate objective
        surr1 = ratio * advantages
        surr2 = torch.clamp(
            ratio,
            1 - self.clip_range,
            1 + self.clip_range
        ) * advantages
        
        policy_loss = -torch.min(surr1, surr2).mean()
        
        # KL divergence
        kl_loss = torch.tensor(0.0, device=log_probs_new.device)
        if ref_log_probs is not None:
            kl_loss = (ref_log_probs - log_probs_new).mean()
        
        # Entropy bonus
        entropy = -log_probs_new.mean()
        
        # Total loss
        total_loss = (
            policy_loss +
            self.kl_coef * kl_loss -
            self.entropy_coef * entropy
        )
        
        return {
            'total_loss': total_loss,
            'policy_loss': policy_loss,
            'kl_loss': kl_loss,
            'entropy': entropy,
            'approx_kl': ((ratio - 1) - torch.log(ratio)).mean()
        }


class AuxiliaryLoss(nn.Module):
    """
    Collection of auxiliary losses for TIBYAN v9.0
    """
    
    def __init__(
        self,
        moe_loss_coef: float = 0.01,
        z_loss_coef: float = 1e-4
    ):
        super().__init__()
        
        self.moe_loss_coef = moe_loss_coef
        self.z_loss_coef = z_loss_coef
    
    def compute_moe_load_balance_loss(
        self,
        router_probs: torch.Tensor,
        expert_indices: torch.Tensor,
        num_experts: int
    ) -> torch.Tensor:
        """
        Compute MoE load balancing loss.
        
        Encourages even distribution of tokens across experts.
        """
        # Fraction of tokens per expert
        expert_mask = F.one_hot(expert_indices, num_experts).float()
        expert_fraction = expert_mask.mean(dim=0)
        
        # Average router probability per expert
        router_fraction = router_probs.mean(dim=0)
        
        # Load balance loss
        loss = num_experts * torch.sum(expert_fraction * router_fraction)
        
        return loss
    
    def compute_z_loss(
        self,
        logits: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute Z-loss to prevent logits from becoming too large.
        
        This stabilizes training by penalizing large logit values.
        """
        z_squared = logits ** 2
        return z_squared.mean()
    
    def forward(
        self,
        logits: torch.Tensor,
        router_probs: Optional[torch.Tensor] = None,
        expert_indices: Optional[torch.Tensor] = None,
        num_experts: Optional[int] = None
    ) -> Dict[str, torch.Tensor]:
        """Compute all auxiliary losses"""
        losses = {}
        total = torch.tensor(0.0, device=logits.device)
        
        # Z-loss
        z_loss = self.compute_z_loss(logits)
        losses['z_loss'] = z_loss
        total = total + self.z_loss_coef * z_loss
        
        # MoE load balance loss
        if router_probs is not None and expert_indices is not None and num_experts is not None:
            moe_loss = self.compute_moe_load_balance_loss(
                router_probs, expert_indices, num_experts
            )
            losses['moe_loss'] = moe_loss
            total = total + self.moe_loss_coef * moe_loss
        
        losses['total_aux_loss'] = total
        
        return losses


class DistillationLoss(nn.Module):
    """
    Knowledge Distillation Loss
    
    Transfers knowledge from teacher to student model.
    """
    
    def __init__(
        self,
        temperature: float = 2.0,
        alpha: float = 0.5
    ):
        super().__init__()
        
        self.temperature = temperature
        self.alpha = alpha
    
    def forward(
        self,
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        labels: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        Compute distillation loss.
        
        Args:
            student_logits: Student model logits
            teacher_logits: Teacher model logits
            labels: Ground truth labels
            
        Returns:
            Dictionary with losses
        """
        # Hard target loss
        hard_loss = F.cross_entropy(
            student_logits.view(-1, student_logits.size(-1)),
            labels.view(-1),
            ignore_index=-100
        )
        
        # Soft target loss (KL divergence)
        soft_loss = F.kl_div(
            F.log_softmax(student_logits / self.temperature, dim=-1),
            F.softmax(teacher_logits / self.temperature, dim=-1),
            reduction='batchmean'
        ) * (self.temperature ** 2)
        
        # Combined loss
        total_loss = self.alpha * soft_loss + (1 - self.alpha) * hard_loss
        
        return {
            'total_loss': total_loss,
            'hard_loss': hard_loss,
            'soft_loss': soft_loss
        }


class ContrastiveLoss(nn.Module):
    """
    Contrastive Loss for embedding learning.
    """
    
    def __init__(
        self,
        temperature: float = 0.07,
        margin: float = 1.0
    ):
        super().__init__()
        
        self.temperature = temperature
        self.margin = margin
    
    def forward(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute contrastive loss.
        
        Args:
            embeddings: Embedding vectors [batch, dim]
            labels: Labels for grouping [batch]
            
        Returns:
            Loss value
        """
        batch_size = embeddings.shape[0]
        
        # Normalize embeddings
        embeddings = F.normalize(embeddings, dim=1)
        
        # Compute similarity matrix
        similarity = torch.mm(embeddings, embeddings.t()) / self.temperature
        
        # Create label mask
        labels = labels.view(-1, 1)
        mask = (labels == labels.t()).float()
        
        # Remove diagonal
        mask = mask - torch.eye(batch_size, device=embeddings.device)
        
        # Contrastive loss
        exp_sim = torch.exp(similarity)
        log_prob = similarity - torch.log(exp_sim.sum(dim=1, keepdim=True))
        
        # Mean of positive pairs
        loss = -(mask * log_prob).sum(dim=1) / mask.sum(dim=1).clamp(min=1)
        
        return loss.mean()


class FocalLoss(nn.Module):
    """
    Focal Loss for handling class imbalance.
    """
    
    def __init__(
        self,
        alpha: float = 0.25,
        gamma: float = 2.0,
        reduction: str = 'mean'
    ):
        super().__init__()
        
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
    
    def forward(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """Compute focal loss"""
        ce_loss = F.cross_entropy(logits, labels, reduction='none')
        
        pt = torch.exp(-ce_loss)
        
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        return focal_loss
