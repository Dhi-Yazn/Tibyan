#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Quick Demo
================================================================================

Quick demonstration script for TIBYAN v9.0 capabilities.

Run:
    python demo.py

This script demonstrates:
1. Model creation and configuration
2. Text generation
3. Chat sessions
4. Safety features
5. Memory systems

================================================================================
"""

import sys
import time
from pathlib import Path

# Add parent to path if running as script
sys.path.insert(0, str(Path(__file__).parent.parent))


def print_section(title: str):
    """Print section header"""
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}\n")


def demo_basic_generation():
    """Demonstrate basic text generation"""
    print_section("📝 Basic Text Generation")
    
    try:
        from tibyan_v9.api import TibyanAPI, GenerationConfig
        
        api = TibyanAPI()
        
        prompts = [
            "مرحبا بك في عالم الذكاء الاصطناعي",
            "ما هي فوائد التعلم الآلي؟",
            "Hello, how are you today?"
        ]
        
        for prompt in prompts:
            print(f"🔹 Prompt: {prompt}")
            
            result = api.generate(prompt, max_new_tokens=50)
            
            print(f"   Response: {result.text[:100]}...")
            print(f"   Tokens: {result.num_tokens}, Time: {result.generation_time:.2f}s")
            print(f"   Speed: {result.tokens_per_second:.1f} tokens/s")
            print()
    
    except Exception as e:
        print(f"⚠️ Demo skipped: {e}")


def demo_generation_presets():
    """Demonstrate generation presets"""
    print_section("🎨 Generation Presets")
    
    try:
        from tibyan_v9.api import TibyanAPI, GenerationConfig, PresetMode
        
        api = TibyanAPI()
        prompt = "اشرح مفهوم الذكاء الاصطناعي"
        
        presets = ['creative', 'precise', 'balanced', 'arabic']
        
        for preset in presets:
            print(f"🔹 Preset: {preset}")
            
            result = api.generate(prompt, preset=preset, max_new_tokens=50)
            
            print(f"   Response: {result.text[:80]}...")
            print()
    
    except Exception as e:
        print(f"⚠️ Demo skipped: {e}")


def demo_chat_session():
    """Demonstrate chat session"""
    print_section("💬 Chat Session")
    
    try:
        from tibyan_v9.api import TibyanAPI, ChatSession
        
        api = TibyanAPI()
        session = ChatSession(api)
        
        messages = [
            "مرحبا، كيف حالك؟",
            "ما هو الذكاء الاصطناعي؟",
            "كيف يمكنني تعلم البرمجة؟"
        ]
        
        for msg in messages:
            print(f"👤 User: {msg}")
            
            response = session.send(msg, max_new_tokens=100)
            
            print(f"🤖 TIBYAN: {response[:150]}...")
            print()
        
        # Show history
        print("📜 Conversation History:")
        for m in session.get_history()[-6:]:
            print(f"   [{m['role']}]: {m['content'][:50]}...")
    
    except Exception as e:
        print(f"⚠️ Demo skipped: {e}")


def demo_safety_features():
    """Demonstrate safety features"""
    print_section("🛡️ Safety Features")
    
    try:
        from tibyan_v9.api import TibyanAPI
        
        api = TibyanAPI()
        
        # Generate with safety check
        result = api.generate(
            "ما هي عاصمة السعودية؟",
            check_hallucination=True
        )
        
        print(f"Response: {result.text[:100]}...")
        print(f"Safety Status: {'⚠️ Potential hallucination' if result.is_hallucination else '✅ Confident'}")
        print(f"Confidence: {result.confidence:.2f}" if result.confidence else "")
    
    except Exception as e:
        print(f"⚠️ Demo skipped: {e}")


def demo_streaming():
    """Demonstrate streaming generation"""
    print_section("🌊 Streaming Generation")
    
    try:
        from tibyan_v9.api import TibyanAPI, GenerationConfig
        
        api = TibyanAPI()
        
        prompt = "اكتب قصة قصيرة عن الطبيعة"
        
        print(f"🔹 Prompt: {prompt}")
        print("🔹 Streaming response: ", end="", flush=True)
        
        for token in api.generate_stream(prompt, max_new_tokens=50):
            print(token, end="", flush=True)
        
        print("\n")
    
    except Exception as e:
        print(f"⚠️ Demo skipped: {e}")


def demo_model_info():
    """Show model information"""
    print_section("📊 Model Information")
    
    try:
        import torch
        from tibyan_v9 import get_version_info, check_installation
        
        print("📦 TIBYAN v9.0 Info:")
        info = get_version_info()
        for key, value in info.items():
            print(f"   • {key}: {value}")
        
        print(f"\n🖥️ Hardware:")
        print(f"   • PyTorch: {torch.__version__}")
        print(f"   • CUDA: {'Available' if torch.cuda.is_available() else 'Not available'}")
        
        if torch.cuda.is_available():
            print(f"   • GPU: {torch.cuda.get_device_name(0)}")
        
        print(f"\n📚 Dependencies:")
        install = check_installation()
        for pkg, ok in install['required'].items():
            print(f"   • {pkg}: {'✅' if ok else '❌'}")
    
    except Exception as e:
        print(f"⚠️ Info skipped: {e}")


def demo_model_architecture():
    """Demonstrate model architecture"""
    print_section("🏗️ Model Architecture")
    
    try:
        from tibyan_v9 import create_small_tibyan_v9, TibyanV9ModelConfig
        
        print("Creating small TIBYAN v9.0 model...")
        
        config = TibyanV9ModelConfig(
            vocab_size=32000,
            hidden_dim=512,
            num_layers=8,
            num_heads=8
        )
        
        print(f"\n📋 Configuration:")
        print(f"   • Vocab size: {config.vocab_size}")
        print(f"   • Hidden dim: {config.hidden_dim}")
        print(f"   • Layers: {config.num_layers}")
        print(f"   • Heads: {config.num_heads}")
        
        model = create_small_tibyan_v9()
        
        # Count parameters
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        print(f"\n📊 Model Statistics:")
        print(f"   • Total parameters: {total_params:,}")
        print(f"   • Trainable parameters: {trainable_params:,}")
        print(f"   • Size: {total_params * 4 / 1024 / 1024:.1f} MB (FP32)")
        
        # Memory info
        if hasattr(model, 'get_memory_info'):
            print(f"\n🧠 Memory Systems:")
            memory_info = model.get_memory_info()
            for key, value in memory_info.items():
                print(f"   • {key}: {value}")
    
    except Exception as e:
        print(f"⚠️ Architecture demo skipped: {e}")


def demo_api_statistics():
    """Demonstrate API statistics"""
    print_section("📈 API Statistics")
    
    try:
        from tibyan_v9.api import TibyanAPI
        
        api = TibyanAPI()
        
        # Generate a few times
        for _ in range(3):
            api.generate("test", max_new_tokens=20)
        
        stats = api.get_stats()
        
        print("📊 Statistics:")
        for key, value in stats.items():
            if isinstance(value, float):
                print(f"   • {key}: {value:.2f}")
            else:
                print(f"   • {key}: {value}")
    
    except Exception as e:
        print(f"⚠️ Stats demo skipped: {e}")


def main():
    """Run all demos"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║    ████████╗██╗   ██╗██╗    ████████╗███████╗██╗   ██╗                      ║
║    ╚══██╔══╝██║   ██║██║    ╚══██╔══╝██╔════╝██║   ██║                      ║
║       ██║   ████████║██║       ██║   █████╗  ████████║                      ║
║       ██║   ██╔══██║██║       ██║   ██╔══╝  ╚════██║                      ║
║       ██║   ██║  ██║██║       ██║   ███████╗     ██║                      ║
║       ╚═╝   ╚═╝  ╚═╝╚═╝       ╚═╝   ╚══════╝     ╚═╝                      ║
║                                                                              ║
║              ███████╗ █████╗ ██████╗ ██╗                                     ║
║              ██╔════╝██╔══██╗██╔══██╗██║                                     ║
║              █████╗  ███████║██████╔╝██║                                     ║
║              ██╔══╝  ██╔══██║██╔══██╗██║                                     ║
║              ██║     ██║  ██║██║  ██║███████╗                                ║
║              ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝                                ║
║                                                                              ║
║                      v9.0 AGI Micro-Engine                                  ║
║                   Quick Demonstration                                       ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")
    
    # Run demos
    demo_model_info()
    demo_model_architecture()
    demo_basic_generation()
    demo_generation_presets()
    demo_chat_session()
    demo_safety_features()
    demo_streaming()
    demo_api_statistics()
    
    print_section("✅ Demo Complete!")
    print("""
Thank you for trying TIBYAN v9.0!

For more information:
    • Documentation: https://github.com/tibyan/tibyan-v9
    • API Reference: python -m tibyan_v9 --help
    • Examples: See the examples/ directory

Quick Start:
    from tibyan_v9 import TibyanAPI
    api = TibyanAPI()
    response = api.generate("مرحبا بك")
""")


if __name__ == "__main__":
    main()
