#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Batch Processing
================================================================================

Efficient batch processing with:
- Dynamic batching
- Memory optimization
- Parallel processing
- Progress tracking
- Result aggregation

NO SIMPLIFICATIONS - Full production code.

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple, Iterator, Callable
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
import logging
import time
import threading
from queue import Queue
from collections import defaultdict
import json

logger = logging.getLogger(__name__)


# =============================================================================
# BATCH CONFIGURATION
# =============================================================================

@dataclass
class BatchConfig:
    """Configuration for batch processing"""
    
    # Batch settings
    max_batch_size: int = 32
    max_sequence_length: int = 2048
    max_total_tokens: int = 100000
    
    # Dynamic batching
    use_dynamic_batching: bool = True
    batch_timeout_ms: int = 100
    min_batch_size: int = 1
    
    # Memory
    max_memory_gb: float = 8.0
    memory_buffer: float = 0.1  # 10% buffer
    
    # Parallelism
    num_workers: int = 4
    use_multiprocessing: bool = False
    
    # Progress
    show_progress: bool = True
    progress_callback: Optional[Callable[[int, int], None]] = None
    
    # Output
    save_intermediate: bool = False
    output_dir: Optional[str] = None
    
    # Error handling
    continue_on_error: bool = True
    max_retries: int = 3


@dataclass
class BatchResult:
    """Result of batch processing"""
    
    # Results
    inputs: List[str]
    outputs: List[str]
    
    # Metadata
    total_time: float
    batch_size: int
    num_batches: int
    
    # Statistics
    total_tokens: int
    tokens_per_second: float
    
    # Errors
    errors: List[Tuple[int, str]]  # (index, error_message)
    
    # Additional info
    batch_times: List[float]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'outputs': self.outputs,
            'total_time': self.total_time,
            'batch_size': self.batch_size,
            'num_batches': self.num_batches,
            'total_tokens': self.total_tokens,
            'tokens_per_second': self.tokens_per_second,
            'errors': self.errors
        }


# =============================================================================
# BATCH PROCESSOR
# =============================================================================

class BatchProcessor:
    """
    Efficient Batch Processor
    
    Features:
    - Dynamic batching
    - Memory-aware scheduling
    - Parallel processing
    - Progress tracking
    """
    
    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any = None,
        config: Optional[BatchConfig] = None,
        device: Optional[torch.device] = None
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or BatchConfig()
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Move model to device
        self.model.to(self.device)
        self.model.eval()
        
        # Statistics
        self._stats = {
            'total_batches': 0,
            'total_requests': 0,
            'total_tokens': 0,
            'total_time': 0.0,
            'errors': 0
        }
        
        # Lock for thread safety
        self._lock = threading.Lock()
    
    def process_batch(
        self,
        prompts: List[str],
        generation_config: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> BatchResult:
        """
        Process a batch of prompts.
        
        Args:
            prompts: List of input prompts
            generation_config: Generation configuration
            **kwargs: Additional generation parameters
            
        Returns:
            BatchResult with all outputs
        """
        start_time = time.time()
        
        generation_config = generation_config or {}
        outputs = []
        errors = []
        batch_times = []
        total_tokens = 0
        
        # Process in batches
        batch_size = kwargs.get('batch_size', self.config.max_batch_size)
        num_batches = (len(prompts) + batch_size - 1) // batch_size
        
        for batch_idx in range(num_batches):
            batch_start = time.time()
            
            # Get batch
            start = batch_idx * batch_size
            end = min(start + batch_size, len(prompts))
            batch_prompts = prompts[start:end]
            
            try:
                # Process batch
                batch_outputs, batch_tokens = self._process_single_batch(
                    batch_prompts,
                    generation_config,
                    **kwargs
                )
                
                outputs.extend(batch_outputs)
                total_tokens += batch_tokens
                
                # Progress callback
                if self.config.progress_callback:
                    self.config.progress_callback(end, len(prompts))
                
            except Exception as e:
                logger.error(f"Error processing batch {batch_idx}: {e}")
                
                if self.config.continue_on_error:
                    # Add empty outputs for failed batch
                    for i, prompt in enumerate(batch_prompts):
                        outputs.append("")
                        errors.append((start + i, str(e)))
                else:
                    raise
            
            batch_times.append(time.time() - batch_start)
        
        total_time = time.time() - start_time
        tokens_per_second = total_tokens / total_time if total_time > 0 else 0
        
        # Update stats
        with self._lock:
            self._stats['total_batches'] += num_batches
            self._stats['total_requests'] += len(prompts)
            self._stats['total_tokens'] += total_tokens
            self._stats['total_time'] += total_time
            self._stats['errors'] += len(errors)
        
        return BatchResult(
            inputs=prompts,
            outputs=outputs,
            total_time=total_time,
            batch_size=batch_size,
            num_batches=num_batches,
            total_tokens=total_tokens,
            tokens_per_second=tokens_per_second,
            errors=errors,
            batch_times=batch_times
        )
    
    def _process_single_batch(
        self,
        prompts: List[str],
        generation_config: Dict[str, Any],
        **kwargs
    ) -> Tuple[List[str], int]:
        """Process a single batch of prompts"""
        
        # Tokenize
        input_ids_list = [self._tokenize(p) for p in prompts]
        
        # Pad to same length
        max_len = max(ids.shape[1] for ids in input_ids_list)
        
        padded = torch.zeros(len(prompts), max_len, dtype=torch.long, device=self.device)
        attention_mask = torch.zeros(len(prompts), max_len, device=self.device)
        
        for i, ids in enumerate(input_ids_list):
            padded[i, :ids.shape[1]] = ids
            attention_mask[i, :ids.shape[1]] = 1
        
        # Generate
        outputs = []
        total_tokens = 0
        
        max_new_tokens = generation_config.get('max_new_tokens', 100)
        temperature = generation_config.get('temperature', 0.7)
        
        with torch.no_grad():
            # Process each prompt in batch
            for i, prompt in enumerate(prompts):
                single_input = padded[i:i+1, :input_ids_list[i].shape[1]]
                
                output, num_tokens = self._generate_single(
                    single_input,
                    max_new_tokens,
                    temperature
                )
                
                outputs.append(output)
                total_tokens += num_tokens
        
        return outputs, total_tokens
    
    def _generate_single(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int,
        temperature: float
    ) -> Tuple[str, int]:
        """Generate for a single input"""
        generated = input_ids.clone()
        
        for _ in range(max_new_tokens):
            outputs = self.model(generated)
            logits = outputs['logits'] if isinstance(outputs, dict) else outputs[0]
            
            next_token_logits = logits[:, -1, :] / temperature
            probs = F.softmax(next_token_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            
            generated = torch.cat([generated, next_token], dim=1)
            
            # Check EOS
            if hasattr(self.model, 'config') and hasattr(self.model.config, 'eos_token_id'):
                if next_token.item() == self.model.config.eos_token_id:
                    break
        
        # Decode
        output_text = self._detokenize(generated[0])
        num_tokens = generated.shape[1] - input_ids.shape[1]
        
        return output_text, num_tokens
    
    def process_parallel(
        self,
        prompts: List[str],
        generation_config: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> BatchResult:
        """
        Process prompts in parallel using multiple workers.
        
        Args:
            prompts: List of input prompts
            generation_config: Generation configuration
            **kwargs: Additional parameters
            
        Returns:
            BatchResult
        """
        start_time = time.time()
        
        generation_config = generation_config or {}
        num_workers = kwargs.get('num_workers', self.config.num_workers)
        
        # Split prompts among workers
        chunk_size = (len(prompts) + num_workers - 1) // num_workers
        chunks = [
            prompts[i:i+chunk_size]
            for i in range(0, len(prompts), chunk_size)
        ]
        
        outputs = [None] * len(prompts)
        errors = []
        total_tokens = 0
        
        # Process chunks in parallel
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = {}
            
            for chunk_idx, chunk in enumerate(chunks):
                future = executor.submit(
                    self._process_chunk,
                    chunk,
                    chunk_idx * chunk_size,
                    generation_config
                )
                futures[future] = chunk_idx
            
            for future in as_completed(futures):
                chunk_idx = futures[future]
                chunk_start = chunk_idx * chunk_size
                
                try:
                    chunk_outputs, chunk_tokens, chunk_errors = future.result()
                    
                    for i, output in enumerate(chunk_outputs):
                        outputs[chunk_start + i] = output
                    
                    total_tokens += chunk_tokens
                    errors.extend(chunk_errors)
                    
                except Exception as e:
                    logger.error(f"Error in worker {chunk_idx}: {e}")
                    for i in range(len(chunks[chunk_idx])):
                        errors.append((chunk_start + i, str(e)))
        
        total_time = time.time() - start_time
        tokens_per_second = total_tokens / total_time if total_time > 0 else 0
        
        # Fill in None outputs
        for i, output in enumerate(outputs):
            if output is None:
                outputs[i] = ""
        
        return BatchResult(
            inputs=prompts,
            outputs=outputs,
            total_time=total_time,
            batch_size=len(prompts),
            num_batches=len(chunks),
            total_tokens=total_tokens,
            tokens_per_second=tokens_per_second,
            errors=errors,
            batch_times=[]
        )
    
    def _process_chunk(
        self,
        prompts: List[str],
        start_idx: int,
        generation_config: Dict[str, Any]
    ) -> Tuple[List[str], int, List[Tuple[int, str]]]:
        """Process a chunk of prompts"""
        outputs = []
        errors = []
        total_tokens = 0
        
        for i, prompt in enumerate(prompts):
            try:
                input_ids = self._tokenize(prompt)
                
                max_new_tokens = generation_config.get('max_new_tokens', 100)
                temperature = generation_config.get('temperature', 0.7)
                
                output, num_tokens = self._generate_single(
                    input_ids, max_new_tokens, temperature
                )
                
                outputs.append(output)
                total_tokens += num_tokens
                
            except Exception as e:
                outputs.append("")
                errors.append((start_idx + i, str(e)))
        
        return outputs, total_tokens, errors
    
    def process_streaming(
        self,
        prompts: List[str],
        callback: Callable[[int, str], None],
        generation_config: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> BatchResult:
        """
        Process with streaming callback.
        
        Args:
            prompts: List of prompts
            callback: Called with (index, output) for each result
            generation_config: Generation config
            **kwargs: Additional parameters
            
        Returns:
            BatchResult
        """
        result = self.process_batch(prompts, generation_config, **kwargs)
        
        # Call callback for each result
        for i, output in enumerate(result.outputs):
            callback(i, output)
        
        return result
    
    def _tokenize(self, text: str) -> torch.Tensor:
        """Tokenize text"""
        if self.tokenizer is not None:
            return self.tokenizer.encode(text, return_tensors='pt').to(self.device)
        
        tokens = [ord(c) % 64000 for c in text]
        return torch.tensor([tokens], device=self.device)
    
    def _detokenize(self, tokens: torch.Tensor) -> str:
        """Detokenize to text"""
        if isinstance(tokens, torch.Tensor):
            tokens = tokens.tolist()
        
        if self.tokenizer is not None:
            return self.tokenizer.decode(tokens)
        
        return ''.join(chr(t % 65536) for t in tokens if t > 0)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get processing statistics"""
        stats = self._stats.copy()
        
        if stats['total_requests'] > 0:
            stats['avg_batch_size'] = stats['total_requests'] / max(stats['total_batches'], 1)
            stats['avg_tokens_per_request'] = stats['total_tokens'] / stats['total_requests']
        
        if stats['total_time'] > 0:
            stats['overall_tokens_per_second'] = stats['total_tokens'] / stats['total_time']
        
        return stats
    
    def reset_stats(self):
        """Reset statistics"""
        self._stats = {
            'total_batches': 0,
            'total_requests': 0,
            'total_tokens': 0,
            'total_time': 0.0,
            'errors': 0
        }


# =============================================================================
# DYNAMIC BATCHER
# =============================================================================

class DynamicBatcher:
    """
    Dynamic batching for real-time request handling.
    
    Groups incoming requests into batches for efficient processing.
    """
    
    def __init__(
        self,
        processor: BatchProcessor,
        max_batch_size: int = 32,
        timeout_ms: int = 100
    ):
        self.processor = processor
        self.max_batch_size = max_batch_size
        self.timeout_ms = timeout_ms
        
        # Queue for incoming requests
        self._queue: Queue = Queue()
        self._results: Dict[int, Any] = {}
        self._result_events: Dict[int, threading.Event] = {}
        
        # Worker thread
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None
        
        # Counter for request IDs
        self._request_counter = 0
        self._counter_lock = threading.Lock()
    
    def start(self):
        """Start the batcher"""
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker, daemon=True)
        self._worker_thread.start()
    
    def stop(self):
        """Stop the batcher"""
        self._running = False
        if self._worker_thread:
            self._worker_thread.join(timeout=5)
    
    def submit(self, prompt: str) -> int:
        """
        Submit a request.
        
        Args:
            prompt: Input prompt
            
        Returns:
            Request ID for retrieving result
        """
        with self._counter_lock:
            request_id = self._request_counter
            self._request_counter += 1
        
        self._result_events[request_id] = threading.Event()
        self._queue.put((request_id, prompt))
        
        return request_id
    
    def get_result(self, request_id: int, timeout: float = 30.0) -> Optional[str]:
        """
        Get result for a request.
        
        Args:
            request_id: Request ID from submit()
            timeout: Timeout in seconds
            
        Returns:
            Result string or None if timeout
        """
        if request_id not in self._result_events:
            return None
        
        event = self._result_events[request_id]
        
        if event.wait(timeout):
            result = self._results.pop(request_id, None)
            self._result_events.pop(request_id, None)
            return result
        
        return None
    
    def _worker(self):
        """Worker thread that processes batches"""
        batch = []
        batch_ids = []
        last_batch_time = time.time()
        
        while self._running:
            try:
                # Check timeout
                current_time = time.time()
                timeout_remaining = max(
                    0,
                    (self.timeout_ms / 1000) - (current_time - last_batch_time)
                )
                
                # Get next request
                try:
                    request_id, prompt = self._queue.get(timeout=timeout_remaining)
                    batch.append(prompt)
                    batch_ids.append(request_id)
                except:
                    pass  # Timeout, process what we have
                
                # Process batch if ready
                should_process = (
                    len(batch) >= self.max_batch_size or
                    (len(batch) > 0 and (current_time - last_batch_time) * 1000 >= self.timeout_ms)
                )
                
                if should_process:
                    self._process_batch(batch, batch_ids)
                    batch = []
                    batch_ids = []
                    last_batch_time = time.time()
            
            except Exception as e:
                logger.error(f"Error in batch worker: {e}")
        
        # Process remaining
        if batch:
            self._process_batch(batch, batch_ids)
    
    def _process_batch(self, prompts: List[str], request_ids: List[int]):
        """Process a batch of requests"""
        try:
            results = self.processor.process_batch(prompts)
            
            for request_id, output in zip(request_ids, results.outputs):
                self._results[request_id] = output
                self._result_events[request_id].set()
                
        except Exception as e:
            logger.error(f"Error processing batch: {e}")
            
            for request_id in request_ids:
                self._results[request_id] = None
                self._result_events[request_id].set()
