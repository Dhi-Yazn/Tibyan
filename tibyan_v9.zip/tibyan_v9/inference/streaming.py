#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Streaming Generator
================================================================================

Real-time streaming generation support with:
- Token-by-token streaming
- WebSocket support
- Server-Sent Events (SSE)
- Async generation
- Cancellation support

NO SIMPLIFICATIONS - Full production code.

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Callable, AsyncGenerator, Generator
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import logging
import time
import json
from queue import Queue
from threading import Thread, Event
import socket

logger = logging.getLogger(__name__)


# =============================================================================
# STREAMING CONFIGURATION
# =============================================================================

@dataclass
class StreamConfig:
    """Configuration for streaming generation"""
    
    # Generation
    max_new_tokens: int = 512
    temperature: float = 0.7
    top_k: int = 50
    top_p: float = 0.95
    
    # Streaming
    chunk_size: int = 1  # Tokens per chunk
    delay_ms: int = 0  # Artificial delay for smoother streaming
    
    # Timeout
    generation_timeout: float = 60.0
    idle_timeout: float = 300.0
    
    # Buffer
    buffer_size: int = 1000
    
    # Callbacks
    on_token: Optional[Callable[[str], None]] = None
    on_complete: Optional[Callable[[str], None]] = None
    on_error: Optional[Callable[[Exception], None]] = None


class StreamState(Enum):
    """Streaming state"""
    IDLE = "idle"
    GENERATING = "generating"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ERROR = "error"


# =============================================================================
# STREAMING GENERATOR
# =============================================================================

class StreamingGenerator:
    """
    Real-time Streaming Generator
    
    Supports:
    - Token-by-token streaming
    - Cancellation
    - Multiple output formats
    - WebSocket integration
    """
    
    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any = None,
        config: Optional[StreamConfig] = None,
        device: Optional[torch.device] = None
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or StreamConfig()
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # State
        self._state = StreamState.IDLE
        self._cancel_event = Event()
        self._output_buffer = ""
        
        # Queue for streaming
        self._queue: Queue = Queue(maxsize=self.config.buffer_size)
        
        # Statistics
        self._stats = {
            'total_streams': 0,
            'total_tokens': 0,
            'cancelled_streams': 0,
            'error_streams': 0
        }
    
    def generate_stream(
        self,
        prompt: str,
        **kwargs
    ) -> Generator[str, None, None]:
        """
        Synchronous streaming generation.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional generation parameters
            
        Yields:
            Generated tokens as strings
        """
        self._state = StreamState.GENERATING
        self._cancel_event.clear()
        self._output_buffer = ""
        self._stats['total_streams'] += 1
        
        try:
            # Tokenize
            input_ids = self._tokenize(prompt)
            generated = input_ids.clone()
            past_key_values = None
            
            token_count = 0
            
            with torch.no_grad():
                while token_count < self.config.max_new_tokens and not self._cancel_event.is_set():
                    # Forward pass
                    outputs = self.model(
                        input_ids=generated if past_key_values is None else generated[:, -1:],
                        past_key_values=past_key_values,
                        use_cache=True
                    )
                    
                    if isinstance(outputs, dict):
                        logits = outputs['logits']
                        past_key_values = outputs.get('past_key_values')
                    else:
                        logits = outputs[0]
                        past_key_values = outputs[1] if len(outputs) > 1 else None
                    
                    # Sample next token
                    next_token = self._sample_token(logits[:, -1, :])
                    
                    # Decode token
                    token_text = self._detokenize([next_token.item()])
                    
                    # Update state
                    generated = torch.cat([generated, next_token], dim=1)
                    self._output_buffer += token_text
                    token_count += 1
                    
                    # Yield token
                    yield token_text
                    
                    # Callback
                    if self.config.on_token:
                        self.config.on_token(token_text)
                    
                    # Check EOS
                    if hasattr(self.model, 'config') and hasattr(self.model.config, 'eos_token_id'):
                        if next_token.item() == self.model.config.eos_token_id:
                            break
                    
                    # Artificial delay for smoother streaming
                    if self.config.delay_ms > 0:
                        time.sleep(self.config.delay_ms / 1000)
            
            self._state = StreamState.COMPLETED
            self._stats['total_tokens'] += token_count
            
            # Callback
            if self.config.on_complete:
                self.config.on_complete(self._output_buffer)
            
        except Exception as e:
            self._state = StreamState.ERROR
            self._stats['error_streams'] += 1
            
            if self.config.on_error:
                self.config.on_error(e)
            
            raise
    
    async def generate_stream_async(
        self,
        prompt: str,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """
        Asynchronous streaming generation.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional generation parameters
            
        Yields:
            Generated tokens as strings
        """
        self._state = StreamState.GENERATING
        self._cancel_event.clear()
        self._output_buffer = ""
        self._stats['total_streams'] += 1
        
        try:
            # Tokenize
            input_ids = self._tokenize(prompt)
            generated = input_ids.clone()
            past_key_values = None
            
            token_count = 0
            
            with torch.no_grad():
                while token_count < self.config.max_new_tokens and not self._cancel_event.is_set():
                    # Run blocking operation in thread pool
                    outputs = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: self.model(
                            input_ids=generated if past_key_values is None else generated[:, -1:],
                            past_key_values=past_key_values,
                            use_cache=True
                        )
                    )
                    
                    if isinstance(outputs, dict):
                        logits = outputs['logits']
                        past_key_values = outputs.get('past_key_values')
                    else:
                        logits = outputs[0]
                        past_key_values = outputs[1] if len(outputs) > 1 else None
                    
                    # Sample
                    next_token = self._sample_token(logits[:, -1, :])
                    token_text = self._detokenize([next_token.item()])
                    
                    # Update
                    generated = torch.cat([generated, next_token], dim=1)
                    self._output_buffer += token_text
                    token_count += 1
                    
                    yield token_text
                    
                    # Check EOS
                    if hasattr(self.model, 'config') and hasattr(self.model.config, 'eos_token_id'):
                        if next_token.item() == self.model.config.eos_token_id:
                            break
                    
                    # Delay
                    if self.config.delay_ms > 0:
                        await asyncio.sleep(self.config.delay_ms / 1000)
            
            self._state = StreamState.COMPLETED
            self._stats['total_tokens'] += token_count
            
        except Exception as e:
            self._state = StreamState.ERROR
            self._stats['error_streams'] += 1
            raise
    
    def generate_to_queue(
        self,
        prompt: str,
        **kwargs
    ) -> Queue:
        """
        Generate to a queue for consumer pattern.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional parameters
            
        Returns:
            Queue with generated tokens
        """
        queue = Queue(maxsize=self.config.buffer_size)
        
        def producer():
            try:
                for token in self.generate_stream(prompt, **kwargs):
                    queue.put(('token', token))
                queue.put(('done', None))
            except Exception as e:
                queue.put(('error', str(e)))
        
        thread = Thread(target=producer, daemon=True)
        thread.start()
        
        return queue
    
    def generate_sse(
        self,
        prompt: str,
        **kwargs
    ) -> Generator[str, None, None]:
        """
        Generate in Server-Sent Events format.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional parameters
            
        Yields:
            SSE formatted strings
        """
        try:
            for token in self.generate_stream(prompt, **kwargs):
                # SSE format
                data = json.dumps({'token': token}, ensure_ascii=False)
                yield f"data: {data}\n\n"
            
            # Send completion event
            data = json.dumps({'done': True}, ensure_ascii=False)
            yield f"data: {data}\n\n"
            
        except Exception as e:
            error_data = json.dumps({'error': str(e)}, ensure_ascii=False)
            yield f"data: {error_data}\n\n"
    
    def generate_websocket(
        self,
        prompt: str,
        **kwargs
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Generate WebSocket messages.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional parameters
            
        Yields:
            WebSocket message dictionaries
        """
        try:
            for token in self.generate_stream(prompt, **kwargs):
                yield {
                    'type': 'token',
                    'content': token,
                    'state': self._state.value
                }
            
            yield {
                'type': 'complete',
                'content': self._output_buffer,
                'state': StreamState.COMPLETED.value
            }
            
        except Exception as e:
            yield {
                'type': 'error',
                'content': str(e),
                'state': StreamState.ERROR.value
            }
    
    def cancel(self):
        """Cancel current generation"""
        self._cancel_event.set()
        self._state = StreamState.CANCELLED
        self._stats['cancelled_streams'] += 1
    
    def _sample_token(self, logits: torch.Tensor) -> torch.Tensor:
        """Sample next token from logits"""
        logits = logits / self.config.temperature
        
        if self.config.top_k > 0:
            v, _ = torch.topk(logits, min(self.config.top_k, logits.size(-1)))
            logits[logits < v[:, [-1]]] = float('-inf')
        
        if self.config.top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            
            sorted_indices_to_remove = cumulative_probs > self.config.top_p
            sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
            sorted_indices_to_remove[..., 0] = 0
            
            indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
            logits[indices_to_remove] = float('-inf')
        
        probs = F.softmax(logits, dim=-1)
        return torch.multinomial(probs, num_samples=1)
    
    def _tokenize(self, text: str) -> torch.Tensor:
        """Tokenize text"""
        if self.tokenizer is not None:
            return self.tokenizer.encode(text, return_tensors='pt').to(self.device)
        
        tokens = [ord(c) % 64000 for c in text]
        return torch.tensor([tokens], device=self.device)
    
    def _detokenize(self, tokens: List[int]) -> str:
        """Detokenize tokens"""
        if self.tokenizer is not None:
            return self.tokenizer.decode(tokens)
        
        return ''.join(chr(t % 65536) for t in tokens if t > 0)
    
    def get_state(self) -> StreamState:
        """Get current state"""
        return self._state
    
    def get_output(self) -> str:
        """Get current output buffer"""
        return self._output_buffer
    
    def get_stats(self) -> Dict[str, Any]:
        """Get streaming statistics"""
        return self._stats.copy()


# =============================================================================
# WEBSOCKET SERVER HELPER
# =============================================================================

class WebSocketStreamingHandler:
    """
    WebSocket handler for streaming generation.
    
    Usage with websockets library:
        async def handler(websocket):
            ws_handler = WebSocketStreamingHandler(model, tokenizer)
            await ws_handler.handle(websocket)
    """
    
    def __init__(
        self,
        model: nn.Module,
        tokenizer: Any = None,
        config: Optional[StreamConfig] = None
    ):
        self.generator = StreamingGenerator(model, tokenizer, config)
    
    async def handle(self, websocket):
        """Handle WebSocket connection"""
        try:
            async for message in websocket:
                # Parse message
                if isinstance(message, str):
                    data = json.loads(message)
                else:
                    data = message
                
                # Handle different message types
                msg_type = data.get('type', 'generate')
                
                if msg_type == 'generate':
                    prompt = data.get('prompt', '')
                    await self._handle_generate(websocket, prompt)
                
                elif msg_type == 'cancel':
                    self.generator.cancel()
                    await websocket.send(json.dumps({'type': 'cancelled'}))
                
                elif msg_type == 'ping':
                    await websocket.send(json.dumps({'type': 'pong'}))
        
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            await websocket.send(json.dumps({
                'type': 'error',
                'message': str(e)
            }))
    
    async def _handle_generate(self, websocket, prompt: str):
        """Handle generation request"""
        try:
            async for token in self.generator.generate_stream_async(prompt):
                await websocket.send(json.dumps({
                    'type': 'token',
                    'content': token
                }))
            
            await websocket.send(json.dumps({
                'type': 'complete',
                'content': self.generator.get_output()
            }))
        
        except Exception as e:
            await websocket.send(json.dumps({
                'type': 'error',
                'message': str(e)
            }))
