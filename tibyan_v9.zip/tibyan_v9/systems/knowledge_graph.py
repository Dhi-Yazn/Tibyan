#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Knowledge Graph
================================================================================

Knowledge Graph Integration for Structured Knowledge

Features:
- Entity recognition and linking
- Relation extraction
- Knowledge retrieval
- Graph reasoning

NO SIMPLIFICATIONS - Full production code.

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple, Set
from dataclasses import dataclass, field
from collections import defaultdict
import re


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class Entity:
    """Knowledge Graph Entity"""
    id: str
    name: str
    entity_type: str
    aliases: List[str] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[torch.Tensor] = None
    
    def __hash__(self):
        return hash(self.id)


@dataclass
class Relation:
    """Knowledge Graph Relation"""
    id: str
    name: str
    head_entity: str
    tail_entity: str
    properties: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    
    def __hash__(self):
        return hash(self.id)


@dataclass
class Triple:
    """Knowledge Triple (head, relation, tail)"""
    head: str
    relation: str
    tail: str
    confidence: float = 1.0


# =============================================================================
# KNOWLEDGE GRAPH
# =============================================================================

class KnowledgeGraph:
    """
    Knowledge Graph for structured knowledge storage and retrieval.
    
    Features:
    - Entity and relation storage
    - Triple-based knowledge representation
    - Graph traversal and reasoning
    - Embedding-based retrieval
    """
    
    def __init__(
        self,
        embedding_dim: int = 256,
        device: Optional[torch.device] = None
    ):
        self.embedding_dim = embedding_dim
        self.device = device or torch.device('cpu')
        
        # Storage
        self.entities: Dict[str, Entity] = {}
        self.relations: Dict[str, Relation] = {}
        self.triples: List[Triple] = []
        
        # Index structures
        self.entity_by_name: Dict[str, str] = {}
        self.entity_by_type: Dict[str, Set[str]] = defaultdict(set)
        self.triples_by_head: Dict[str, List[Triple]] = defaultdict(list)
        self.triples_by_tail: Dict[str, List[Triple]] = defaultdict(list)
        self.triples_by_relation: Dict[str, List[Triple]] = defaultdict(list)
        
        # Embedding models
        self.entity_embeddings = nn.Embedding(100000, embedding_dim).to(self.device)
        self.relation_embeddings = nn.Embedding(1000, embedding_dim).to(self.device)
        
        # ID mappings
        self.entity_to_idx: Dict[str, int] = {}
        self.relation_to_idx: Dict[str, int] = {}
        self._next_entity_idx = 0
        self._next_relation_idx = 0
    
    def add_entity(
        self,
        entity: Entity
    ):
        """Add entity to graph"""
        self.entities[entity.id] = entity
        
        # Index by name
        self.entity_by_name[entity.name.lower()] = entity.id
        for alias in entity.aliases:
            self.entity_by_name[alias.lower()] = entity.id
        
        # Index by type
        self.entity_by_type[entity.entity_type].add(entity.id)
        
        # Assign embedding index
        if entity.id not in self.entity_to_idx:
            self.entity_to_idx[entity.id] = self._next_entity_idx
            self._next_entity_idx += 1
    
    def add_relation(
        self,
        relation: Relation
    ):
        """Add relation to graph"""
        self.relations[relation.id] = relation
    
    def add_triple(
        self,
        triple: Triple
    ):
        """Add triple to graph"""
        self.triples.append(triple)
        
        # Index
        self.triples_by_head[triple.head].append(triple)
        self.triples_by_tail[triple.tail].append(triple)
        self.triples_by_relation[triple.relation].append(triple)
        
        # Assign relation embedding index
        if triple.relation not in self.relation_to_idx:
            self.relation_to_idx[triple.relation] = self._next_relation_idx
            self._next_relation_idx += 1
    
    def get_entity(
        self,
        entity_id: str
    ) -> Optional[Entity]:
        """Get entity by ID"""
        return self.entities.get(entity_id)
    
    def find_entity_by_name(
        self,
        name: str
    ) -> Optional[Entity]:
        """Find entity by name or alias"""
        entity_id = self.entity_by_name.get(name.lower())
        if entity_id:
            return self.entities[entity_id]
        return None
    
    def get_entities_by_type(
        self,
        entity_type: str
    ) -> List[Entity]:
        """Get all entities of a type"""
        entity_ids = self.entity_by_type.get(entity_type, set())
        return [self.entities[eid] for eid in entity_ids if eid in self.entities]
    
    def get_outgoing_relations(
        self,
        entity_id: str,
        relation_name: Optional[str] = None
    ) -> List[Triple]:
        """Get all triples where entity is head"""
        triples = self.triples_by_head.get(entity_id, [])
        if relation_name:
            triples = [t for t in triples if t.relation == relation_name]
        return triples
    
    def get_incoming_relations(
        self,
        entity_id: str,
        relation_name: Optional[str] = None
    ) -> List[Triple]:
        """Get all triples where entity is tail"""
        triples = self.triples_by_tail.get(entity_id, [])
        if relation_name:
            triples = [t for t in triples if t.relation == relation_name]
        return triples
    
    def query(
        self,
        head: Optional[str] = None,
        relation: Optional[str] = None,
        tail: Optional[str] = None
    ) -> List[Triple]:
        """
        Query the knowledge graph.
        
        Supports pattern matching with wildcards (None).
        
        Args:
            head: Head entity (None for wildcard)
            relation: Relation name (None for wildcard)
            tail: Tail entity (None for wildcard)
            
        Returns:
            Matching triples
        """
        results = self.triples
        
        if head is not None:
            results = [t for t in results if t.head == head]
        if relation is not None:
            results = [t for t in results if t.relation == relation]
        if tail is not None:
            results = [t for t in results if t.tail == tail]
        
        return results
    
    def find_path(
        self,
        start_entity: str,
        end_entity: str,
        max_depth: int = 3
    ) -> List[List[Triple]]:
        """
        Find paths between two entities.
        
        Args:
            start_entity: Starting entity ID
            end_entity: Target entity ID
            max_depth: Maximum path length
            
        Returns:
            List of paths (each path is a list of triples)
        """
        paths = []
        
        def dfs(current: str, target: str, path: List[Triple], visited: Set[str], depth: int):
            if depth > max_depth:
                return
            
            if current == target:
                paths.append(path.copy())
                return
            
            visited.add(current)
            
            # Get neighbors
            for triple in self.triples_by_head.get(current, []):
                if triple.tail not in visited:
                    path.append(triple)
                    dfs(triple.tail, target, path, visited, depth + 1)
                    path.pop()
        
        dfs(start_entity, end_entity, [], set(), 0)
        return paths
    
    def get_entity_embedding(
        self,
        entity_id: str
    ) -> torch.Tensor:
        """Get embedding for entity"""
        if entity_id in self.entity_to_idx:
            idx = self.entity_to_idx[entity_id]
            return self.entity_embeddings(torch.tensor([idx], device=self.device)).squeeze(0)
        return torch.zeros(self.embedding_dim, device=self.device)
    
    def get_relation_embedding(
        self,
        relation_name: str
    ) -> torch.Tensor:
        """Get embedding for relation"""
        if relation_name in self.relation_to_idx:
            idx = self.relation_to_idx[relation_name]
            return self.relation_embeddings(torch.tensor([idx], device=self.device)).squeeze(0)
        return torch.zeros(self.embedding_dim, device=self.device)
    
    def score_triple(
        self,
        head: str,
        relation: str,
        tail: str,
        method: str = "transE"
    ) -> float:
        """
        Score a triple using embedding methods.
        
        Args:
            head: Head entity ID
            relation: Relation name
            tail: Tail entity ID
            method: Scoring method (transE, distMult, complex)
            
        Returns:
            Triple score
        """
        h = self.get_entity_embedding(head)
        r = self.get_relation_embedding(relation)
        t = self.get_entity_embedding(tail)
        
        if method == "transE":
            score = -torch.norm(h + r - t, p=2).item()
        elif method == "distMult":
            score = (h * r * t).sum().item()
        else:
            score = -torch.norm(h + r - t, p=2).item()
        
        return score
    
    def predict_tails(
        self,
        head: str,
        relation: str,
        k: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Predict most likely tails for a head-relation pair.
        
        Args:
            head: Head entity ID
            relation: Relation name
            k: Number of predictions
            
        Returns:
            List of (entity_id, score) tuples
        """
        scores = []
        
        for entity_id in self.entities:
            score = self.score_triple(head, relation, entity_id)
            scores.append((entity_id, score))
        
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:k]
    
    def save(
        self,
        path: str
    ):
        """Save knowledge graph"""
        import pickle
        with open(path, 'wb') as f:
            pickle.dump({
                'entities': self.entities,
                'relations': self.relations,
                'triples': self.triples
            }, f)
    
    def load(
        self,
        path: str
    ):
        """Load knowledge graph"""
        import pickle
        with open(path, 'rb') as f:
            data = pickle.load(f)
            
            for entity in data['entities'].values():
                self.add_entity(entity)
            
            for relation in data['relations'].values():
                self.add_relation(relation)
            
            for triple in data['triples']:
                self.add_triple(triple)


# =============================================================================
# ENTITY LINKER
# =============================================================================

class EntityLinker(nn.Module):
    """
    Entity Linker for connecting text mentions to knowledge graph entities.
    
    Features:
    - Mention detection
    - Candidate generation
    - Disambiguation
    """
    
    def __init__(
        self,
        knowledge_graph: KnowledgeGraph,
        hidden_dim: int = 256,
        device: Optional[torch.device] = None
    ):
        super().__init__()
        
        self.kg = knowledge_graph
        self.hidden_dim = hidden_dim
        self.device = device or torch.device('cpu')
        
        # Context encoder
        self.context_encoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim)
        ).to(self.device)
        
        # Mention encoder
        self.mention_encoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim)
        ).to(self.device)
        
        # Scorer
        self.scorer = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1)
        ).to(self.device)
    
    def detect_mentions(
        self,
        text: str
    ) -> List[Tuple[str, int, int]]:
        """
        Detect potential entity mentions in text.
        
        Args:
            text: Input text
            
        Returns:
            List of (mention_text, start, end)
        """
        mentions = []
        
        # Simple pattern matching (in production, use NER model)
        for name, entity_id in self.kg.entity_by_name.items():
            if len(name) < 2:
                continue
            
            # Find all occurrences
            start = 0
            while True:
                pos = text.lower().find(name, start)
                if pos == -1:
                    break
                
                mentions.append((text[pos:pos + len(name)], pos, pos + len(name)))
                start = pos + 1
        
        return mentions
    
    def generate_candidates(
        self,
        mention: str
    ) -> List[Entity]:
        """Generate candidate entities for mention"""
        candidates = []
        
        # Exact match
        entity = self.kg.find_entity_by_name(mention)
        if entity:
            candidates.append(entity)
        
        # Partial matches
        mention_lower = mention.lower()
        for name, entity_id in self.kg.entity_by_name.items():
            if mention_lower in name or name in mention_lower:
                entity = self.kg.entities.get(entity_id)
                if entity and entity not in candidates:
                    candidates.append(entity)
        
        return candidates[:10]  # Top 10 candidates
    
    def disambiguate(
        self,
        mention_embedding: torch.Tensor,
        context_embedding: torch.Tensor,
        candidates: List[Entity]
    ) -> Tuple[Entity, float]:
        """
        Disambiguate mention to entity.
        
        Args:
            mention_embedding: Embedding of mention
            context_embedding: Embedding of context
            candidates: Candidate entities
            
        Returns:
            Tuple of (best_entity, confidence)
        """
        if not candidates:
            return None, 0.0
        
        if len(candidates) == 1:
            return candidates[0], 1.0
        
        best_entity = None
        best_score = float('-inf')
        
        for entity in candidates:
            entity_embedding = self.kg.get_entity_embedding(entity.id)
            
            # Combine features
            features = torch.cat([
                mention_embedding,
                context_embedding,
                entity_embedding
            ])
            
            score = self.scorer(features).item()
            
            if score > best_score:
                best_score = score
                best_entity = entity
        
        confidence = torch.sigmoid(torch.tensor(best_score)).item()
        
        return best_entity, confidence
    
    def forward(
        self,
        text: str,
        text_embedding: torch.Tensor
    ) -> List[Tuple[str, Entity, float]]:
        """
        Link entities in text.
        
        Args:
            text: Input text
            text_embedding: Text embedding
            
        Returns:
            List of (mention, entity, confidence)
        """
        # Detect mentions
        mentions = self.detect_mentions(text)
        
        # Encode context
        context_embedding = self.context_encoder(text_embedding)
        
        results = []
        for mention_text, start, end in mentions:
            # Generate candidates
            candidates = self.generate_candidates(mention_text)
            
            if not candidates:
                continue
            
            # Encode mention (simplified)
            mention_embedding = self.mention_encoder(text_embedding)
            
            # Disambiguate
            entity, confidence = self.disambiguate(
                mention_embedding,
                context_embedding,
                candidates
            )
            
            if entity:
                results.append((mention_text, entity, confidence))
        
        return results
