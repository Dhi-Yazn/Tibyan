"""
TIBYAN v9.0 AGI Micro-Engine - Utilities
=======================================

General utility functions and classes:
- Logging
- Timing
- Checkpointing
- Model statistics
- Progress tracking
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any, List, Union, Callable
from pathlib import Path
import logging
import sys
import time
import json
import os
from datetime import datetime
from dataclasses import asdict
import math


# =============================================================================
# LOGGING
# =============================================================================

def setup_logging(
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    format_string: Optional[str] = None,
    rich_formatting: bool = True
) -> logging.Logger:
    """
    Setup logging configuration.
    
    Args:
        level: Logging level
        log_file: Optional log file path
        format_string: Custom format string
        rich_formatting: Use colored output
        
    Returns:
        Root logger
    """
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Create formatter
    formatter = logging.Formatter(format_string, datefmt="%Y-%m-%d %H:%M:%S")
    
    # Setup root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Clear existing handlers
    root_logger.handlers = []
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # File handler
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    return root_logger


def get_logger(name: str) -> logging.Logger:
    """
    Get logger with given name.
    
    Args:
        name: Logger name (usually __name__)
        
    Returns:
        Logger instance
    """
    return logging.getLogger(name)


class LoggingContext:
    """Context manager for temporary logging level change"""
    
    def __init__(self, logger: logging.Logger, level: int):
        self.logger = logger
        self.level = level
        self.original_level = logger.level
    
    def __enter__(self):
        self.logger.setLevel(self.level)
        return self.logger
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logger.setLevel(self.original_level)


# =============================================================================
# TIMING
# =============================================================================

class Timer:
    """
    Simple timer for measuring execution time.
    
    Usage:
        timer = Timer()
        timer.start()
        # ... code to time ...
        elapsed = timer.stop()
        
        # Or as context manager:
        with Timer() as t:
            # ... code to time ...
        print(f"Took {t.elapsed:.2f}s")
    """
    
    def __init__(self, name: str = "Timer"):
        self.name = name
        self._start_time: Optional[float] = None
        self._end_time: Optional[float] = None
        self.elapsed: float = 0.0
    
    def start(self) -> 'Timer':
        """Start the timer"""
        self._start_time = time.time()
        return self
    
    def stop(self) -> float:
        """Stop the timer and return elapsed time"""
        self._end_time = time.time()
        if self._start_time is not None:
            self.elapsed = self._end_time - self._start_time
        return self.elapsed
    
    def reset(self) -> 'Timer':
        """Reset the timer"""
        self._start_time = None
        self._end_time = None
        self.elapsed = 0.0
        return self
    
    def __enter__(self) -> 'Timer':
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
    
    def __str__(self) -> str:
        return f"{self.name}: {self.elapsed:.4f}s"


class CumulativeTimer:
    """Timer that accumulates time across multiple calls"""
    
    def __init__(self, name: str = "CumulativeTimer"):
        self.name = name
        self.total_time: float = 0.0
        self.call_count: int = 0
        self._start_time: Optional[float] = None
    
    def start(self):
        """Start timing"""
        self._start_time = time.time()
    
    def stop(self):
        """Stop timing and accumulate"""
        if self._start_time is not None:
            self.total_time += time.time() - self._start_time
            self.call_count += 1
            self._start_time = None
    
    @property
    def average(self) -> float:
        """Average time per call"""
        return self.total_time / self.call_count if self.call_count > 0 else 0.0
    
    def __enter__(self):
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()


# =============================================================================
# PROGRESS TRACKING
# =============================================================================

class ProgressBar:
    """
    Simple progress bar for training loops.
    
    Usage:
        progress = ProgressBar(total=1000, desc="Training")
        for i in range(1000):
            # ... training step ...
            progress.update(1, loss=0.5)
    """
    
    def __init__(
        self,
        total: int,
        desc: str = "",
        unit: str = "it",
        bar_length: int = 40,
        print_freq: int = 1
    ):
        """
        Initialize progress bar.
        
        Args:
            total: Total number of iterations
            desc: Description prefix
            unit: Unit name
            bar_length: Length of progress bar
            print_freq: Print every N iterations
        """
        self.total = total
        self.desc = desc
        self.unit = unit
        self.bar_length = bar_length
        self.print_freq = print_freq
        
        self.current = 0
        self.start_time = time.time()
        self.metrics: Dict[str, float] = {}
    
    def update(self, n: int = 1, **metrics):
        """
        Update progress.
        
        Args:
            n: Number of iterations completed
            **metrics: Additional metrics to display
        """
        self.current += n
        self.metrics.update(metrics)
        
        if self.current % self.print_freq == 0 or self.current >= self.total:
            self._print()
    
    def _print(self):
        """Print progress bar"""
        elapsed = time.time() - self.start_time
        
        # Calculate progress
        if self.total > 0:
            progress = self.current / self.total
            filled = int(self.bar_length * progress)
            bar = '█' * filled + '░' * (self.bar_length - filled)
        else:
            bar = '?' * self.bar_length
            progress = 0.0
        
        # Calculate speed
        speed = self.current / elapsed if elapsed > 0 else 0
        
        # Format metrics
        metrics_str = ""
        for key, value in self.metrics.items():
            if isinstance(value, float):
                metrics_str += f" | {key}: {value:.4f}"
            else:
                metrics_str += f" | {key}: {value}"
        
        # ETA
        if speed > 0 and self.total > 0:
            eta = (self.total - self.current) / speed
            eta_str = f"ETA: {self._format_time(eta)}"
        else:
            eta_str = "ETA: --:--"
        
        # Print
        line = (
            f"\r{self.desc}: [{bar}] {self.current}/{self.total} "
            f"({progress * 100:.1f}%) | {speed:.2f} {self.unit}/s | "
            f"Elapsed: {self._format_time(elapsed)} | {eta_str}{metrics_str}"
        )
        
        print(line, end='', flush=True)
        
        if self.current >= self.total:
            print()  # New line at completion
    
    @staticmethod
    def _format_time(seconds: float) -> str:
        """Format time in HH:MM:SS"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    
    def close(self):
        """Close progress bar"""
        if self.current < self.total:
            print()  # Ensure new line


# =============================================================================
# MODEL UTILITIES
# =============================================================================

def count_parameters(model: nn.Module, trainable_only: bool = False) -> int:
    """
    Count model parameters.
    
    Args:
        model: Model to count
        trainable_only: Only count trainable parameters
        
    Returns:
        Number of parameters
    """
    if trainable_only:
        return sum(p.numel() for p in model.parameters() if p.requires_grad)
    return sum(p.numel() for p in model.parameters())


def get_model_size_mb(model: nn.Module) -> float:
    """
    Get model size in megabytes.
    
    Args:
        model: Model to measure
        
    Returns:
        Size in MB
    """
    param_size = 0
    for param in model.parameters():
        param_size += param.numel() * param.element_size()
    
    buffer_size = 0
    for buffer in model.buffers():
        buffer_size += buffer.numel() * buffer.element_size()
    
    return (param_size + buffer_size) / (1024 * 1024)


def get_model_info(model: nn.Module) -> Dict[str, Any]:
    """
    Get comprehensive model information.
    
    Args:
        model: Model to analyze
        
    Returns:
        Dictionary with model information
    """
    total_params = count_parameters(model, trainable_only=False)
    trainable_params = count_parameters(model, trainable_only=True)
    non_trainable_params = total_params - trainable_params
    
    return {
        "total_parameters": total_params,
        "trainable_parameters": trainable_params,
        "non_trainable_parameters": non_trainable_params,
        "trainable_ratio": trainable_params / total_params if total_params > 0 else 0,
        "size_mb": get_model_size_mb(model),
        "num_layers": len(list(model.modules())),
        "num_parameters_groups": len(list(model.parameters())),
    }


def freeze_module(module: nn.Module):
    """Freeze all parameters in a module"""
    for param in module.parameters():
        param.requires_grad = False


def unfreeze_module(module: nn.Module):
    """Unfreeze all parameters in a module"""
    for param in module.parameters():
        param.requires_grad = True


def get_gradient_norm(model: nn.Module, norm_type: float = 2.0) -> float:
    """
    Compute total gradient norm.
    
    Args:
        model: Model with gradients
        norm_type: Type of norm (default L2)
        
    Returns:
        Total gradient norm
    """
    total_norm = 0.0
    for param in model.parameters():
        if param.grad is not None:
            param_norm = param.grad.data.norm(norm_type)
            total_norm += param_norm.item() ** norm_type
    
    return total_norm ** (1.0 / norm_type)


def clip_gradient_norm(
    model: nn.Module,
    max_norm: float,
    norm_type: float = 2.0
) -> float:
    """
    Clip gradient norm and return the norm before clipping.
    
    Args:
        model: Model with gradients
        max_norm: Maximum allowed norm
        norm_type: Type of norm
        
    Returns:
        Gradient norm before clipping
    """
    return torch.nn.utils.clip_grad_norm_(
        model.parameters(),
        max_norm=max_norm,
        norm_type=norm_type
    )


# =============================================================================
# CHECKPOINTING
# =============================================================================

def save_checkpoint(
    model: nn.Module,
    optimizer: Optional[torch.optim.Optimizer],
    path: Union[str, Path],
    epoch: int = 0,
    step: int = 0,
    metrics: Optional[Dict[str, float]] = None,
    **kwargs
):
    """
    Save training checkpoint.
    
    Args:
        model: Model to save
        optimizer: Optimizer to save
        path: Checkpoint path
        epoch: Current epoch
        step: Current step
        metrics: Training metrics
        **kwargs: Additional items to save
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    checkpoint = {
        "epoch": epoch,
        "step": step,
        "model_state_dict": model.state_dict(),
        "timestamp": datetime.now().isoformat(),
    }
    
    if optimizer is not None:
        checkpoint["optimizer_state_dict"] = optimizer.state_dict()
    
    if metrics:
        checkpoint["metrics"] = metrics
    
    checkpoint.update(kwargs)
    
    torch.save(checkpoint, path)
    logger = get_logger(__name__)
    logger.info(f"Checkpoint saved to {path}")


def load_checkpoint(
    path: Union[str, Path],
    model: Optional[nn.Module] = None,
    optimizer: Optional[torch.optim.Optimizer] = None,
    map_location: Optional[str] = None,
    strict: bool = True
) -> Dict[str, Any]:
    """
    Load training checkpoint.
    
    Args:
        path: Checkpoint path
        model: Model to load state into
        optimizer: Optimizer to load state into
        map_location: Device to map tensors to
        strict: Strict loading for model
        
    Returns:
        Checkpoint dictionary
    """
    path = Path(path)
    
    if not path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    
    checkpoint = torch.load(path, map_location=map_location)
    
    if model is not None and "model_state_dict" in checkpoint:
        model.load_state_dict(checkpoint["model_state_dict"], strict=strict)
    
    if optimizer is not None and "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    
    logger = get_logger(__name__)
    logger.info(f"Checkpoint loaded from {path}")
    
    return checkpoint


def get_latest_checkpoint(checkpoint_dir: Union[str, Path]) -> Optional[Path]:
    """
    Get the latest checkpoint in a directory.
    
    Args:
        checkpoint_dir: Directory containing checkpoints
        
    Returns:
        Path to latest checkpoint or None
    """
    checkpoint_dir = Path(checkpoint_dir)
    
    if not checkpoint_dir.exists():
        return None
    
    checkpoints = list(checkpoint_dir.glob("*.pt")) + list(checkpoint_dir.glob("*.pth"))
    
    if not checkpoints:
        return None
    
    return max(checkpoints, key=lambda p: p.stat().st_mtime)


# =============================================================================
# CONFIG UTILITIES
# =============================================================================

def save_config(config: Any, path: Union[str, Path]):
    """
    Save configuration to JSON.
    
    Args:
        config: Configuration object (dataclass)
        path: Output path
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    if hasattr(config, 'to_dict'):
        config_dict = config.to_dict()
    else:
        config_dict = asdict(config)
    
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config_dict, f, indent=2, ensure_ascii=False, default=str)


def load_config(config_class: type, path: Union[str, Path]) -> Any:
    """
    Load configuration from JSON.
    
    Args:
        config_class: Configuration class
        path: Config path
        
    Returns:
        Configuration instance
    """
    path = Path(path)
    
    with open(path, 'r', encoding='utf-8') as f:
        config_dict = json.load(f)
    
    if hasattr(config_class, 'from_dict'):
        return config_class.from_dict(config_dict)
    
    return config_class(**config_dict)


# =============================================================================
# MATH UTILITIES
# =============================================================================

def warmup_cosine_schedule(
    step: int,
    warmup_steps: int,
    total_steps: int,
    base_lr: float,
    min_lr: float = 0.0
) -> float:
    """
    Cosine learning rate schedule with warmup.
    
    Args:
        step: Current step
        warmup_steps: Number of warmup steps
        total_steps: Total training steps
        base_lr: Base learning rate
        min_lr: Minimum learning rate
        
    Returns:
        Learning rate for current step
    """
    if step < warmup_steps:
        return base_lr * step / warmup_steps
    
    progress = (step - warmup_steps) / (total_steps - warmup_steps)
    cosine_factor = 0.5 * (1 + math.cos(math.pi * progress))
    
    return min_lr + (base_lr - min_lr) * cosine_factor


def get_linear_schedule_with_warmup(
    step: int,
    warmup_steps: int,
    total_steps: int,
    base_lr: float
) -> float:
    """
    Linear learning rate schedule with warmup.
    
    Args:
        step: Current step
        warmup_steps: Number of warmup steps
        total_steps: Total training steps
        base_lr: Base learning rate
        
    Returns:
        Learning rate for current step
    """
    if step < warmup_steps:
        return base_lr * step / warmup_steps
    
    progress = (step - warmup_steps) / (total_steps - warmup_steps)
    
    return base_lr * max(0.0, 1.0 - progress)


# =============================================================================
# DECORATORS
# =============================================================================

def timeit(func: Callable) -> Callable:
    """Decorator to time function execution"""
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"{func.__name__} took {elapsed:.4f}s")
        return result
    return wrapper


def profile(func: Callable) -> Callable:
    """Decorator to profile function with memory stats"""
    def wrapper(*args, **kwargs):
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
        
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            peak_memory = torch.cuda.max_memory_allocated() / 1e6
            print(f"{func.__name__}: {elapsed:.4f}s, peak memory: {peak_memory:.1f}MB")
        else:
            print(f"{func.__name__}: {elapsed:.4f}s")
        
        return result
    return wrapper
