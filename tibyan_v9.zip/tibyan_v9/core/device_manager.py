"""
TIBYAN v9.0 AGI Micro-Engine - Device Manager
=============================================

Comprehensive device management with:
- Automatic device detection (CUDA, MPS, CPU)
- OOM handling with graceful fallback
- Memory tracking and optimization
- Multi-GPU support
- Mobile device optimization
"""

import torch
import torch.nn as nn
from typing import Optional, List, Dict, Any, Tuple, Union
from dataclasses import dataclass, field
from collections import deque
import gc
import warnings
import logging
from enum import Enum
import os
import platform

logger = logging.getLogger(__name__)


class DeviceType(Enum):
    """Supported device types"""
    CUDA = "cuda"
    MPS = "mps"  # Apple Silicon
    CPU = "cpu"
    XLA = "xla"  # TPU
    ROCM = "rocm"  # AMD


@dataclass
class DeviceInfo:
    """Device information container"""
    device_type: DeviceType
    device_name: str
    device_index: int = 0
    total_memory_gb: float = 0.0
    available_memory_gb: float = 0.0
    compute_capability: Optional[Tuple[int, int]] = None
    multi_processor_count: int = 1
    
    def __str__(self) -> str:
        return f"{self.device_name} ({self.device_type.value}:{self.device_index})"


@dataclass
class MemorySnapshot:
    """Memory usage snapshot"""
    allocated_mb: float
    reserved_mb: float
    free_mb: float
    total_mb: float
    timestamp: float
    
    @property
    def utilization(self) -> float:
        """Memory utilization ratio"""
        return self.allocated_mb / self.total_mb if self.total_mb > 0 else 0.0


class SafeDeviceManager:
    """
    Dynamic GPU/CPU Fallback Manager with OOM handling.
    
    Key Features:
    - Automatic device detection and selection
    - Graceful OOM fallback from GPU to CPU
    - Memory tracking with history
    - Multi-device management
    - Mobile/edge device optimization
    
    This is a production-grade implementation that ensures
    training/inference continues even when memory is exhausted.
    """
    
    def __init__(
        self,
        preferred_device: Optional[str] = None,
        verbose: bool = True,
        enable_memory_tracking: bool = True,
        oom_fallback_enabled: bool = True,
        max_memory_utilization: float = 0.9
    ):
        """
        Initialize the device manager.
        
        Args:
            preferred_device: Preferred device ('cuda', 'mps', 'cpu', 'auto')
            verbose: Print device information
            enable_memory_tracking: Track memory usage over time
            oom_fallback_enabled: Enable automatic fallback on OOM
            max_memory_utilization: Maximum memory utilization before proactive measures
        """
        self.verbose = verbose
        self.enable_memory_tracking = enable_memory_tracking
        self.oom_fallback_enabled = oom_fallback_enabled
        self.max_memory_utilization = max_memory_utilization
        
        # Detect and initialize device
        self._device_info = self._detect_devices()
        self._current_device = self._select_device(preferred_device)
        
        # State tracking
        self._fallback_count = 0
        self._oom_count = 0
        self._is_fallback_mode = False
        
        # Memory tracking
        self._memory_history: deque = deque(maxlen=1000)
        self._peak_memory_mb = 0.0
        
        # Multi-GPU
        self._available_devices: List[DeviceInfo] = list(self._device_info.values())
        self._device_index = 0
        
        if self.verbose:
            self._log_device_info()
    
    def _detect_devices(self) -> Dict[str, DeviceInfo]:
        """Detect all available devices"""
        devices = {}
        
        # CUDA devices
        if torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                devices[f"cuda:{i}"] = DeviceInfo(
                    device_type=DeviceType.CUDA,
                    device_name=props.name,
                    device_index=i,
                    total_memory_gb=props.total_memory / 1e9,
                    available_memory_gb=self._get_cuda_free_memory(i) / 1e9,
                    compute_capability=(props.major, props.minor),
                    multi_processor_count=props.multi_processor_count
                )
        
        # MPS (Apple Silicon)
        if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            devices["mps:0"] = DeviceInfo(
                device_type=DeviceType.MPS,
                device_name="Apple Silicon (MPS)",
                device_index=0,
                total_memory_gb=self._estimate_mps_memory(),
                available_memory_gb=self._estimate_mps_memory() * 0.8  # Conservative estimate
            )
        
        # CPU (always available)
        devices["cpu:0"] = DeviceInfo(
            device_type=DeviceType.CPU,
            device_name=f"{platform.processor()} or compatible",
            device_index=0,
            total_memory_gb=self._get_system_memory_gb(),
            available_memory_gb=self._get_available_system_memory_gb()
        )
        
        return devices
    
    def _select_device(self, preferred: Optional[str]) -> torch.device:
        """Select the best available device"""
        if preferred and preferred != "auto":
            if preferred in self._device_info:
                return torch.device(preferred)
            elif preferred.startswith("cuda") and "cuda:0" in self._device_info:
                return torch.device(preferred)
        
        # Auto-select: CUDA > MPS > CPU
        if "cuda:0" in self._device_info:
            return torch.device("cuda:0")
        elif "mps:0" in self._device_info:
            return torch.device("mps:0")
        else:
            return torch.device("cpu")
    
    def _log_device_info(self):
        """Log device information"""
        print("=" * 60)
        print(" TIBYAN v9.0 Device Manager")
        print("=" * 60)
        print(f" Selected Device: {self._current_device}")
        
        if self._current_device.type == "cuda":
            info = self._device_info.get(f"cuda:{self._current_device.index}", None)
            if info:
                print(f"   GPU: {info.device_name}")
                print(f"   Memory: {info.total_memory_gb:.1f} GB total")
                print(f"   Compute Capability: {info.compute_capability}")
                print(f"   Multi-processors: {info.multi_processor_count}")
        elif self._current_device.type == "mps":
            info = self._device_info.get("mps:0", None)
            if info:
                print(f"   Apple Silicon GPU via MPS")
                print(f"   Estimated Memory: {info.total_memory_gb:.1f} GB")
        
        print(f" Available Devices: {len(self._available_devices)}")
        for dev in self._available_devices:
            print(f"   - {dev}")
        print("=" * 60)
    
    @staticmethod
    def _get_cuda_free_memory(device_index: int = 0) -> float:
        """Get free CUDA memory in bytes"""
        if not torch.cuda.is_available():
            return 0.0
        try:
            torch.cuda.set_device(device_index)
            free, _ = torch.cuda.mem_get_info()
            return free
        except Exception:
            return 0.0
    
    @staticmethod
    def _get_system_memory_gb() -> float:
        """Get total system memory in GB"""
        try:
            import psutil
            return psutil.virtual_memory().total / 1e9
        except ImportError:
            # Fallback: estimate based on common values
            return 16.0  # Assume 16GB as default
    
    @staticmethod
    def _get_available_system_memory_gb() -> float:
        """Get available system memory in GB"""
        try:
            import psutil
            return psutil.virtual_memory().available / 1e9
        except ImportError:
            return 8.0  # Conservative estimate
    
    def _estimate_mps_memory(self) -> float:
        """Estimate MPS (Apple Silicon) available memory"""
        # Apple Silicon uses unified memory
        # Typically 1/2 to 2/3 of system memory is available for GPU
        system_memory = self._get_system_memory_gb()
        return system_memory * 0.5
    
    def get_device(self) -> torch.device:
        """Get the current device"""
        return self._current_device
    
    def is_gpu(self) -> bool:
        """Check if current device is GPU"""
        return self._current_device.type in ["cuda", "mps"]
    
    def is_cuda(self) -> bool:
        """Check if current device is CUDA"""
        return self._current_device.type == "cuda"
    
    def is_mps(self) -> bool:
        """Check if current device is MPS (Apple Silicon)"""
        return self._current_device.type == "mps"
    
    def is_cpu(self) -> bool:
        """Check if current device is CPU"""
        return self._current_device.type == "cpu"
    
    def is_fallback_mode(self) -> bool:
        """Check if running in fallback mode (after OOM)"""
        return self._is_fallback_mode
    
    def get_memory_snapshot(self) -> MemorySnapshot:
        """Get current memory usage snapshot"""
        if self._current_device.type == "cuda":
            allocated = torch.cuda.memory_allocated(self._current_device.index) / 1e6
            reserved = torch.cuda.memory_reserved(self._current_device.index) / 1e6
            info = self._device_info.get(f"cuda:{self._current_device.index}")
            total = info.total_memory_gb * 1000 if info else 0
            free = self._get_cuda_free_memory(self._current_device.index) / 1e6
        elif self._current_device.type == "mps":
            # MPS doesn't provide detailed memory info
            info = self._device_info.get("mps:0")
            total = info.total_memory_gb * 1000 if info else 0
            allocated = 0  # Not directly available
            reserved = 0
            free = total * 0.5
        else:
            # CPU
            info = self._device_info.get("cpu:0")
            total = info.total_memory_gb * 1000 if info else 0
            allocated = total - self._get_available_system_memory_gb() * 1000
            reserved = allocated
            free = self._get_available_system_memory_gb() * 1000
        
        import time
        snapshot = MemorySnapshot(
            allocated_mb=allocated,
            reserved_mb=reserved,
            free_mb=free,
            total_mb=total,
            timestamp=time.time()
        )
        
        # Track peak memory
        if allocated > self._peak_memory_mb:
            self._peak_memory_mb = allocated
        
        # Record history
        if self.enable_memory_tracking:
            self._memory_history.append(snapshot)
        
        return snapshot
    
    def get_memory_utilization(self) -> float:
        """Get current memory utilization as a ratio"""
        snapshot = self.get_memory_snapshot()
        return snapshot.utilization
    
    def get_peak_memory_mb(self) -> float:
        """Get peak memory usage in MB"""
        return self._peak_memory_mb
    
    def safe_forward(
        self,
        model: nn.Module,
        *args,
        **kwargs
    ) -> Any:
        """
        Execute forward pass with OOM handling.
        
        If CUDA OOM occurs, automatically falls back to CPU
        and continues execution.
        
        Args:
            model: The model to run
            *args, **kwargs: Arguments for the forward pass
            
        Returns:
            Model output
        """
        try:
            return model(*args, **kwargs)
        except RuntimeError as e:
            if 'out of memory' in str(e).lower():
                return self._handle_oom(model, args, kwargs)
            raise e
    
    def _handle_oom(
        self,
        model: nn.Module,
        args: tuple,
        kwargs: dict
    ) -> Any:
        """Handle OOM by falling back to CPU"""
        if not self.oom_fallback_enabled:
            raise RuntimeError("CUDA OOM and fallback is disabled")
        
        self._oom_count += 1
        self._fallback_count += 1
        
        if self.verbose:
            logger.warning(
                f"CUDA OOM detected! Falling back to CPU "
                f"(fallback #{self._fallback_count})"
            )
        
        # Clear GPU memory
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        
        # Move model to CPU
        model = model.to('cpu')
        self._current_device = torch.device('cpu')
        self._is_fallback_mode = True
        
        # Move inputs to CPU
        args = tuple(self._move_to_device(a, 'cpu') for a in args)
        kwargs = {k: self._move_to_device(v, 'cpu') for k, v in kwargs.items()}
        
        if self.verbose:
            logger.info("Model moved to CPU. Continuing execution...")
        
        # Retry forward pass
        return model(*args, **kwargs)
    
    def _move_to_device(
        self,
        obj: Any,
        device: Union[str, torch.device]
    ) -> Any:
        """Recursively move tensors to device"""
        if isinstance(obj, torch.Tensor):
            return obj.to(device)
        elif isinstance(obj, dict):
            return {k: self._move_to_device(v, device) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return type(obj)(self._move_to_device(v, device) for v in obj)
        return obj
    
    def optimize_memory(self, aggressive: bool = False):
        """
        Optimize memory usage.
        
        Args:
            aggressive: If True, take more aggressive measures
        """
        if self._current_device.type == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            
            if aggressive:
                # Python garbage collection
                gc.collect()
                
                # Reset peak memory stats
                torch.cuda.reset_peak_memory_stats(self._current_device.index)
        
        elif self._current_device.type == "mps":
            # MPS doesn't have as many memory management options
            gc.collect()
        
        else:
            # CPU
            gc.collect()
        
        if self.verbose:
            snapshot = self.get_memory_snapshot()
            logger.info(
                f"Memory: {snapshot.allocated_mb:.1f}MB used / "
                f"{snapshot.total_mb:.1f}MB total "
                f"({snapshot.utilization * 100:.1f}% utilization)"
            )
    
    def should_reduce_batch_size(self) -> bool:
        """Check if memory usage is too high and batch size should be reduced"""
        utilization = self.get_memory_utilization()
        return utilization > self.max_memory_utilization
    
    def get_recommended_batch_size(
        self,
        current_batch_size: int,
        min_batch_size: int = 1
    ) -> int:
        """Get recommended batch size based on memory usage"""
        utilization = self.get_memory_utilization()
        
        if utilization < 0.7:
            # Memory available, can increase
            return min(current_batch_size * 2, 128)
        elif utilization > 0.9:
            # Memory critical, reduce significantly
            return max(current_batch_size // 2, min_batch_size)
        elif utilization > 0.8:
            # Memory high, reduce slightly
            return max(current_batch_size - 1, min_batch_size)
        
        return current_batch_size
    
    def get_device_info(self, device_key: Optional[str] = None) -> Optional[DeviceInfo]:
        """Get device information"""
        if device_key:
            return self._device_info.get(device_key)
        
        # Return current device info
        key = f"{self._current_device.type}:{self._current_device.index}"
        return self._device_info.get(key)
    
    def get_all_devices(self) -> List[DeviceInfo]:
        """Get all available devices"""
        return self._available_devices.copy()
    
    def set_device(self, device: Union[str, torch.device]) -> bool:
        """
        Set the current device.
        
        Args:
            device: Device to set ('cuda:0', 'cpu', etc.)
            
        Returns:
            True if successful, False otherwise
        """
        if isinstance(device, str):
            device = torch.device(device)
        
        device_key = f"{device.type}:{device.index if device.index else 0}"
        
        if device_key not in self._device_info:
            logger.warning(f"Device {device} not available")
            return False
        
        self._current_device = device
        self._is_fallback_mode = False
        
        if device.type == "cuda":
            torch.cuda.set_device(device.index)
        
        if self.verbose:
            logger.info(f"Device set to: {self.get_device_info(device_key)}")
        
        return True
    
    def get_stats(self) -> Dict[str, Any]:
        """Get device manager statistics"""
        snapshot = self.get_memory_snapshot()
        
        return {
            "current_device": str(self._current_device),
            "is_fallback_mode": self._is_fallback_mode,
            "fallback_count": self._fallback_count,
            "oom_count": self._oom_count,
            "memory_allocated_mb": snapshot.allocated_mb,
            "memory_reserved_mb": snapshot.reserved_mb,
            "memory_free_mb": snapshot.free_mb,
            "memory_total_mb": snapshot.total_mb,
            "memory_utilization": snapshot.utilization,
            "peak_memory_mb": self._peak_memory_mb,
        }


class DeviceManager:
    """
    Simplified device manager for basic use cases.
    
    Provides a simpler interface for common device operations.
    """
    
    _instance: Optional['DeviceManager'] = None
    _safe_manager: Optional[SafeDeviceManager] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def initialize(
        cls,
        preferred_device: str = "auto",
        verbose: bool = True
    ):
        """Initialize the device manager"""
        if cls._safe_manager is None:
            cls._safe_manager = SafeDeviceManager(
                preferred_device=preferred_device,
                verbose=verbose
            )
    
    @classmethod
    def get_device(cls) -> torch.device:
        """Get the current device"""
        if cls._safe_manager is None:
            cls.initialize()
        return cls._safe_manager.get_device()
    
    @classmethod
    def is_gpu(cls) -> bool:
        """Check if using GPU"""
        if cls._safe_manager is None:
            cls.initialize()
        return cls._safe_manager.is_gpu()
    
    @classmethod
    def optimize_memory(cls):
        """Optimize memory usage"""
        if cls._safe_manager is None:
            cls.initialize()
        cls._safe_manager.optimize_memory()
    
    @classmethod
    def get_stats(cls) -> Dict[str, Any]:
        """Get device statistics"""
        if cls._safe_manager is None:
            cls.initialize()
        return cls._safe_manager.get_stats()
    
    @classmethod
    def safe_forward(cls, model: nn.Module, *args, **kwargs) -> Any:
        """Execute forward pass with OOM handling"""
        if cls._safe_manager is None:
            cls.initialize()
        return cls._safe_manager.safe_forward(model, *args, **kwargs)
