"""
TIBYAN v9.0 AGI Micro-Engine - Memory Manager
=============================================

Advanced memory management for efficient training and inference:
- Memory pool management
- Gradient checkpointing optimization
- CPU offloading strategies
- Memory-aware batch sizing
"""

import torch
import torch.nn as nn
from typing import Optional, List, Dict, Any, Tuple, Union, Callable
from dataclasses import dataclass, field
from collections import deque
import gc
import weakref
import logging
import threading
import time

logger = logging.getLogger(__name__)


@dataclass
class MemoryBlock:
    """Represents a block of memory"""
    address: int
    size_bytes: int
    allocated: bool
    timestamp: float
    tensor_ref: Optional[weakref.ref] = None


@dataclass
class MemoryPlan:
    """Memory allocation plan"""
    total_memory_bytes: int
    model_memory_bytes: int
    optimizer_memory_bytes: int
    activation_memory_bytes: int
    gradient_memory_bytes: int
    available_memory_bytes: int
    
    @property
    def utilization(self) -> float:
        return (self.total_memory_bytes - self.available_memory_bytes) / self.total_memory_bytes


class MemoryManager:
    """
    Advanced Memory Management System
    
    Features:
    - Memory pool with pre-allocation
    - Smart gradient checkpointing decisions
    - CPU offloading for large tensors
    - Memory-aware training configuration
    - Real-time memory monitoring
    """
    
    def __init__(
        self,
        max_memory_gb: Optional[float] = None,
        reserved_memory_gb: float = 1.0,
        enable_monitoring: bool = True,
        offload_threshold: float = 0.85
    ):
        """
        Initialize memory manager.
        
        Args:
            max_memory_gb: Maximum memory to use (None for auto-detect)
            reserved_memory_gb: Memory to reserve for system
            enable_monitoring: Enable background memory monitoring
            offload_threshold: Memory usage threshold to trigger offloading
        """
        self.reserved_memory_gb = reserved_memory_gb
        self.enable_monitoring = enable_monitoring
        self.offload_threshold = offload_threshold
        
        # Detect available memory
        self._total_memory_bytes = self._detect_total_memory()
        if max_memory_gb:
            self._max_memory_bytes = int(max_memory_gb * 1e9)
        else:
            self._max_memory_bytes = int(
                self._total_memory_bytes - reserved_memory_gb * 1e9
            )
        
        # Memory tracking
        self._allocated_blocks: Dict[int, MemoryBlock] = {}
        self._block_counter = 0
        self._memory_history: deque = deque(maxlen=10000)
        
        # Offloading
        self._offloaded_tensors: Dict[int, torch.Tensor] = {}
        
        # Monitoring
        self._monitoring_active = False
        self._monitor_thread: Optional[threading.Thread] = None
        
        # Callbacks
        self._oom_callbacks: List[Callable] = []
        self._high_memory_callbacks: List[Callable] = []
        
        if enable_monitoring:
            self._start_monitoring()
    
    def _detect_total_memory(self) -> int:
        """Detect total available memory"""
        if torch.cuda.is_available():
            return torch.cuda.get_device_properties(0).total_memory
        else:
            try:
                import psutil
                return psutil.virtual_memory().total
            except ImportError:
                return 16 * 1e9  # Default 16GB
    
    def _start_monitoring(self):
        """Start background memory monitoring"""
        if self._monitoring_active:
            return
        
        self._monitoring_active = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            daemon=True
        )
        self._monitor_thread.start()
    
    def _monitor_loop(self):
        """Background monitoring loop"""
        while self._monitoring_active:
            try:
                self._check_memory()
                time.sleep(0.1)  # Check every 100ms
            except Exception as e:
                logger.error(f"Memory monitoring error: {e}")
    
    def _check_memory(self):
        """Check memory and trigger callbacks if needed"""
        usage = self.get_memory_usage()
        
        if usage > self.offload_threshold:
            for callback in self._high_memory_callbacks:
                try:
                    callback(usage)
                except Exception as e:
                    logger.error(f"Memory callback error: {e}")
    
    def get_max_memory_bytes(self) -> int:
        """Get maximum allowed memory in bytes"""
        return self._max_memory_bytes
    
    def get_max_memory_gb(self) -> float:
        """Get maximum allowed memory in GB"""
        return self._max_memory_bytes / 1e9
    
    def get_current_memory_bytes(self) -> int:
        """Get current memory usage in bytes"""
        if torch.cuda.is_available():
            return torch.cuda.memory_allocated()
        else:
            try:
                import psutil
                process = psutil.Process()
                return process.memory_info().rss
            except ImportError:
                return 0
    
    def get_memory_usage(self) -> float:
        """Get current memory usage as a ratio"""
        current = self.get_current_memory_bytes()
        return current / self._max_memory_bytes if self._max_memory_bytes > 0 else 0
    
    def get_available_memory_bytes(self) -> int:
        """Get available memory in bytes"""
        return max(0, self._max_memory_bytes - self.get_current_memory_bytes())
    
    def can_allocate(self, size_bytes: int) -> bool:
        """Check if allocation is possible"""
        return size_bytes <= self.get_available_memory_bytes()
    
    def estimate_tensor_memory(
        self,
        shape: Tuple[int, ...],
        dtype: torch.dtype = torch.float32
    ) -> int:
        """Estimate memory needed for a tensor"""
        element_size = torch.tensor([], dtype=dtype).element_size()
        num_elements = 1
        for dim in shape:
            num_elements *= dim
        return num_elements * element_size
    
    def estimate_model_memory(self, model: nn.Module) -> int:
        """Estimate memory needed for a model"""
        param_memory = 0
        for param in model.parameters():
            param_memory += param.numel() * param.element_size()
        
        buffer_memory = 0
        for buffer in model.buffers():
            buffer_memory += buffer.numel() * buffer.element_size()
        
        return param_memory + buffer_memory
    
    def estimate_training_memory(
        self,
        model: nn.Module,
        batch_size: int,
        sequence_length: int,
        hidden_dim: int
    ) -> MemoryPlan:
        """
        Estimate memory needed for training.
        
        Returns a MemoryPlan with detailed breakdown.
        """
        # Model memory
        model_memory = self.estimate_model_memory(model)
        
        # Optimizer memory (AdamW: 2 states per parameter)
        optimizer_memory = model_memory * 2
        
        # Activation memory (rough estimate)
        # For transformer: ~batch_size * seq_len * hidden_dim * num_layers * 4
        activation_memory = batch_size * sequence_length * hidden_dim * 4
        
        # Gradient memory
        gradient_memory = model_memory
        
        total = model_memory + optimizer_memory + activation_memory + gradient_memory
        available = self._max_memory_bytes - total
        
        return MemoryPlan(
            total_memory_bytes=self._max_memory_bytes,
            model_memory_bytes=model_memory,
            optimizer_memory_bytes=optimizer_memory,
            activation_memory_bytes=activation_memory,
            gradient_memory_bytes=gradient_memory,
            available_memory_bytes=max(0, available)
        )
    
    def recommend_batch_size(
        self,
        model: nn.Module,
        sequence_length: int,
        hidden_dim: int,
        min_batch_size: int = 1,
        max_batch_size: int = 128
    ) -> int:
        """
        Recommend optimal batch size based on available memory.
        
        Uses binary search to find the largest batch size that fits.
        """
        low, high = min_batch_size, max_batch_size
        best = min_batch_size
        
        while low <= high:
            mid = (low + high) // 2
            plan = self.estimate_training_memory(
                model, mid, sequence_length, hidden_dim
            )
            
            if plan.available_memory_bytes > 0:
                best = mid
                low = mid + 1
            else:
                high = mid - 1
        
        return best
    
    def optimize_for_inference(
        self,
        model: nn.Module,
        use_kv_cache: bool = True,
        kv_cache_size: int = 0
    ) -> nn.Module:
        """
        Optimize model for inference.
        
        Args:
            model: The model to optimize
            use_kv_cache: Whether KV cache will be used
            kv_cache_size: Expected KV cache size in bytes
            
        Returns:
            Optimized model
        """
        # Set to eval mode
        model.eval()
        
        # Disable gradient computation
        for param in model.parameters():
            param.requires_grad = False
        
        # Clear any stored gradients
        model.zero_grad(set_to_none=True)
        
        # Run garbage collection
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        return model
    
    def offload_to_cpu(
        self,
        tensor: torch.Tensor,
        keep_on_gpu: bool = False
    ) -> torch.Tensor:
        """
        Offload a tensor to CPU memory.
        
        Args:
            tensor: Tensor to offload
            keep_on_gpu: Keep a copy on GPU
            
        Returns:
            CPU tensor (or GPU copy if keep_on_gpu)
        """
        if tensor.device.type == 'cpu':
            return tensor
        
        tensor_id = id(tensor)
        
        # Move to CPU
        cpu_tensor = tensor.cpu()
        self._offloaded_tensors[tensor_id] = cpu_tensor
        
        if keep_on_gpu:
            return tensor
        else:
            return cpu_tensor
    
    def load_from_cpu(
        self,
        tensor_id: int,
        device: Optional[torch.device] = None
    ) -> Optional[torch.Tensor]:
        """Load an offloaded tensor back to GPU"""
        if tensor_id not in self._offloaded_tensors:
            return None
        
        cpu_tensor = self._offloaded_tensors[tensor_id]
        
        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        return cpu_tensor.to(device)
    
    def register_oom_callback(self, callback: Callable):
        """Register a callback for OOM events"""
        self._oom_callbacks.append(callback)
    
    def register_high_memory_callback(self, callback: Callable):
        """Register a callback for high memory usage"""
        self._high_memory_callbacks.append(callback)
    
    def clear_cache(self):
        """Clear all caches"""
        gc.collect()
        
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        
        self._offloaded_tensors.clear()
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """Get detailed memory statistics"""
        current_bytes = self.get_current_memory_bytes()
        
        stats = {
            "total_memory_gb": self._total_memory_bytes / 1e9,
            "max_memory_gb": self._max_memory_bytes / 1e9,
            "current_memory_gb": current_bytes / 1e9,
            "available_memory_gb": self.get_available_memory_bytes() / 1e9,
            "memory_usage_ratio": self.get_memory_usage(),
            "offloaded_tensors_count": len(self._offloaded_tensors),
        }
        
        if torch.cuda.is_available():
            stats.update({
                "cuda_allocated_gb": torch.cuda.memory_allocated() / 1e9,
                "cuda_reserved_gb": torch.cuda.memory_reserved() / 1e9,
                "cuda_max_allocated_gb": torch.cuda.max_memory_allocated() / 1e9,
            })
        
        return stats
    
    def __del__(self):
        """Cleanup on destruction"""
        self._monitoring_active = False
        self.clear_cache()


class OptimizedMemoryPool:
    """
    Optimized memory pool for tensor allocation.
    
    Pre-allocates memory blocks to reduce allocation overhead
    and fragmentation.
    """
    
    def __init__(
        self,
        pool_size_mb: int = 1024,
        block_size_mb: int = 16,
        device: Optional[torch.device] = None
    ):
        """
        Initialize memory pool.
        
        Args:
            pool_size_mb: Total pool size in MB
            block_size_mb: Size of each block in MB
            device: Device to allocate on
        """
        self.pool_size_bytes = pool_size_mb * 1024 * 1024
        self.block_size_bytes = block_size_mb * 1024 * 1024
        self.device = device or torch.device(
            'cuda' if torch.cuda.is_available() else 'cpu'
        )
        
        # Calculate number of blocks
        self.num_blocks = self.pool_size_bytes // self.block_size_bytes
        
        # Pre-allocate memory pool
        self._pool = self._allocate_pool()
        
        # Track block usage
        self._free_blocks: deque = deque(range(self.num_blocks))
        self._used_blocks: Dict[int, MemoryBlock] = {}
    
    def _allocate_pool(self) -> torch.Tensor:
        """Pre-allocate the memory pool"""
        # Create a large tensor that serves as the memory pool
        pool = torch.empty(
            self.pool_size_bytes,
            dtype=torch.uint8,
            device=self.device
        )
        return pool
    
    def allocate(
        self,
        shape: Tuple[int, ...],
        dtype: torch.dtype = torch.float32
    ) -> Optional[torch.Tensor]:
        """
        Allocate a tensor from the pool.
        
        Args:
            shape: Shape of tensor to allocate
            dtype: Data type
            
        Returns:
            Allocated tensor, or None if pool exhausted
        """
        # Calculate required size
        element_size = torch.tensor([], dtype=dtype).element_size()
        num_elements = 1
        for dim in shape:
            num_elements *= dim
        required_bytes = num_elements * element_size
        
        # Calculate blocks needed
        blocks_needed = (required_bytes + self.block_size_bytes - 1) // self.block_size_bytes
        
        if len(self._free_blocks) < blocks_needed:
            return None  # Not enough space
        
        # Allocate blocks
        allocated_blocks = []
        for _ in range(blocks_needed):
            block_idx = self._free_blocks.popleft()
            allocated_blocks.append(block_idx)
        
        # Create tensor view
        start_idx = allocated_blocks[0] * self.block_size_bytes
        end_idx = (allocated_blocks[-1] + 1) * self.block_size_bytes
        
        memory_slice = self._pool[start_idx:end_idx]
        
        # Create tensor with proper shape and dtype
        tensor = memory_slice.view(dtype).view(shape)
        
        # Track allocation
        block = MemoryBlock(
            address=start_idx,
            size_bytes=required_bytes,
            allocated=True,
            timestamp=time.time()
        )
        self._used_blocks[allocated_blocks[0]] = block
        
        return tensor
    
    def deallocate(self, tensor: torch.Tensor):
        """Deallocate a tensor back to the pool"""
        # Find the block this tensor belongs to
        data_ptr = tensor.data_ptr()
        pool_ptr = self._pool.data_ptr()
        
        offset = data_ptr - pool_ptr
        block_idx = offset // self.block_size_bytes
        
        # Free blocks
        if block_idx in self._used_blocks:
            del self._used_blocks[block_idx]
            self._free_blocks.append(block_idx)
    
    def get_available_memory_bytes(self) -> int:
        """Get available memory in the pool"""
        return len(self._free_blocks) * self.block_size_bytes
    
    def get_utilization(self) -> float:
        """Get pool utilization ratio"""
        used = len(self._used_blocks)
        return used / self.num_blocks if self.num_blocks > 0 else 0
    
    def clear(self):
        """Clear all allocations"""
        self._free_blocks = deque(range(self.num_blocks))
        self._used_blocks.clear()


def estimate_memory_for_model(
    num_parameters: int,
    precision: str = "fp32",
    training: bool = False
) -> Dict[str, float]:
    """
    Estimate memory requirements for a model.
    
    Args:
        num_parameters: Number of model parameters
        precision: Precision ('fp32', 'fp16', 'bf16', 'int8', 'int4')
        training: Whether training (includes gradients and optimizer states)
        
    Returns:
        Dictionary with memory estimates
    """
    # Bytes per parameter
    bytes_per_param = {
        "fp32": 4,
        "fp16": 2,
        "bf16": 2,
        "int8": 1,
        "int4": 0.5,
    }
    
    bp = bytes_per_param.get(precision, 4)
    
    # Model memory
    model_memory_gb = num_parameters * bp / 1e9
    
    result = {
        "model_memory_gb": model_memory_gb,
    }
    
    if training:
        # Gradients
        gradient_memory_gb = model_memory_gb
        
        # Optimizer states (AdamW: 2 states)
        optimizer_memory_gb = model_memory_gb * 2
        
        # Total
        total_gb = model_memory_gb + gradient_memory_gb + optimizer_memory_gb
        
        result.update({
            "gradient_memory_gb": gradient_memory_gb,
            "optimizer_memory_gb": optimizer_memory_gb,
            "total_training_memory_gb": total_gb,
        })
    else:
        result["total_inference_memory_gb"] = model_memory_gb
    
    return result
