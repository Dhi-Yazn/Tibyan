"""
TIBYAN v9.0 AGI Micro-Engine - Tensor Operations
================================================

Safe and optimized tensor operations:
- Numerical stability helpers
- Memory-efficient operations
- Custom autograd functions
- Tensor manipulation utilities
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function
from typing import Optional, Tuple, List, Union, Any
import math
import warnings


class SafeTensorOps:
    """
    Numerically stable tensor operations.
    
    All operations are designed to handle edge cases:
    - Zero division
    - Numerical overflow/underflow
    - NaN propagation
    - Memory efficiency
    """
    
    @staticmethod
    def safe_softmax(
        x: torch.Tensor,
        dim: int = -1,
        eps: float = 1e-12,
        dtype: Optional[torch.dtype] = None
    ) -> torch.Tensor:
        """
        Numerically stable softmax.
        
        Uses the max-subtraction trick to prevent overflow.
        """
        if dtype is not None:
            x = x.to(dtype)
        
        # Subtract max for numerical stability
        x_max = x.max(dim=dim, keepdim=True).values
        x_shifted = x - x_max
        
        # Compute exp safely
        exp_x = torch.exp(x_shifted)
        
        # Normalize with epsilon for numerical stability
        sum_exp = exp_x.sum(dim=dim, keepdim=True)
        sum_exp = torch.clamp(sum_exp, min=eps)
        
        return exp_x / sum_exp
    
    @staticmethod
    def safe_log_softmax(
        x: torch.Tensor,
        dim: int = -1,
        eps: float = 1e-12
    ) -> torch.Tensor:
        """
        Numerically stable log softmax.
        """
        x_max = x.max(dim=dim, keepdim=True).values
        x_shifted = x - x_max
        
        log_sum_exp = x_shifted.exp().sum(dim=dim, keepdim=True).log()
        
        return x_shifted - log_sum_exp
    
    @staticmethod
    def safe_log(
        x: torch.Tensor,
        eps: float = 1e-12,
        clamp_min: bool = True
    ) -> torch.Tensor:
        """
        Safe logarithm with protection against log(0).
        """
        if clamp_min:
            x = torch.clamp(x, min=eps)
        return torch.log(x + eps * (x < eps).float())
    
    @staticmethod
    def safe_div(
        numerator: torch.Tensor,
        denominator: torch.Tensor,
        eps: float = 1e-12,
        replace_nan: float = 0.0
    ) -> torch.Tensor:
        """
        Safe division with protection against division by zero.
        """
        result = numerator / (denominator + eps)
        
        if replace_nan is not None:
            result = torch.where(
                torch.isnan(result),
                torch.full_like(result, replace_nan),
                result
            )
        
        return result
    
    @staticmethod
    def safe_sqrt(
        x: torch.Tensor,
        eps: float = 1e-12
    ) -> torch.Tensor:
        """
        Safe square root with protection against negative values.
        """
        return torch.sqrt(torch.clamp(x, min=eps))
    
    @staticmethod
    def safe_rsqrt(
        x: torch.Tensor,
        eps: float = 1e-12
    ) -> torch.Tensor:
        """
        Safe reciprocal square root.
        """
        return torch.rsqrt(torch.clamp(x, min=eps))
    
    @staticmethod
    def safe_exp(
        x: torch.Tensor,
        max_exp: float = 50.0,
        min_exp: float = -50.0
    ) -> torch.Tensor:
        """
        Safe exponential with clamping to prevent overflow.
        """
        return torch.exp(torch.clamp(x, min=min_exp, max=max_exp))
    
    @staticmethod
    def safe_gelu(x: torch.Tensor) -> torch.Tensor:
        """
        Numerically stable GELU activation.
        """
        return 0.5 * x * (1.0 + torch.tanh(
            math.sqrt(2.0 / math.pi) * (x + 0.044715 * torch.pow(x, 3.0))
        ))
    
    @staticmethod
    def entropy(
        probs: torch.Tensor,
        dim: int = -1,
        eps: float = 1e-12
    ) -> torch.Tensor:
        """
        Compute entropy of probability distribution.
        
        H(p) = -sum(p * log(p))
        """
        log_probs = SafeTensorOps.safe_log(probs, eps)
        return -torch.sum(probs * log_probs, dim=dim)
    
    @staticmethod
    def kl_divergence(
        p: torch.Tensor,
        q: torch.Tensor,
        eps: float = 1e-12
    ) -> torch.Tensor:
        """
        Compute KL divergence KL(P || Q).
        
        KL(P||Q) = sum(P * log(P/Q))
        """
        log_ratio = SafeTensorOps.safe_log(p / (q + eps), eps)
        return torch.sum(p * log_ratio, dim=-1)
    
    @staticmethod
    def cosine_similarity_safe(
        x1: torch.Tensor,
        x2: torch.Tensor,
        dim: int = -1,
        eps: float = 1e-8
    ) -> torch.Tensor:
        """
        Safe cosine similarity with protection against zero vectors.
        """
        norm1 = torch.norm(x1, dim=dim, keepdim=True)
        norm2 = torch.norm(x2, dim=dim, keepdim=True)
        
        # Avoid division by zero
        norm1 = torch.clamp(norm1, min=eps)
        norm2 = torch.clamp(norm2, min=eps)
        
        return (x1 * x2).sum(dim=dim, keepdim=True) / (norm1 * norm2)


class StraightThroughEstimator(Function):
    """
    Straight-Through Estimator for non-differentiable operations.
    
    Used in quantization and discretization where gradients
    need to flow through non-differentiable operations.
    
    Forward: Applies the non-differentiable operation
    Backward: Passes gradients through unchanged
    """
    
    @staticmethod
    def forward(ctx, input_tensor: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
        """
        Forward pass: Quantize based on threshold.
        
        For BitNet: {-1, 0, +1}
        """
        # Quantize: ternary weights
        abs_input = torch.abs(input_tensor)
        mask = (abs_input > threshold).float()
        quantized = torch.sign(input_tensor) * mask
        
        # Save for backward (though we bypass in backward)
        ctx.save_for_backward(input_tensor)
        ctx.threshold = threshold
        
        return quantized
    
    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[torch.Tensor, None]:
        """
        Backward pass: Straight-through gradient.
        
        Gradient passes through to the original input unchanged.
        """
        # STE: gradient flows through
        return grad_output, None


class MatmulWithoutOutputGrad(Function):
    """
    Memory-efficient matmul that doesn't require output gradient.
    
    Useful for inference or when output gradient is not needed.
    """
    
    @staticmethod
    def forward(ctx, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        ctx.save_for_backward(a, b)
        return torch.matmul(a, b)
    
    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        a, b = ctx.saved_tensors
        grad_a = grad_b = None
        
        if ctx.needs_input_grad[0]:
            grad_a = torch.matmul(grad_output, b.transpose(-2, -1))
        if ctx.needs_input_grad[1]:
            grad_b = torch.matmul(a.transpose(-2, -1), grad_output)
        
        return grad_a, grad_b


class TensorUtils:
    """
    Tensor manipulation utilities.
    """
    
    @staticmethod
    def ensure_contiguous(tensor: torch.Tensor) -> torch.Tensor:
        """Ensure tensor is contiguous in memory."""
        if not tensor.is_contiguous():
            return tensor.contiguous()
        return tensor
    
    @staticmethod
    def reshape_for_broadcast(
        tensor: torch.Tensor,
        target_shape: Tuple[int, ...]
    ) -> torch.Tensor:
        """Reshape tensor for broadcasting to target shape."""
        # Add dimensions as needed
        while len(tensor.shape) < len(target_shape):
            tensor = tensor.unsqueeze(-1)
        return tensor
    
    @staticmethod
    def split_heads(
        tensor: torch.Tensor,
        num_heads: int,
        head_dim: int
    ) -> torch.Tensor:
        """
        Split last dimension into heads.
        
        [..., num_heads * head_dim] -> [..., num_heads, head_dim]
        """
        new_shape = tensor.shape[:-1] + (num_heads, head_dim)
        return tensor.view(new_shape)
    
    @staticmethod
    def merge_heads(tensor: torch.Tensor) -> torch.Tensor:
        """
        Merge head dimensions.
        
        [..., num_heads, head_dim] -> [..., num_heads * head_dim]
        """
        new_shape = tensor.shape[:-2] + (tensor.shape[-2] * tensor.shape[-1],)
        return tensor.reshape(new_shape)
    
    @staticmethod
    def apply_rotary_emb(
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor
    ) -> torch.Tensor:
        """
        Apply rotary position embeddings.
        
        Args:
            x: [..., seq_len, head_dim]
            cos, sin: [..., seq_len, head_dim // 2]
        """
        # Split into two halves
        x1 = x[..., : x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2 :]
        
        # Apply rotation
        # Rotate: [x1, x2] -> [x1 * cos - x2 * sin, x1 * sin + x2 * cos]
        rotated = torch.cat([
            x1 * cos - x2 * sin,
            x1 * sin + x2 * cos,
        ], dim=-1)
        
        return rotated
    
    @staticmethod
    def create_causal_mask(
        seq_len: int,
        device: torch.device,
        dtype: torch.dtype = torch.float32
    ) -> torch.Tensor:
        """
        Create causal attention mask.
        
        Returns:
            Mask of shape [seq_len, seq_len] where True indicates positions to mask.
        """
        mask = torch.triu(
            torch.ones(seq_len, seq_len, device=device, dtype=dtype),
            diagonal=1
        ).bool()
        return mask
    
    @staticmethod
    def create_sliding_window_mask(
        seq_len: int,
        window_size: int,
        device: torch.device
    ) -> torch.Tensor:
        """
        Create sliding window attention mask.
        
        Only attend to tokens within the window.
        """
        # Create positions
        positions = torch.arange(seq_len, device=device)
        
        # Compute distance matrix
        distance = torch.abs(positions.unsqueeze(1) - positions.unsqueeze(0))
        
        # Mask positions outside window
        mask = distance > window_size
        
        return mask
    
    @staticmethod
    def chunked_attention(
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        chunk_size: int = 1024,
        scale: Optional[float] = None
    ) -> torch.Tensor:
        """
        Compute attention in chunks to save memory.
        
        Useful for very long sequences where full attention
        doesn't fit in memory.
        """
        batch_size, num_heads, seq_len, head_dim = q.shape
        
        if scale is None:
            scale = 1.0 / math.sqrt(head_dim)
        
        output = torch.zeros_like(q)
        
        for i in range(0, seq_len, chunk_size):
            q_chunk = q[:, :, i:i+chunk_size, :]
            
            # Compute attention for this chunk against all keys/values
            attn_weights = torch.matmul(q_chunk, k.transpose(-2, -1)) * scale
            
            # Causal mask for this chunk
            chunk_len = q_chunk.shape[2]
            causal_mask = torch.triu(
                torch.ones(chunk_len, seq_len, device=q.device),
                diagonal=i + 1
            ).bool()
            attn_weights = attn_weights.masked_fill(causal_mask, float('-inf'))
            
            # Softmax and apply to values
            attn_probs = F.softmax(attn_weights, dim=-1)
            output[:, :, i:i+chunk_size, :] = torch.matmul(attn_probs, v)
        
        return output
    
    @staticmethod
    def gather_from_experts(
        tensor: torch.Tensor,
        indices: torch.Tensor,
        num_experts: int
    ) -> torch.Tensor:
        """
        Gather tensor slices according to expert indices.
        
        Used in MoE routing.
        
        Args:
            tensor: [batch, seq_len, num_experts, hidden_dim]
            indices: [batch, seq_len, top_k] expert indices
            num_experts: Number of experts
        """
        batch_size, seq_len, top_k = indices.shape
        
        # Expand indices for gathering
        # indices: [batch, seq_len, top_k]
        # We need: [batch, seq_len, top_k, hidden_dim]
        
        gathered = torch.zeros(
            batch_size, seq_len, top_k, tensor.shape[-1],
            device=tensor.device,
            dtype=tensor.dtype
        )
        
        for k in range(top_k):
            expert_idx = indices[:, :, k]  # [batch, seq_len]
            gathered[:, :, k, :] = tensor[
                torch.arange(batch_size).unsqueeze(1),
                torch.arange(seq_len).unsqueeze(0),
                expert_idx
            ]
        
        return gathered


def get_dtype_size(dtype: torch.dtype) -> int:
    """Get size in bytes for a dtype."""
    return torch.tensor([], dtype=dtype).element_size()


def cast_to_dtype(
    tensor: torch.Tensor,
    dtype: torch.dtype,
    allow_downcast: bool = True
) -> torch.Tensor:
    """
    Safely cast tensor to dtype.
    
    Args:
        tensor: Input tensor
        dtype: Target dtype
        allow_downcast: Allow precision reduction
    """
    if tensor.dtype == dtype:
        return tensor
    
    if not allow_downcast:
        # Check if we're reducing precision
        current_size = get_dtype_size(tensor.dtype)
        target_size = get_dtype_size(dtype)
        
        if target_size < current_size:
            warnings.warn(
                f"Reducing precision from {tensor.dtype} to {dtype}. "
                "This may cause precision loss."
            )
    
    return tensor.to(dtype)


def create_attention_mask_from_lengths(
    lengths: torch.Tensor,
    max_length: int,
    device: torch.device
) -> torch.Tensor:
    """
    Create attention mask from sequence lengths.
    
    Args:
        lengths: [batch_size] - length of each sequence
        max_length: Maximum sequence length
        device: Device for the mask
        
    Returns:
        [batch_size, 1, 1, max_length] mask where True = masked position
    """
    batch_size = lengths.shape[0]
    
    # Create position indices
    positions = torch.arange(max_length, device=device).unsqueeze(0)
    
    # Compare with lengths
    mask = positions >= lengths.unsqueeze(1)
    
    # Reshape for attention: [batch, 1, 1, max_length]
    mask = mask.unsqueeze(1).unsqueeze(2)
    
    return mask
