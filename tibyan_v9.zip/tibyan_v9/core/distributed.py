"""
TIBYAN v9.0 AGI Micro-Engine - Distributed Training
===================================================

Distributed training support:
- Multi-GPU training
- Model parallelism
- Data parallelism
- Pipeline parallelism
- Process group management
"""

import torch
import torch.nn as nn
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from typing import Optional, List, Dict, Any, Tuple, Union
from dataclasses import dataclass, field
import os
import logging
import warnings

logger = logging.getLogger(__name__)


@dataclass
class DistributedConfig:
    """Configuration for distributed training"""
    backend: str = "nccl"  # nccl, gloo, mpi
    init_method: str = "env://"
    world_size: int = 1
    rank: int = 0
    local_rank: int = 0
    
    # Model parallelism
    tensor_parallel_size: int = 1
    pipeline_parallel_size: int = 1
    
    # Data parallelism
    data_parallel_size: int = 1
    
    # Communication
    gradient_compression: bool = False
    gradient_predivide_factor: float = 1.0
    
    # Mixed precision
    fp32_reduce_scatter: bool = False


class ProcessGroupManager:
    """
    Manages process groups for different parallelism strategies.
    
    Supports:
    - Data parallel groups
    - Tensor parallel groups
    - Pipeline parallel groups
    """
    
    def __init__(self, config: DistributedConfig):
        """
        Initialize process group manager.
        
        Args:
            config: Distributed configuration
        """
        self.config = config
        self._initialized = False
        
        # Process groups
        self._world_group = None
        self._data_parallel_group = None
        self._tensor_parallel_group = None
        self._pipeline_parallel_group = None
        
        # Group info
        self._data_parallel_rank = 0
        self._tensor_parallel_rank = 0
        self._pipeline_parallel_rank = 0
        self._data_parallel_world_size = 1
        self._tensor_parallel_world_size = 1
        self._pipeline_parallel_world_size = 1
    
    def initialize(self):
        """Initialize process groups"""
        if self._initialized:
            return
        
        if not dist.is_initialized():
            dist.init_process_group(
                backend=self.config.backend,
                init_method=self.config.init_method,
                world_size=self.config.world_size,
                rank=self.config.rank
            )
        
        self._world_group = dist.group.WORLD
        
        # Create process groups based on parallelism strategy
        self._create_process_groups()
        
        self._initialized = True
        
        logger.info(
            f"Distributed initialized: rank={self.config.rank}, "
            f"world_size={self.config.world_size}, "
            f"dp_size={self._data_parallel_world_size}, "
            f"tp_size={self._tensor_parallel_world_size}, "
            f"pp_size={self._pipeline_parallel_world_size}"
        )
    
    def _create_process_groups(self):
        """Create all process groups"""
        rank = self.config.rank
        world_size = self.config.world_size
        tp_size = self.config.tensor_parallel_size
        pp_size = self.config.pipeline_parallel_size
        
        # Calculate data parallel size
        dp_size = world_size // (tp_size * pp_size)
        
        self._data_parallel_world_size = dp_size
        self._tensor_parallel_world_size = tp_size
        self._pipeline_parallel_world_size = pp_size
        
        # Calculate ranks
        self._pipeline_parallel_rank = rank // (tp_size * dp_size)
        remaining = rank % (tp_size * dp_size)
        self._tensor_parallel_rank = remaining // dp_size
        self._data_parallel_rank = remaining % dp_size
        
        # Create tensor parallel groups
        if tp_size > 1:
            for i in range(pp_size):
                for j in range(dp_size):
                    start = i * tp_size * dp_size + j * tp_size
                    ranks = list(range(start, start + tp_size))
                    group = dist.new_group(ranks)
                    if rank in ranks:
                        self._tensor_parallel_group = group
        
        # Create pipeline parallel groups
        if pp_size > 1:
            for i in range(tp_size):
                for j in range(dp_size):
                    start = i * dp_size + j
                    ranks = [start + k * tp_size * dp_size for k in range(pp_size)]
                    group = dist.new_group(ranks)
                    if rank in ranks:
                        self._pipeline_parallel_group = group
        
        # Create data parallel groups
        if dp_size > 1:
            for i in range(pp_size):
                for j in range(tp_size):
                    start = i * tp_size * dp_size + j * dp_size
                    ranks = list(range(start, start + dp_size))
                    group = dist.new_group(ranks)
                    if rank in ranks:
                        self._data_parallel_group = group
    
    @property
    def is_initialized(self) -> bool:
        """Check if distributed is initialized"""
        return self._initialized and dist.is_initialized()
    
    @property
    def rank(self) -> int:
        """Get global rank"""
        return self.config.rank
    
    @property
    def world_size(self) -> int:
        """Get global world size"""
        return self.config.world_size
    
    @property
    def local_rank(self) -> int:
        """Get local rank on this node"""
        return self.config.local_rank
    
    @property
    def data_parallel_rank(self) -> int:
        """Get rank in data parallel group"""
        return self._data_parallel_rank
    
    @property
    def tensor_parallel_rank(self) -> int:
        """Get rank in tensor parallel group"""
        return self._tensor_parallel_rank
    
    @property
    def pipeline_parallel_rank(self) -> int:
        """Get rank in pipeline parallel group"""
        return self._pipeline_parallel_rank
    
    @property
    def data_parallel_group(self):
        """Get data parallel process group"""
        return self._data_parallel_group or self._world_group
    
    @property
    def tensor_parallel_group(self):
        """Get tensor parallel process group"""
        return self._tensor_parallel_group or self._world_group
    
    @property
    def pipeline_parallel_group(self):
        """Get pipeline parallel process group"""
        return self._pipeline_parallel_group or self._world_group
    
    def is_master(self) -> bool:
        """Check if this is the master process"""
        return self.config.rank == 0
    
    def barrier(self):
        """Synchronization barrier"""
        if self.is_initialized:
            dist.barrier()
    
    def all_reduce(
        self,
        tensor: torch.Tensor,
        op: dist.ReduceOp = dist.ReduceOp.SUM,
        group=None
    ):
        """
        All-reduce operation.
        
        Args:
            tensor: Tensor to reduce
            op: Reduction operation
            group: Process group (default: world)
        """
        if self.is_initialized:
            dist.all_reduce(tensor, op, group=group or self._world_group)
    
    def all_gather(
        self,
        tensor_list: List[torch.Tensor],
        tensor: torch.Tensor,
        group=None
    ):
        """
        All-gather operation.
        
        Args:
            tensor_list: List to gather into
            tensor: Tensor to gather
            group: Process group
        """
        if self.is_initialized:
            dist.all_gather(
                tensor_list, tensor,
                group=group or self._world_group
            )
    
    def broadcast(
        self,
        tensor: torch.Tensor,
        src: int = 0,
        group=None
    ):
        """
        Broadcast operation.
        
        Args:
            tensor: Tensor to broadcast
            src: Source rank
            group: Process group
        """
        if self.is_initialized:
            dist.broadcast(
                tensor, src,
                group=group or self._world_group
            )
    
    def scatter(
        self,
        tensor: torch.Tensor,
        scatter_list: Optional[List[torch.Tensor]] = None,
        src: int = 0,
        group=None
    ):
        """Scatter operation"""
        if self.is_initialized:
            dist.scatter(
                tensor, scatter_list, src,
                group=group or self._world_group
            )
    
    def gather(
        self,
        tensor: torch.Tensor,
        gather_list: Optional[List[torch.Tensor]] = None,
        dst: int = 0,
        group=None
    ):
        """Gather operation"""
        if self.is_initialized:
            dist.gather(
                tensor, gather_list, dst,
                group=group or self._world_group
            )
    
    def reduce_scatter(
        self,
        output: torch.Tensor,
        input_list: List[torch.Tensor],
        op: dist.ReduceOp = dist.ReduceOp.SUM,
        group=None
    ):
        """Reduce-scatter operation"""
        if self.is_initialized:
            dist.reduce_scatter(
                output, input_list, op,
                group=group or self._world_group
            )


class DistributedManager:
    """
    High-level distributed training manager.
    
    Provides easy-to-use interface for:
    - Model wrapping
    - Gradient synchronization
    - Distributed checkpointing
    - Communication optimization
    """
    
    _instance: Optional['DistributedManager'] = None
    
    def __init__(
        self,
        config: Optional[DistributedConfig] = None,
        auto_init: bool = True
    ):
        """
        Initialize distributed manager.
        
        Args:
            config: Distributed configuration
            auto_init: Automatically initialize from environment
        """
        self.config = config or self._detect_config()
        self._pg_manager: Optional[ProcessGroupManager] = None
        
        if auto_init and self._should_init():
            self.initialize()
    
    @classmethod
    def get_instance(cls) -> 'DistributedManager':
        """Get singleton instance"""
        if cls._instance is None:
            cls._instance = cls(auto_init=True)
        return cls._instance
    
    def _should_init(self) -> bool:
        """Check if should initialize distributed"""
        return (
            "RANK" in os.environ or
            "WORLD_SIZE" in os.environ or
            "LOCAL_RANK" in os.environ
        )
    
    def _detect_config(self) -> DistributedConfig:
        """Detect configuration from environment variables"""
        return DistributedConfig(
            backend=os.environ.get("BACKEND", "nccl"),
            init_method=os.environ.get("INIT_METHOD", "env://"),
            world_size=int(os.environ.get("WORLD_SIZE", 1)),
            rank=int(os.environ.get("RANK", 0)),
            local_rank=int(os.environ.get("LOCAL_RANK", 0)),
            tensor_parallel_size=int(os.environ.get("TP_SIZE", 1)),
            pipeline_parallel_size=int(os.environ.get("PP_SIZE", 1)),
        )
    
    def initialize(self):
        """Initialize distributed training"""
        if self._pg_manager is not None:
            return
        
        self._pg_manager = ProcessGroupManager(self.config)
        self._pg_manager.initialize()
        
        # Set device for this process
        if torch.cuda.is_available():
            torch.cuda.set_device(self.config.local_rank)
    
    @property
    def is_initialized(self) -> bool:
        """Check if distributed is initialized"""
        return self._pg_manager is not None and self._pg_manager.is_initialized
    
    @property
    def rank(self) -> int:
        """Get global rank"""
        return self.config.rank
    
    @property
    def world_size(self) -> int:
        """Get world size"""
        return self.config.world_size
    
    @property
    def is_master(self) -> bool:
        """Check if master process"""
        return self.config.rank == 0
    
    def wrap_model(
        self,
        model: nn.Module,
        find_unused_parameters: bool = False,
        gradient_as_bucket_view: bool = True
    ) -> nn.Module:
        """
        Wrap model for distributed training.
        
        Args:
            model: Model to wrap
            find_unused_parameters: Find unused parameters in forward pass
            gradient_as_bucket_view: Use gradient as bucket view for efficiency
            
        Returns:
            Wrapped model (DDP if distributed, otherwise original)
        """
        if not self.is_initialized:
            return model
        
        return DDP(
            model,
            device_ids=[self.config.local_rank],
            output_device=self.config.local_rank,
            find_unused_parameters=find_unused_parameters,
            gradient_as_bucket_view=gradient_as_bucket_view,
            process_group=self._pg_manager.data_parallel_group
        )
    
    def all_reduce_gradient(
        self,
        model: nn.Module,
        average: bool = True
    ):
        """
        Manually all-reduce gradients.
        
        Useful when not using DDP.
        """
        if not self.is_initialized:
            return
        
        for param in model.parameters():
            if param.grad is not None:
                self._pg_manager.all_reduce(param.grad.data)
                if average:
                    param.grad.data.div_(self.world_size)
    
    def broadcast_model(
        self,
        model: nn.Module,
        src: int = 0
    ):
        """
        Broadcast model parameters from source.
        
        Useful for loading checkpoint on master and broadcasting.
        """
        if not self.is_initialized:
            return
        
        for param in model.parameters():
            self._pg_manager.broadcast(param.data, src=src)
        
        for buffer in model.buffers():
            self._pg_manager.broadcast(buffer.data, src=src)
    
    def sync_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
        """Synchronize tensor across all processes"""
        if not self.is_initialized:
            return tensor
        
        self._pg_manager.all_reduce(tensor.clone(), op=dist.ReduceOp.SUM)
        tensor.div_(self.world_size)
        return tensor
    
    def barrier(self):
        """Synchronization barrier"""
        if self._pg_manager:
            self._pg_manager.barrier()
    
    def print_on_master(self, msg: str):
        """Print only on master process"""
        if self.is_master:
            print(msg)
    
    def save_checkpoint(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        path: str,
        **kwargs
    ):
        """Save checkpoint (only master saves)"""
        if not self.is_master:
            return
        
        checkpoint = {
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "config": self.config.__dict__,
            **kwargs
        }
        torch.save(checkpoint, path)
    
    def load_checkpoint(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer],
        path: str,
        map_location: Optional[str] = None
    ) -> Dict[str, Any]:
        """Load checkpoint and broadcast to all processes"""
        if map_location is None:
            map_location = f"cuda:{self.config.local_rank}"
        
        checkpoint = torch.load(path, map_location=map_location)
        
        model.load_state_dict(checkpoint["model_state_dict"])
        
        if optimizer is not None and "optimizer_state_dict" in checkpoint:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        
        return checkpoint


def get_world_size() -> int:
    """Get world size without full initialization"""
    if dist.is_initialized():
        return dist.get_world_size()
    return int(os.environ.get("WORLD_SIZE", 1))


def get_rank() -> int:
    """Get rank without full initialization"""
    if dist.is_initialized():
        return dist.get_rank()
    return int(os.environ.get("RANK", 0))


def is_master() -> bool:
    """Check if master process"""
    return get_rank() == 0
