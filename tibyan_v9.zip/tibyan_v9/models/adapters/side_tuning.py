#!/usr/bin/env python3
"""
Side-Tuning Adapter

For mobile-friendly fine-tuning without backprop through main model.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class SideTuningAdapter(nn.Module):
    """
    Side-Tuning: Train a small side network while freezing main model.
    
    Ideal for mobile deployment - minimal memory and compute.
    """
    
    def __init__(
        self,
        hidden_dim: int,
        adapter_dim: int = 64,
        num_layers: int = 4,
        dropout: float = 0.1
    ):
        super().__init__()
        
        self.side_network = nn.Sequential(
            nn.Linear(hidden_dim, adapter_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            *[nn.Sequential(
                nn.Linear(adapter_dim, adapter_dim),
                nn.GELU(),
                nn.Dropout(dropout)
            ) for _ in range(num_layers - 2)],
            nn.Linear(adapter_dim, hidden_dim)
        )
        
        # Learnable combination weight
        self.alpha = nn.Parameter(torch.tensor(0.1))
    
    def forward(self, main_output: torch.Tensor, original_input: torch.Tensor) -> torch.Tensor:
        """Combine main model output with side network output"""
        side_output = self.side_network(original_input)
        return main_output + self.alpha * side_output
