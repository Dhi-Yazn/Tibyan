#!/usr/bin/env python3
"""
LoRA: Low-Rank Adaptation

Standard LoRA implementation for efficient fine-tuning.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, List


class LoRALinear(nn.Module):
    """LoRA Linear Layer"""
    
    def __init__(
        self,
        in_features: int,
        out_features: int,
        rank: int = 16,
        alpha: float = 32.0,
        dropout: float = 0.0,
        use_bias: bool = True
    ):
        super().__init__()
        
        self.in_features = in_features
        self.out_features = out_features
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank
        
        # Original layer (frozen)
        self.weight = nn.Parameter(torch.randn(out_features, in_features) * 0.02)
        
        # LoRA matrices
        self.lora_A = nn.Parameter(torch.randn(rank, in_features) * 0.01)
        self.lora_B = nn.Parameter(torch.zeros(out_features, rank))
        
        if use_bias:
            self.bias = nn.Parameter(torch.zeros(out_features))
        else:
            self.register_parameter('bias', None)
        
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        
        # Disable LoRA by default
        self.active = True
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Original output
        result = F.linear(x, self.weight, self.bias)
        
        # Add LoRA contribution if active
        if self.active and self.training:
            lora_out = x @ self.lora_A.T @ self.lora_B.T
            result = result + lora_out * self.scaling
        
        return result


class LoRAAdapter(nn.Module):
    """LoRA Adapter Manager"""
    
    def __init__(
        self,
        model: nn.Module,
        rank: int = 16,
        alpha: float = 32.0,
        target_modules: List[str] = ['q_proj', 'v_proj', 'k_proj', 'o_proj']
    ):
        super().__init__()
        
        self.model = model
        self.lora_layers = nn.ModuleDict()
        
        # Find and replace target modules
        for name, module in model.named_modules():
            if any(target in name for target in target_modules):
                if isinstance(module, nn.Linear):
                    lora = LoRALinear(
                        module.in_features,
                        module.out_features,
                        rank=rank,
                        alpha=alpha
                    )
                    # Copy weights
                    with torch.no_grad():
                        lora.weight.copy_(module.weight)
                        if module.bias is not None:
                            lora.bias.copy_(module.bias)
                    
                    self.lora_layers[name.replace('.', '_')] = lora
    
    def merge_lora(self):
        """Merge LoRA weights into base weights for inference"""
        for name, lora in self.lora_layers.items():
            # W_new = W + B @ A * scaling
            lora.weight.data += lora.lora_B @ lora.lora_A * lora.scaling
    
    def freeze_base(self):
        """Freeze base model, train only LoRA"""
        for name, param in self.model.named_parameters():
            if 'lora' not in name:
                param.requires_grad = False
