#!/usr/bin/env python3
"""
DoRA: Weight-Decomposed Low-Rank Adaptation

Key innovation: Decompose weights into magnitude and direction,
then apply low-rank updates to direction only.

Better than LoRA for fine-tuning while maintaining efficiency.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class DoRALinear(nn.Module):
    """DoRA Linear Layer"""
    
    def __init__(
        self,
        in_features: int,
        out_features: int,
        rank: int = 16,
        alpha: float = 32.0,
        dropout: float = 0.0,
        use_bias: bool = True
    ):
        super().__init__()
        
        self.in_features = in_features
        self.out_features = out_features
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank
        
        # Original weight (frozen during fine-tuning)
        self.weight = nn.Parameter(torch.randn(out_features, in_features) * 0.02)
        
        # DoRA components
        self.lora_A = nn.Parameter(torch.randn(rank, in_features) * 0.01)
        self.lora_B = nn.Parameter(torch.zeros(out_features, rank))
        
        # Magnitude vector (learnable)
        self.magnitude = nn.Parameter(torch.ones(out_features))
        
        # Bias
        if use_bias:
            self.bias = nn.Parameter(torch.zeros(out_features))
        else:
            self.register_parameter('bias', None)
        
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Original weight direction
        weight_norm = self.weight.norm(dim=1, keepdim=True)
        weight_dir = self.weight / weight_norm
        
        # LoRA update
        lora_update = self.lora_B @ self.lora_A
        
        # Updated direction
        updated_dir = F.normalize(weight_dir + lora_update * self.scaling, dim=1)
        
        # Reconstruct weight with learned magnitude
        weight = self.magnitude.unsqueeze(1) * updated_dir
        
        # Apply
        return F.linear(x, weight, self.bias)


class DoRAAdapter(nn.Module):
    """DoRA Adapter for full model"""
    
    def __init__(self, model: nn.Module, rank: int = 16, alpha: float = 32.0):
        super().__init__()
        
        self.model = model
        self.adapters = nn.ModuleDict()
        
        # Add DoRA to all linear layers
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear) and 'adapter' not in name:
                adapter = DoRALinear(
                    module.in_features,
                    module.out_features,
                    rank=rank,
                    alpha=alpha
                )
                # Copy original weights
                with torch.no_grad():
                    adapter.weight.copy_(module.weight)
                    if module.bias is not None:
                        adapter.bias.copy_(module.bias)
                
                self.adapters[name.replace('.', '_')] = adapter
