#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Models Module
================================================================================
Complete Model Architecture with Progressive Layer Integration

This module contains all model components:
- Hybrid layers (Mamba, Kimi-Linear, MoE++, MLA, etc.)
- All v8.0 techniques preserved
- All v9.0 new techniques integrated
"""

from .tibyan_v9 import TibyanV9Model, TibyanV9ForCausalLM
from .layers import (
    # Mamba layers
    Mamba2SSDLayer,
    Mamba3Layer,
    
    # Attention layers
    KimiDeltaAttention,
    MLAAttention,
    FlashAttentionLayer,
    
    # Recurrent layers
    HGRNLayer,
    
    # Memory layers
    TitansMemoryLayer,
    EpisodicMemoryLayer,
    
    # MoE layers
    MoEPlusPlusLayer,
    DirichletMoELayer,
    
    # Output layers
    DiffusionOutputLayer,
    MultiTokenPredictionHead,
    
    # Hybrid layer
    TibyanV9HybridLayer,
)

__all__ = [
    # Main models
    'TibyanV9Model',
    'TibyanV9ForCausalLM',
    
    # Mamba layers
    'Mamba2SSDLayer',
    'Mamba3Layer',
    
    # Attention layers
    'KimiDeltaAttention',
    'MLAAttention',
    'FlashAttentionLayer',
    
    # Recurrent layers
    'HGRNLayer',
    
    # Memory layers
    'TitansMemoryLayer',
    'EpisodicMemoryLayer',
    
    # MoE layers
    'MoEPlusPlusLayer',
    'DirichletMoELayer',
    
    # Output layers
    'DiffusionOutputLayer',
    'MultiTokenPredictionHead',
    
    # Hybrid layer
    'TibyanV9HybridLayer',
]
