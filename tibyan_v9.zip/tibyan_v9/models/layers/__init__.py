#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Layers Module
================================================================================
All Layer Implementations for Progressive Layer Integration

This module contains ALL layer types:
1. Mamba-2 SSD (State Space Duality)
2. Mamba-3 with Sparse Transition
3. HGRN (Hierarchically Gated Recurrent Networks)
4. Kimi-Linear (Delta Attention)
5. Titans Memory (Neural Long-term Memory)
6. MoE++ (Zero-Computation Experts)
7. MLA (Multi-head Latent Attention)
8. Flash Attention
9. Diffusion Output
10. Episodic Memory

All v8.0 techniques preserved and enhanced.
All v9.0 new techniques integrated.

NO SIMPLIFICATIONS - Full production code.

================================================================================
"""

from .mamba_layers import Mamba2SSDLayer, Mamba3Layer
from .attention_layers import (
    KimiDeltaAttention,
    MLAAttention,
    FlashAttentionLayer,
    GroupedQueryAttention,
)
from .recurrent_layers import HGRNLayer, HGRNBlock
from .memory_layers import TitansMemoryLayer, EpisodicMemoryLayer
from .moe_layers import (
    MoEPlusPlusLayer,
    DirichletMoELayer,
    SEERMoELayer,
    RSMoELayer,
)
from .output_layers import DiffusionOutputLayer, MultiTokenPredictionHead
from .hybrid_layer import TibyanV9HybridLayer
from .embeddings import TibyanEmbeddings, RotaryEmbedding, LongRoPE2

__all__ = [
    # Mamba layers
    'Mamba2SSDLayer',
    'Mamba3Layer',
    
    # Attention layers
    'KimiDeltaAttention',
    'MLAAttention',
    'FlashAttentionLayer',
    'GroupedQueryAttention',
    
    # Recurrent layers
    'HGRNLayer',
    'HGRNBlock',
    
    # Memory layers
    'TitansMemoryLayer',
    'EpisodicMemoryLayer',
    
    # MoE layers
    'MoEPlusPlusLayer',
    'DirichletMoELayer',
    'SEERMoELayer',
    'RSMoELayer',
    
    # Output layers
    'DiffusionOutputLayer',
    'MultiTokenPredictionHead',
    
    # Hybrid
    'TibyanV9HybridLayer',
    
    # Embeddings
    'TibyanEmbeddings',
    'RotaryEmbedding',
    'LongRoPE2',
]
