"""
TIBYAN v9.0 AGI Micro-Engine - DataLoaders
=========================================

Advanced DataLoader implementations:
- Distributed DataLoader
- Streaming DataLoader
- Dynamic batching
- Collate functions
"""

import torch
from torch.utils.data import DataLoader, Dataset, Sampler, BatchSampler
from torch.utils.data.distributed import DistributedSampler
from typing import Optional, List, Dict, Any, Union, Callable, Iterator, Sized
from dataclasses import dataclass
import random
import numpy as np
import logging

logger = logging.getLogger(__name__)


@dataclass
class DataLoaderConfig:
    """Configuration for DataLoader"""
    batch_size: int = 32
    shuffle: bool = True
    num_workers: int = 4
    pin_memory: bool = True
    drop_last: bool = True
    prefetch_factor: int = 2
    persistent_workers: bool = True
    
    # Dynamic batching
    dynamic_batching: bool = False
    max_tokens: int = 8192  # For dynamic batching
    max_batch_size: int = 128
    
    # Distributed
    distributed: bool = False
    world_size: int = 1
    rank: int = 0


def collate_fn(batch: List[Any]) -> Dict[str, torch.Tensor]:
    """
    Default collate function.
    
    Handles DataSample objects and dicts with variable length sequences.
    """
    if not batch:
        return {}
    
    # Handle DataSample objects
    if hasattr(batch[0], 'to_dict'):
        batch = [item.to_dict() for item in batch]
    
    # Stack tensors
    result = {}
    for key in batch[0].keys():
        if isinstance(batch[0][key], torch.Tensor):
            result[key] = torch.stack([item[key] for item in batch])
        elif isinstance(batch[0][key], list):
            result[key] = torch.tensor([item[key] for item in batch])
        else:
            result[key] = [item[key] for item in batch]
    
    return result


def collate_fn_with_padding(
    batch: List[Dict[str, Any]],
    pad_token_id: int = 0,
    max_length: Optional[int] = None
) -> Dict[str, torch.Tensor]:
    """
    Collate function with dynamic padding.
    
    Pads sequences to the longest in the batch.
    """
    if not batch:
        return {}
    
    # Find max length in batch
    if max_length is None:
        max_len = max(
            len(item.get('input_ids', [])) 
            for item in batch
        )
    else:
        max_len = max_length
    
    result = {}
    
    # Process input_ids
    input_ids_list = []
    attention_mask_list = []
    labels_list = []
    
    for item in batch:
        input_ids = item.get('input_ids', [])
        
        # Pad
        pad_length = max_len - len(input_ids)
        padded_input_ids = input_ids + [pad_token_id] * pad_length
        attention_mask = [1] * len(input_ids) + [0] * pad_length
        
        input_ids_list.append(padded_input_ids)
        attention_mask_list.append(attention_mask)
        
        if 'labels' in item:
            labels = item['labels']
            padded_labels = labels + [pad_token_id] * (max_len - len(labels))
            labels_list.append(padded_labels)
    
    result['input_ids'] = torch.tensor(input_ids_list, dtype=torch.long)
    result['attention_mask'] = torch.tensor(attention_mask_list, dtype=torch.long)
    
    if labels_list:
        result['labels'] = torch.tensor(labels_list, dtype=torch.long)
    
    # Copy other fields
    for key in batch[0].keys():
        if key not in ['input_ids', 'attention_mask', 'labels']:
            if isinstance(batch[0][key], torch.Tensor):
                result[key] = torch.stack([item[key] for item in batch])
            else:
                result[key] = [item[key] for item in batch]
    
    return result


class DynamicBatchSampler(Sampler):
    """
    Sampler that creates batches based on total tokens.
    
    Groups samples of similar length together for efficiency.
    """
    
    def __init__(
        self,
        data_source: Dataset,
        max_tokens: int = 8192,
        max_batch_size: int = 128,
        drop_last: bool = False,
        shuffle: bool = True
    ):
        self.data_source = data_source
        self.max_tokens = max_tokens
        self.max_batch_size = max_batch_size
        self.drop_last = drop_last
        self.shuffle = shuffle
        
        # Pre-compute lengths
        self._lengths = self._compute_lengths()
        self._indices = self._sort_by_length()
    
    def _compute_lengths(self) -> List[int]:
        """Compute length of each sample"""
        lengths = []
        for i in range(len(self.data_source)):
            sample = self.data_source[i]
            if hasattr(sample, 'input_ids'):
                lengths.append(len(sample.input_ids))
            elif isinstance(sample, dict):
                lengths.append(len(sample.get('input_ids', [])))
            else:
                lengths.append(1)
        return lengths
    
    def _sort_by_length(self) -> List[List[int]]:
        """Group indices by length buckets"""
        # Create (index, length) pairs
        indexed_lengths = list(enumerate(self._lengths))
        
        # Sort by length
        if self.shuffle:
            random.shuffle(indexed_lengths)
        indexed_lengths.sort(key=lambda x: x[1])
        
        return [[idx for idx, _ in indexed_lengths]]
    
    def __iter__(self) -> Iterator[List[int]]:
        """Yield batches"""
        indices = self._indices[0].copy()
        
        if self.shuffle:
            random.shuffle(indices)
        
        batch = []
        current_tokens = 0
        
        for idx in indices:
            length = self._lengths[idx]
            
            # Check if adding this sample exceeds limits
            if (current_tokens + length > self.max_tokens or 
                len(batch) >= self.max_batch_size):
                
                if batch:
                    yield batch
                batch = [idx]
                current_tokens = length
            else:
                batch.append(idx)
                current_tokens += length
        
        # Yield last batch
        if batch and not self.drop_last:
            yield batch
    
    def __len__(self) -> int:
        """Estimate number of batches"""
        total_samples = len(self.data_source)
        avg_length = sum(self._lengths) / len(self._lengths) if self._lengths else 1
        avg_batch_size = min(self.max_batch_size, self.max_tokens // max(1, int(avg_length)))
        return total_samples // max(1, avg_batch_size)


class DistributedBatchSampler(BatchSampler):
    """
    Distributed batch sampler that ensures each process gets different data.
    """
    
    def __init__(
        self,
        sampler: Sampler,
        batch_size: int,
        drop_last: bool = False,
        rank: int = 0,
        world_size: int = 1
    ):
        super().__init__(sampler, batch_size, drop_last)
        self.rank = rank
        self.world_size = world_size
    
    def __iter__(self) -> Iterator[List[int]]:
        """Yield batches for this rank"""
        for batch in super().__iter__():
            # Each rank takes every world_size-th sample
            yield batch[self.rank::self.world_size]
    
    def __len__(self) -> int:
        base_len = super().__len__()
        return (base_len + self.world_size - 1) // self.world_size


class StreamingDataLoader:
    """
    DataLoader for streaming/iterable datasets.
    
    Features:
    - Works with IterableDataset
    - Supports prefetching
    - Memory efficient
    """
    
    def __init__(
        self,
        dataset: Dataset,
        batch_size: int = 32,
        num_workers: int = 0,
        prefetch_factor: int = 2,
        pin_memory: bool = True,
        collate_fn: Optional[Callable] = None
    ):
        self.dataset = dataset
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.prefetch_factor = prefetch_factor
        self.pin_memory = pin_memory
        self.collate_fn = collate_fn or collate_fn
    
    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        """Iterate through batches"""
        batch = []
        
        for sample in self.dataset:
            batch.append(sample)
            
            if len(batch) >= self.batch_size:
                yield self.collate_fn(batch)
                batch = []
        
        if batch:
            yield self.collate_fn(batch)


class DistributedDataLoader:
    """
    DataLoader wrapper for distributed training.
    
    Automatically handles:
    - Distributed sampling
    - Gradient synchronization
    - Proper shuffling
    """
    
    def __init__(
        self,
        dataset: Dataset,
        batch_size: int = 32,
        shuffle: bool = True,
        num_workers: int = 4,
        pin_memory: bool = True,
        drop_last: bool = True,
        rank: int = 0,
        world_size: int = 1,
        collate_fn: Optional[Callable] = None
    ):
        self.dataset = dataset
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.drop_last = drop_last
        self.rank = rank
        self.world_size = world_size
        self.collate_fn = collate_fn or collate_fn_with_padding
        
        # Create distributed sampler
        self.sampler = DistributedSampler(
            dataset,
            num_replicas=world_size,
            rank=rank,
            shuffle=shuffle,
            drop_last=drop_last
        )
        
        # Create dataloader
        self._dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            sampler=self.sampler,
            num_workers=num_workers,
            pin_memory=pin_memory,
            drop_last=drop_last,
            collate_fn=self.collate_fn
        )
    
    def __iter__(self):
        return iter(self._dataloader)
    
    def __len__(self):
        return len(self._dataloader)
    
    def set_epoch(self, epoch: int):
        """Set epoch for proper shuffling in distributed setting"""
        self.sampler.set_epoch(epoch)


def create_dataloader(
    dataset: Dataset,
    config: Optional[DataLoaderConfig] = None,
    collate_fn: Optional[Callable] = None,
    **kwargs
) -> Union[DataLoader, DistributedDataLoader, StreamingDataLoader]:
    """
    Factory function to create appropriate DataLoader.
    
    Args:
        dataset: Dataset to load
        config: DataLoader configuration
        collate_fn: Optional custom collate function
        **kwargs: Override config values
        
    Returns:
        Configured DataLoader
    """
    if config is None:
        config = DataLoaderConfig(**kwargs)
    
    # Override config with kwargs
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)
    
    # Choose appropriate DataLoader type
    if isinstance(dataset, StreamingDataLoader):
        return StreamingDataLoader(
            dataset,
            batch_size=config.batch_size,
            num_workers=config.num_workers,
            pin_memory=config.pin_memory,
            collate_fn=collate_fn
        )
    
    if config.distributed:
        return DistributedDataLoader(
            dataset,
            batch_size=config.batch_size,
            shuffle=config.shuffle,
            num_workers=config.num_workers,
            pin_memory=config.pin_memory,
            drop_last=config.drop_last,
            rank=config.rank,
            world_size=config.world_size,
            collate_fn=collate_fn or collate_fn_with_padding
        )
    
    if config.dynamic_batching:
        sampler = DynamicBatchSampler(
            dataset,
            max_tokens=config.max_tokens,
            max_batch_size=config.max_batch_size,
            drop_last=config.drop_last,
            shuffle=config.shuffle
        )
        
        return DataLoader(
            dataset,
            batch_sampler=sampler,
            num_workers=config.num_workers,
            pin_memory=config.pin_memory,
            collate_fn=collate_fn or collate_fn_with_padding
        )
    
    return DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=config.shuffle,
        num_workers=config.num_workers,
        pin_memory=config.pin_memory,
        drop_last=config.drop_last,
        prefetch_factor=config.prefetch_factor if config.num_workers > 0 else None,
        persistent_workers=config.persistent_workers if config.num_workers > 0 else False,
        collate_fn=collate_fn or collate_fn_with_padding
    )


def get_batch_size_for_memory(
    available_memory_gb: float,
    model_params_billions: float,
    sequence_length: int,
    hidden_dim: int,
    precision: str = "fp16"
) -> int:
    """
    Estimate optimal batch size based on available memory.
    
    Args:
        available_memory_gb: Available GPU memory in GB
        model_params_billions: Model parameters in billions
        sequence_length: Sequence length
        hidden_dim: Hidden dimension
        precision: Training precision
        
    Returns:
        Recommended batch size
    """
    # Memory per sample (rough estimate)
    bytes_per_param = {"fp32": 4, "fp16": 2, "bf16": 2}[precision]
    
    # Model memory
    model_memory_gb = model_params_billions * bytes_per_param
    
    # Activation memory per sample (rough estimate)
    activation_memory_per_sample_gb = (
        sequence_length * hidden_dim * 4 * bytes_per_param / 1e9
    )
    
    # Gradient memory
    gradient_memory_gb = model_params_billions * bytes_per_param
    
    # Optimizer memory (Adam: 2 states)
    optimizer_memory_gb = model_params_billions * bytes_per_param * 2
    
    # Fixed overhead
    fixed_memory_gb = (
        model_memory_gb + 
        gradient_memory_gb + 
        optimizer_memory_gb
    )
    
    # Available for activations
    available_for_activations_gb = available_memory_gb - fixed_memory_gb
    
    # Batch size
    if activation_memory_per_sample_gb > 0:
        batch_size = int(available_for_activations_gb / activation_memory_per_sample_gb)
        batch_size = max(1, min(batch_size, 128))
    else:
        batch_size = 1
    
    return batch_size
