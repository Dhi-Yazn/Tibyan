"""
TIBYAN v9.0 AGI Micro-Engine - Datasets
======================================

PyTorch Dataset classes for various training scenarios:
- Pretraining dataset
- Supervised fine-tuning (SFT) dataset
- RLHF preference dataset
- Iterable dataset for streaming
"""

import torch
from torch.utils.data import Dataset, IterableDataset
from typing import Optional, List, Dict, Any, Union, Callable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
import json
import random
import numpy as np
import logging

logger = logging.getLogger(__name__)


@dataclass
class DataSample:
    """Container for a single data sample"""
    input_ids: List[int]
    attention_mask: List[int]
    labels: Optional[List[int]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, torch.Tensor]:
        """Convert to dictionary of tensors"""
        result = {
            "input_ids": torch.tensor(self.input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(self.attention_mask, dtype=torch.long),
        }
        if self.labels is not None:
            result["labels"] = torch.tensor(self.labels, dtype=torch.long)
        return result


class TibyanDataset(Dataset):
    """
    Base dataset class for TIBYAN.
    
    Features:
    - Tokenization on-the-fly or pre-tokenized
    - Dynamic padding
    - Text augmentation
    - Multi-format support
    """
    
    def __init__(
        self,
        data: List[Dict[str, Any]],
        tokenizer: Any,
        max_length: int = 2048,
        pad_token_id: int = 0,
        bos_token_id: int = 1,
        eos_token_id: int = 2,
        transform: Optional[Callable] = None
    ):
        """
        Initialize dataset.
        
        Args:
            data: List of data samples (dict with 'text' or 'input_ids')
            tokenizer: Tokenizer for encoding text
            max_length: Maximum sequence length
            pad_token_id: Padding token ID
            bos_token_id: Beginning of sequence token ID
            eos_token_id: End of sequence token ID
            transform: Optional transform function
        """
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.pad_token_id = pad_token_id
        self.bos_token_id = bos_token_id
        self.eos_token_id = eos_token_id
        self.transform = transform
    
    def __len__(self) -> int:
        return len(self.data)
    
    def __getitem__(self, idx: int) -> DataSample:
        """Get a single sample"""
        item = self.data[idx]
        
        # Get or encode input_ids
        if 'input_ids' in item:
            input_ids = item['input_ids']
        elif 'text' in item:
            input_ids = self.tokenizer.encode(
                item['text'],
                add_special_tokens=True,
                max_length=self.max_length,
                truncation=True
            )
        else:
            raise ValueError(f"Item at index {idx} has no 'text' or 'input_ids'")
        
        # Apply transform if any
        if self.transform:
            input_ids = self.transform(input_ids)
        
        # Create attention mask
        attention_mask = [1] * len(input_ids)
        
        # Truncate if needed
        if len(input_ids) > self.max_length:
            input_ids = input_ids[:self.max_length - 1] + [self.eos_token_id]
            attention_mask = attention_mask[:self.max_length]
        
        # Create labels (shift by 1 for causal LM)
        labels = input_ids[1:] + [self.pad_token_id]
        
        return DataSample(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels,
            metadata=item.get('metadata', {})
        )


class PretrainingDataset(TibyanDataset):
    """
    Dataset for language model pretraining.
    
    Features:
    - Packed sequences for efficiency
    - Document separators
    - Dynamic batching
    """
    
    def __init__(
        self,
        data: List[Dict[str, Any]],
        tokenizer: Any,
        max_length: int = 2048,
        pack_sequences: bool = True,
        min_length: int = 32,
        **kwargs
    ):
        super().__init__(data, tokenizer, max_length, **kwargs)
        
        self.pack_sequences = pack_sequences
        self.min_length = min_length
        
        # Pre-pack sequences if enabled
        if pack_sequences:
            self._packed_data = self._pack_sequences()
    
    def _pack_sequences(self) -> List[List[int]]:
        """Pack multiple documents into single sequences"""
        packed = []
        current_seq = [self.bos_token_id]
        
        for item in self.data:
            if 'input_ids' in item:
                ids = item['input_ids']
            elif 'text' in item:
                ids = self.tokenizer.encode(item['text'], add_special_tokens=False)
            else:
                continue
            
            # Add document separator
            ids = ids + [self.eos_token_id, self.bos_token_id]
            
            # Check if fits in current sequence
            if len(current_seq) + len(ids) <= self.max_length:
                current_seq.extend(ids)
            else:
                # Save current sequence
                if len(current_seq) >= self.min_length:
                    packed.append(current_seq)
                
                # Start new sequence
                current_seq = [self.bos_token_id] + ids
        
        # Add last sequence
        if len(current_seq) >= self.min_length:
            packed.append(current_seq)
        
        return packed
    
    def __len__(self) -> int:
        if self.pack_sequences:
            return len(self._packed_data)
        return super().__len__()
    
    def __getitem__(self, idx: int) -> DataSample:
        if self.pack_sequences:
            input_ids = self._packed_data[idx]
            
            # Pad to max_length
            attention_mask = [1] * len(input_ids)
            
            if len(input_ids) < self.max_length:
                pad_length = self.max_length - len(input_ids)
                input_ids = input_ids + [self.pad_token_id] * pad_length
                attention_mask = attention_mask + [0] * pad_length
            
            labels = input_ids[1:] + [self.pad_token_id]
            
            return DataSample(
                input_ids=input_ids,
                attention_mask=attention_mask,
                labels=labels
            )
        
        return super().__getitem__(idx)


class SFTDataset(TibyanDataset):
    """
    Dataset for supervised fine-tuning.
    
    Features:
    - Instruction-response format
    - Chat template support
    - Response-only loss masking
    """
    
    def __init__(
        self,
        data: List[Dict[str, Any]],
        tokenizer: Any,
        max_length: int = 2048,
        instruction_key: str = "instruction",
        input_key: str = "input",
        output_key: str = "output",
        response_only_loss: bool = True,
        chat_template: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize SFT dataset.
        
        Args:
            data: List of samples with instruction/input/output
            tokenizer: Tokenizer
            max_length: Maximum sequence length
            instruction_key: Key for instruction field
            input_key: Key for input field
            output_key: Key for output field
            response_only_loss: Only compute loss on response
            chat_template: Optional chat template string
        """
        super().__init__(data, tokenizer, max_length, **kwargs)
        
        self.instruction_key = instruction_key
        self.input_key = input_key
        self.output_key = output_key
        self.response_only_loss = response_only_loss
        self.chat_template = chat_template
        
        # Preprocess data
        self._processed_data = self._preprocess()
    
    def _preprocess(self) -> List[Dict[str, Any]]:
        """Preprocess all samples"""
        processed = []
        
        for item in self.data:
            # Build prompt
            instruction = item.get(self.instruction_key, "")
            input_text = item.get(self.input_key, "")
            output = item.get(self.output_key, "")
            
            if self.chat_template:
                prompt = self.chat_template.format(
                    instruction=instruction,
                    input=input_text,
                    output=output
                )
            else:
                if input_text:
                    prompt = f"### Instruction:\n{instruction}\n\n### Input:\n{input_text}\n\n### Response:\n{output}"
                else:
                    prompt = f"### Instruction:\n{instruction}\n\n### Response:\n{output}"
            
            # Tokenize
            full_ids = self.tokenizer.encode(
                prompt,
                add_special_tokens=True,
                max_length=self.max_length,
                truncation=True
            )
            
            # Tokenize prompt only for label masking
            if self.response_only_loss:
                if input_text:
                    prompt_only = f"### Instruction:\n{instruction}\n\n### Input:\n{input_text}\n\n### Response:\n"
                else:
                    prompt_only = f"### Instruction:\n{instruction}\n\n### Response:\n"
                
                prompt_ids = self.tokenizer.encode(
                    prompt_only,
                    add_special_tokens=False
                )
                prompt_length = len(prompt_ids)
            else:
                prompt_length = 0
            
            processed.append({
                'input_ids': full_ids,
                'prompt_length': prompt_length,
                'metadata': item.get('metadata', {})
            })
        
        return processed
    
    def __len__(self) -> int:
        return len(self._processed_data)
    
    def __getitem__(self, idx: int) -> DataSample:
        item = self._processed_data[idx]
        input_ids = item['input_ids']
        prompt_length = item['prompt_length']
        
        # Truncate
        if len(input_ids) > self.max_length:
            input_ids = input_ids[:self.max_length]
        
        # Attention mask
        attention_mask = [1] * len(input_ids)
        
        # Labels with masking
        labels = input_ids.copy()
        if self.response_only_loss:
            # Mask prompt portion
            labels[:prompt_length] = [self.pad_token_id] * prompt_length
        
        # Shift labels
        labels = labels[1:] + [self.pad_token_id]
        
        # Pad
        if len(input_ids) < self.max_length:
            pad_length = self.max_length - len(input_ids)
            input_ids = input_ids + [self.pad_token_id] * pad_length
            attention_mask = attention_mask + [0] * pad_length
            labels = labels + [self.pad_token_id] * pad_length
        
        return DataSample(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels,
            metadata=item['metadata']
        )


class PreferenceDataset(Dataset):
    """
    Dataset for RLHF preference learning.
    
    Each sample contains:
    - Prompt
    - Chosen response
    - Rejected response
    """
    
    def __init__(
        self,
        data: List[Dict[str, Any]],
        tokenizer: Any,
        max_length: int = 2048,
        prompt_key: str = "prompt",
        chosen_key: str = "chosen",
        rejected_key: str = "rejected",
    ):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.prompt_key = prompt_key
        self.chosen_key = chosen_key
        self.rejected_key = rejected_key
    
    def __len__(self) -> int:
        return len(self.data)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        
        prompt = item[self.prompt_key]
        chosen = item[self.chosen_key]
        rejected = item[self.rejected_key]
        
        # Tokenize
        chosen_ids = self.tokenizer.encode(
            prompt + chosen,
            add_special_tokens=True,
            max_length=self.max_length,
            truncation=True
        )
        
        rejected_ids = self.tokenizer.encode(
            prompt + rejected,
            add_special_tokens=True,
            max_length=self.max_length,
            truncation=True
        )
        
        # Pad
        def pad_sequence(ids, max_len):
            attention_mask = [1] * len(ids)
            if len(ids) < max_len:
                pad_len = max_len - len(ids)
                ids = ids + [0] * pad_len
                attention_mask = attention_mask + [0] * pad_len
            return ids, attention_mask
        
        chosen_ids, chosen_mask = pad_sequence(chosen_ids, self.max_length)
        rejected_ids, rejected_mask = pad_sequence(rejected_ids, self.max_length)
        
        return {
            "chosen_input_ids": torch.tensor(chosen_ids, dtype=torch.long),
            "chosen_attention_mask": torch.tensor(chosen_mask, dtype=torch.long),
            "rejected_input_ids": torch.tensor(rejected_ids, dtype=torch.long),
            "rejected_attention_mask": torch.tensor(rejected_mask, dtype=torch.long),
        }


class IterableTextDataset(IterableDataset):
    """
    Iterable dataset for streaming large text files.
    
    Features:
    - Memory efficient
    - Supports multiple file formats
    - On-the-fly tokenization
    """
    
    def __init__(
        self,
        file_paths: List[Union[str, Path]],
        tokenizer: Any,
        max_length: int = 2048,
        format: str = "jsonl",  # jsonl, txt, json
        text_key: str = "text",
        buffer_size: int = 1000,
        shuffle: bool = True,
        seed: int = 42
    ):
        self.file_paths = [Path(f) for f in file_paths]
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.format = format
        self.text_key = text_key
        self.buffer_size = buffer_size
        self.shuffle = shuffle
        self.seed = seed
    
    def _iter_files(self) -> Iterator[str]:
        """Iterate through all files and yield text"""
        for file_path in self.file_paths:
            if not file_path.exists():
                continue
            
            if self.format == "jsonl":
                with open(file_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        try:
                            data = json.loads(line)
                            if self.text_key in data:
                                yield data[self.text_key]
                        except json.JSONDecodeError:
                            continue
            
            elif self.format == "txt":
                with open(file_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            yield line
            
            elif self.format == "json":
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        for item in data:
                            if isinstance(item, dict) and self.text_key in item:
                                yield item[self.text_key]
                            elif isinstance(item, str):
                                yield item
    
    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        """Iterate through the dataset"""
        buffer = []
        rng = random.Random(self.seed)
        
        for text in self._iter_files():
            # Tokenize
            input_ids = self.tokenizer.encode(
                text,
                add_special_tokens=True,
                max_length=self.max_length,
                truncation=True
            )
            
            # Create attention mask
            attention_mask = [1] * len(input_ids)
            
            # Pad
            if len(input_ids) < self.max_length:
                pad_length = self.max_length - len(input_ids)
                input_ids = input_ids + [0] * pad_length
                attention_mask = attention_mask + [0] * pad_length
            
            sample = {
                "input_ids": torch.tensor(input_ids, dtype=torch.long),
                "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
                "labels": torch.tensor(input_ids[1:] + [0], dtype=torch.long),
            }
            
            # Add to buffer
            buffer.append(sample)
            
            # Yield from buffer when full
            if len(buffer) >= self.buffer_size:
                if self.shuffle:
                    rng.shuffle(buffer)
                
                for item in buffer:
                    yield item
                
                buffer = []
        
        # Yield remaining items
        if buffer:
            if self.shuffle:
                rng.shuffle(buffer)
            for item in buffer:
                yield item


def load_dataset(
    path: Union[str, Path],
    format: str = "auto",
    **kwargs
) -> List[Dict[str, Any]]:
    """
    Load dataset from file.
    
    Supports:
    - JSONL
    - JSON
    - CSV
    - Parquet
    
    Args:
        path: Path to data file
        format: File format ('auto' to detect)
        **kwargs: Additional arguments
        
    Returns:
        List of data samples
    """
    path = Path(path)
    
    if format == "auto":
        format = path.suffix.lstrip('.')
    
    if format == "jsonl":
        data = []
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return data
    
    elif format == "json":
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else [data]
    
    elif format == "csv":
        import csv
        data = []
        with open(path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                data.append(dict(row))
        return data
    
    elif format in ["parquet", "pq"]:
        import pandas as pd
        df = pd.read_parquet(path)
        return df.to_dict('records')
    
    else:
        raise ValueError(f"Unsupported format: {format}")
