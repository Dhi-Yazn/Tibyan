"""
TIBYAN v9.0 AGI Micro-Engine - Data Scrapers
============================================

Web scraping tools for collecting Arabic training data:
- Arabic Wikipedia scraper
- News article scraper
- General web scraper
- Data cleaning utilities
"""

import re
import json
import time
import logging
import asyncio
import aiohttp
from typing import Optional, List, Dict, Any, Iterator, AsyncIterator
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urljoin, urlparse
from datetime import datetime
import hashlib

logger = logging.getLogger(__name__)


@dataclass
class ScraperConfig:
    """Configuration for web scraping"""
    user_agent: str = "TIBYAN/9.0 (Arabic LLM Research)"
    request_delay: float = 1.0  # Seconds between requests
    timeout: float = 30.0
    max_retries: int = 3
    max_pages: int = 1000
    output_dir: str = "./data/corpus"
    
    # Rate limiting
    requests_per_second: float = 1.0
    burst_limit: int = 5
    
    # Content filtering
    min_content_length: int = 100
    max_content_length: int = 100000
    required_language: str = "ar"


@dataclass
class ScrapedDocument:
    """Container for scraped document"""
    url: str
    title: str
    content: str
    language: str = "ar"
    timestamp: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def doc_id(self) -> str:
        """Generate unique document ID"""
        return hashlib.md5(self.url.encode()).hexdigest()[:12]


class BaseScraper:
    """Base scraper with common functionality"""
    
    def __init__(self, config: Optional[ScraperConfig] = None):
        self.config = config or ScraperConfig()
        self._session: Optional[aiohttp.ClientSession] = None
        self._request_count = 0
        self._last_request_time = 0.0
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.config.timeout)
            self._session = aiohttp.ClientSession(
                headers={"User-Agent": self.config.user_agent},
                timeout=timeout
            )
        return self._session
    
    async def _fetch_url(self, url: str) -> Optional[str]:
        """Fetch URL with rate limiting and retries"""
        session = await self._get_session()
        
        # Rate limiting
        current_time = time.time()
        elapsed = current_time - self._last_request_time
        if elapsed < self.config.request_delay:
            await asyncio.sleep(self.config.request_delay - elapsed)
        
        for attempt in range(self.config.max_retries):
            try:
                self._last_request_time = time.time()
                async with session.get(url) as response:
                    if response.status == 200:
                        return await response.text()
                    elif response.status == 429:  # Rate limited
                        await asyncio.sleep(self.config.request_delay * 2)
                    else:
                        logger.warning(f"HTTP {response.status} for {url}")
                        return None
            except asyncio.TimeoutError:
                logger.warning(f"Timeout for {url} (attempt {attempt + 1})")
            except Exception as e:
                logger.error(f"Error fetching {url}: {e}")
            
            if attempt < self.config.max_retries - 1:
                await asyncio.sleep(self.config.request_delay * (attempt + 1))
        
        return None
    
    async def close(self):
        """Close HTTP session"""
        if self._session and not self._session.closed:
            await self._session.close()
    
    def clean_text(self, text: str) -> str:
        """Clean extracted text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove control characters
        text = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
        
        # Normalize Arabic text
        text = self._normalize_arabic(text)
        
        return text.strip()
    
    def _normalize_arabic(self, text: str) -> str:
        """Normalize Arabic characters"""
        replacements = {
            'أ': 'ا', 'إ': 'ا', 'آ': 'ا',
            'ة': 'ه', 'ى': 'ي',
            '\u0640': '',  # Tatweel
        }
        for old, new in replacements.items():
            text = text.replace(old, new)
        return text
    
    def is_arabic_content(self, text: str, threshold: float = 0.7) -> bool:
        """Check if text is primarily Arabic"""
        arabic_chars = len(re.findall(r'[\u0600-\u06FF]', text))
        total_chars = len(re.findall(r'\w', text))
        
        if total_chars == 0:
            return False
        
        return arabic_chars / total_chars >= threshold


class ArabicWikipediaScraper(BaseScraper):
    """
    Scraper for Arabic Wikipedia articles.
    
    Features:
    - Article extraction with cleaning
    - Category-based crawling
    - Redirect resolution
    - Infobox extraction
    """
    
    WIKI_API = "https://ar.wikipedia.org/w/api.php"
    
    def __init__(self, config: Optional[ScraperConfig] = None):
        super().__init__(config)
        self._visited: set = set()
    
    async def get_article(self, title: str) -> Optional[ScrapedDocument]:
        """Fetch a single Wikipedia article by title"""
        params = {
            "action": "query",
            "format": "json",
            "prop": "extracts|pageprops",
            "explaintext": 1,
            "titles": title,
            "redirects": 1,
        }
        
        url = f"{self.WIKI_API}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
        
        content = await self._fetch_url(url)
        if not content:
            return None
        
        try:
            data = json.loads(content)
            pages = data.get("query", {}).get("pages", {})
            
            for page_id, page in pages.items():
                if page_id == "-1":
                    continue
                
                title = page.get("title", "")
                extract = page.get("extract", "")
                
                if not extract or len(extract) < self.config.min_content_length:
                    continue
                
                return ScrapedDocument(
                    url=f"https://ar.wikipedia.org/wiki/{title.replace(' ', '_')}",
                    title=title,
                    content=self.clean_text(extract),
                    language="ar",
                    timestamp=datetime.now().isoformat(),
                    metadata={"source": "wikipedia", "page_id": page_id}
                )
        except json.JSONDecodeError:
            logger.error(f"Failed to parse JSON for {title}")
        
        return None
    
    async def get_category_articles(
        self,
        category: str,
        limit: int = 100
    ) -> AsyncIterator[ScrapedDocument]:
        """
        Get all articles in a Wikipedia category.
        
        Args:
            category: Category name (without "Category:" prefix)
            limit: Maximum number of articles to fetch
        """
        params = {
            "action": "query",
            "format": "json",
            "list": "categorymembers",
            "cmtitle": f"تصنيف:{category}",
            "cmlimit": min(limit, 500),
            "cmtype": "page",
        }
        
        continue_token = None
        count = 0
        
        while count < limit:
            if continue_token:
                params["cmcontinue"] = continue_token
            
            url = f"{self.WIKI_API}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
            content = await self._fetch_url(url)
            
            if not content:
                break
            
            try:
                data = json.loads(content)
                members = data.get("query", {}).get("categorymembers", [])
                
                for member in members:
                    if count >= limit:
                        break
                    
                    title = member.get("title", "")
                    if title in self._visited:
                        continue
                    
                    self._visited.add(title)
                    doc = await self.get_article(title)
                    
                    if doc:
                        count += 1
                        yield doc
                
                # Check for more pages
                continue_token = data.get("continue", {}).get("cmcontinue")
                if not continue_token:
                    break
                    
            except json.JSONDecodeError:
                logger.error("Failed to parse category response")
                break
    
    async def get_random_articles(
        self,
        count: int = 100
    ) -> AsyncIterator[ScrapedDocument]:
        """Get random Wikipedia articles"""
        for _ in range(count):
            params = {
                "action": "query",
                "format": "json",
                "list": "random",
                "rnnamespace": 0,  # Main namespace
                "rnlimit": 1,
            }
            
            url = f"{self.WIKI_API}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
            content = await self._fetch_url(url)
            
            if not content:
                continue
            
            try:
                data = json.loads(content)
                random_pages = data.get("query", {}).get("random", [])
                
                for page in random_pages:
                    title = page.get("title", "")
                    if title not in self._visited:
                        self._visited.add(title)
                        doc = await self.get_article(title)
                        if doc:
                            yield doc
                            
            except json.JSONDecodeError:
                continue
    
    async def scrape_all_categories(
        self,
        categories: List[str],
        articles_per_category: int = 100
    ) -> List[ScrapedDocument]:
        """Scrape articles from multiple categories"""
        documents = []
        
        for category in categories:
            logger.info(f"Scraping category: {category}")
            async for doc in self.get_category_articles(
                category,
                limit=articles_per_category
            ):
                documents.append(doc)
        
        return documents


class ArabicNewsScraper(BaseScraper):
    """
    Scraper for Arabic news websites.
    
    Features:
    - Multi-site support
    - RSS feed parsing
    - Article extraction
    - Date parsing
    """
    
    # Popular Arabic news sources
    NEWS_SOURCES = {
        "alarabiya": "https://www.alarabiya.net",
        "bbc_arabic": "https://www.bbc.com/arabic",
        "aljazeera": "https://www.aljazeera.net",
        "skynews_arabia": "https://www.skynewsarabia.com",
        "france24_arabic": "https://www.france24.com/ar",
    }
    
    def __init__(
        self,
        config: Optional[ScraperConfig] = None,
        sources: Optional[List[str]] = None
    ):
        super().__init__(config)
        self.sources = sources or list(self.NEWS_SOURCES.keys())
    
    async def extract_article(
        self,
        url: str,
        source: str
    ) -> Optional[ScrapedDocument]:
        """Extract article content from URL"""
        content = await self._fetch_url(url)
        
        if not content:
            return None
        
        try:
            # Simple extraction (in production, use newspaper3k or similar)
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(content, 'html.parser')
            
            # Extract title
            title_tag = soup.find('title') or soup.find('h1')
            title = title_tag.get_text() if title_tag else ""
            
            # Extract main content
            # Look for common article containers
            article = (
                soup.find('article') or
                soup.find('div', class_=re.compile(r'article|content|story')) or
                soup.find('div', id=re.compile(r'article|content'))
            )
            
            if not article:
                return None
            
            # Extract text
            paragraphs = article.find_all('p')
            text = ' '.join(p.get_text() for p in paragraphs)
            
            if len(text) < self.config.min_content_length:
                return None
            
            if not self.is_arabic_content(text):
                return None
            
            return ScrapedDocument(
                url=url,
                title=self.clean_text(title),
                content=self.clean_text(text),
                language="ar",
                timestamp=datetime.now().isoformat(),
                metadata={"source": source, "type": "news"}
            )
            
        except Exception as e:
            logger.error(f"Error extracting article from {url}: {e}")
            return None
    
    async def scrape_source(
        self,
        source_name: str,
        max_articles: int = 50
    ) -> List[ScrapedDocument]:
        """Scrape articles from a news source"""
        if source_name not in self.NEWS_SOURCES:
            logger.warning(f"Unknown source: {source_name}")
            return []
        
        base_url = self.NEWS_SOURCES[source_name]
        documents = []
        
        # Fetch homepage
        content = await self._fetch_url(base_url)
        if not content:
            return documents
        
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(content, 'html.parser')
            
            # Find article links
            links = set()
            for a in soup.find_all('a', href=True):
                href = a['href']
                
                # Make absolute URL
                if not href.startswith('http'):
                    href = urljoin(base_url, href)
                
                # Filter to same domain
                if urlparse(href).netloc == urlparse(base_url).netloc:
                    links.add(href)
            
            # Scrape articles
            for i, link in enumerate(links):
                if i >= max_articles:
                    break
                
                doc = await self.extract_article(link, source_name)
                if doc:
                    documents.append(doc)
                    logger.info(f"Scraped article {len(documents)}: {doc.title[:50]}...")
                    
        except Exception as e:
            logger.error(f"Error scraping {source_name}: {e}")
        
        return documents


class WebScraper(BaseScraper):
    """
    General web scraper for Arabic content.
    
    Features:
    - Crawl-based scraping
    - Content filtering
    - Duplicate detection
    - Domain-based limits
    """
    
    def __init__(self, config: Optional[ScraperConfig] = None):
        super().__init__(config)
        self._visited_urls: set = set()
        self._domain_counts: Dict[str, int] = {}
    
    async def crawl(
        self,
        start_urls: List[str],
        max_pages: int = 1000,
        max_depth: int = 3,
        same_domain_only: bool = True
    ) -> AsyncIterator[ScrapedDocument]:
        """
        Crawl web pages starting from given URLs.
        
        Args:
            start_urls: Starting URLs for crawling
            max_pages: Maximum pages to crawl
            max_depth: Maximum crawl depth
            same_domain_only: Only follow links to same domain
        """
        from bs4 import BeautifulSoup
        
        queue = [(url, 0) for url in start_urls]
        pages_crawled = 0
        
        for url in start_urls:
            self._visited_urls.add(url)
        
        while queue and pages_crawled < max_pages:
            current_url, depth = queue.pop(0)
            
            if depth > max_depth:
                continue
            
            content = await self._fetch_url(current_url)
            if not content:
                continue
            
            try:
                soup = BeautifulSoup(content, 'html.parser')
                
                # Extract title
                title_tag = soup.find('title')
                title = title_tag.get_text() if title_tag else ""
                
                # Extract text content
                # Remove script and style elements
                for element in soup(['script', 'style', 'nav', 'footer', 'header']):
                    element.decompose()
                
                text = soup.get_text(separator=' ', strip=True)
                
                # Filter content
                if (len(text) >= self.config.min_content_length and
                    len(text) <= self.config.max_content_length and
                    self.is_arabic_content(text)):
                    
                    pages_crawled += 1
                    yield ScrapedDocument(
                        url=current_url,
                        title=self.clean_text(title),
                        content=self.clean_text(text),
                        language="ar",
                        timestamp=datetime.now().isoformat(),
                        metadata={"depth": depth}
                    )
                
                # Find more links if not at max depth
                if depth < max_depth:
                    base_domain = urlparse(current_url).netloc
                    
                    for a in soup.find_all('a', href=True):
                        href = a['href']
                        
                        # Make absolute
                        if not href.startswith('http'):
                            href = urljoin(current_url, href)
                        
                        # Skip if visited
                        if href in self._visited_urls:
                            continue
                        
                        # Check domain
                        if same_domain_only:
                            href_domain = urlparse(href).netloc
                            if href_domain != base_domain:
                                continue
                        
                        self._visited_urls.add(href)
                        queue.append((href, depth + 1))
                        
            except Exception as e:
                logger.error(f"Error processing {current_url}: {e}")
    
    def save_documents(
        self,
        documents: List[ScrapedDocument],
        output_dir: str,
        format: str = "jsonl"
    ):
        """Save scraped documents to file"""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        if format == "jsonl":
            output_file = output_path / f"corpus_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
            with open(output_file, 'w', encoding='utf-8') as f:
                for doc in documents:
                    f.write(json.dumps(doc.__dict__, ensure_ascii=False) + '\n')
        
        elif format == "txt":
            output_file = output_path / f"corpus_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            with open(output_file, 'w', encoding='utf-8') as f:
                for doc in documents:
                    f.write(doc.content + '\n\n')
        
        logger.info(f"Saved {len(documents)} documents to {output_file}")


async def scrape_arabic_corpus(
    output_dir: str = "./data/corpus",
    wiki_categories: Optional[List[str]] = None,
    news_sources: Optional[List[str]] = None,
    max_articles: int = 10000
) -> List[ScrapedDocument]:
    """
    Main function to scrape Arabic corpus.
    
    Args:
        output_dir: Output directory for scraped data
        wiki_categories: Wikipedia categories to scrape
        news_sources: News sources to scrape
        max_articles: Maximum total articles
        
    Returns:
        List of scraped documents
    """
    config = ScraperConfig(output_dir=output_dir)
    documents = []
    
    # Default categories
    if wiki_categories is None:
        wiki_categories = [
            "علوم",  # Science
            "تاريخ",  # History
            "جغرافيا",  # Geography
            "أدب",  # Literature
            "تقنية",  # Technology
            "طب",  # Medicine
            "رياضة",  # Sports
            "اقتصاد",  # Economy
        ]
    
    # Scrape Wikipedia
    logger.info("Scraping Wikipedia...")
    wiki_scraper = ArabicWikipediaScraper(config)
    
    articles_per_category = max_articles // (len(wiki_categories) + 1)
    
    for category in wiki_categories:
        if len(documents) >= max_articles:
            break
        
        async for doc in wiki_scraper.get_category_articles(
            category,
            limit=articles_per_category
        ):
            documents.append(doc)
            if len(documents) >= max_articles:
                break
    
    await wiki_scraper.close()
    
    # Scrape news
    if news_sources and len(documents) < max_articles:
        logger.info("Scraping news...")
        news_scraper = ArabicNewsScraper(config, news_sources)
        
        for source in news_sources:
            if len(documents) >= max_articles:
                break
            
            articles = await news_scraper.scrape_source(
                source,
                max_articles=(max_articles - len(documents)) // len(news_sources)
            )
            documents.extend(articles)
        
        await news_scraper.close()
    
    # Save
    scraper = WebScraper(config)
    scraper.save_documents(documents, output_dir)
    
    logger.info(f"Total documents scraped: {len(documents)}")
    return documents
