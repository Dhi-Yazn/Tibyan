"""
TIBYAN v9.0 AGI Micro-Engine - Tokenizers
=========================================

Native tokenizers optimized for Arabic:
- R-BPE (Regex-based BPE) for morphological awareness
- Diacritics-aware tokenization
- Efficient vocabulary management
- Fast encoding/decoding
"""

import torch
from typing import Optional, List, Dict, Tuple, Union, Any
from dataclasses import dataclass, field
from collections import Counter
import re
import json
import os
from pathlib import Path
import regex


# =============================================================================
# SPECIAL TOKENS
# =============================================================================

SPECIAL_TOKENS = {
    "pad": "<|pad|>",
    "bos": "<|begin_of_text|>",
    "eos": "<|end_of_text|>",
    "unk": "<|unknown|>",
    "sep": "<|separator|>",
    "cls": "<|classification|>",
    "mask": "<|mask|>",
    "think_start": "<|think|>",
    "think_end": "<|/think|>",
    "latent_think": "<|latent_think|>",
    "memory_start": "<|memory|>",
    "memory_end": "<|/memory|>",
    "arabic_start": "<|arabic|>",
    "arabic_end": "<|/arabic|>",
    "code_start": "<|code|>",
    "code_end": "<|/code|>",
}

# Arabic-specific patterns
ARABIC_LETTERS = r'\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF'
ARABIC_DIACRITICS = r'\u064B-\u065F\u0670'
ARABIC_PUNCTUATION = r'\u060C\u061B\u061F\u06D4'

# Regex patterns for Arabic text processing
ARABIC_WORD_PATTERN = rf'[{ARABIC_LETTERS}]+'
ARABIC_DIACRITIZED_PATTERN = rf'[{ARABIC_LETTERS}][{ARABIC_DIACRITICS}]*'


@dataclass
class TokenizerConfig:
    """Configuration for tokenizer"""
    vocab_size: int = 64000
    min_frequency: int = 2
    max_token_length: int = 32
    use_diacritics: bool = True
    use_morphological_split: bool = True
    special_tokens: Dict[str, str] = field(default_factory=lambda: SPECIAL_TOKENS)
    
    # BPE settings
    bpe_merges: int = 50000
    bpe_dropout: float = 0.0
    
    # Arabic-specific
    normalize_arabic: bool = True
    split_on_punctuation: bool = True


class BaseTokenizer:
    """Base tokenizer class with common functionality"""
    
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        config: Optional[TokenizerConfig] = None
    ):
        self.config = config or TokenizerConfig()
        self.vocab = vocab or {}
        self.inverse_vocab = {v: k for k, v in self.vocab.items()}
        
        # Initialize special tokens
        self._init_special_tokens()
    
    def _init_special_tokens(self):
        """Initialize special tokens in vocabulary"""
        for name, token in self.config.special_tokens.items():
            if token not in self.vocab:
                idx = len(self.vocab)
                self.vocab[token] = idx
                self.inverse_vocab[idx] = token
    
    @property
    def vocab_size(self) -> int:
        return len(self.vocab)
    
    @property
    def pad_token_id(self) -> int:
        return self.vocab.get(self.config.special_tokens["pad"], 0)
    
    @property
    def bos_token_id(self) -> int:
        return self.vocab.get(self.config.special_tokens["bos"], 1)
    
    @property
    def eos_token_id(self) -> int:
        return self.vocab.get(self.config.special_tokens["eos"], 2)
    
    @property
    def unk_token_id(self) -> int:
        return self.vocab.get(self.config.special_tokens["unk"], 3)
    
    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        padding: bool = False,
        truncation: bool = False
    ) -> List[int]:
        """Encode text to token IDs"""
        raise NotImplementedError
    
    def decode(
        self,
        token_ids: List[int],
        skip_special_tokens: bool = True
    ) -> str:
        """Decode token IDs to text"""
        raise NotImplementedError
    
    def __len__(self) -> int:
        return self.vocab_size
    
    def save(self, path: str):
        """Save tokenizer to file"""
        data = {
            "vocab": self.vocab,
            "config": self.config.__dict__,
        }
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def load(cls, path: str) -> 'BaseTokenizer':
        """Load tokenizer from file"""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        config = TokenizerConfig(**data["config"])
        return cls(vocab=data["vocab"], config=config)


class ArabicTokenizer(BaseTokenizer):
    """
    Arabic-optimized tokenizer with morphological awareness.
    
    Features:
    - Handles Arabic diacritics (تشكيل)
    - Morphological segmentation
    - Normalization of Arabic letters (أ/إ/آ -> ا, etc.)
    - Efficient encoding for Arabic text
    """
    
    # Arabic normalization map
    NORMALIZATION_MAP = {
        'أ': 'ا',
        'إ': 'ا',
        'آ': 'ا',
        'ٱ': 'ا',
        'ة': 'ه',
        'ى': 'ي',
        'ۀ': 'ي',
        'ئ': 'ي',
        'ؤ': 'و',
    }
    
    # Common Arabic prefixes
    ARABIC_PREFIXES = [
        'و', 'ف', 'ب', 'ل', 'ك', 'ال', 'وال', 'فال', 'بال', 'كال',
        'ولل', 'فلل', 'لل', 'أل', 'والت', 'والأ', 'فالت', 'فالأ',
    ]
    
    # Common Arabic suffixes
    ARABIC_SUFFIXES = [
        'ة', 'ه', 'ها', 'هم', 'هن', 'كم', 'كن', 'نا', 'ي', 'ك',
        'ون', 'ين', 'ان', 'ات', 'تى', 'ية', 'يه',
    ]
    
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        config: Optional[TokenizerConfig] = None
    ):
        super().__init__(vocab, config)
        
        # Build morphological patterns
        self._build_patterns()
        
        # Initialize wordpiece/vocab for unknown handling
        self._wordpiece_vocab: Dict[str, int] = {}
        self._wordpiece_id = 0
    
    def _build_patterns(self):
        """Build regex patterns for tokenization"""
        # Pattern for Arabic words (with optional diacritics)
        if self.config.use_diacritics:
            self.arabic_pattern = regex.compile(
                rf'[{ARABIC_LETTERS}][{ARABIC_DIACRITICS}]*(?:[{ARABIC_LETTERS}][{ARABIC_DIACRITICS}]*)*',
                regex.UNICODE
            )
        else:
            self.arabic_pattern = regex.compile(
                rf'[{ARABIC_LETTERS}]+',
                regex.UNICODE
            )
        
        # Pattern for non-Arabic text
        self.non_arabic_pattern = regex.compile(
            rf'[^{ARABIC_LETTERS}{ARABIC_DIACRITICS}]+',
            regex.UNICODE
        )
        
        # Pattern for numbers
        self.number_pattern = regex.compile(r'\d+(?:\.\d+)?')
        
        # Pattern for punctuation
        self.punct_pattern = regex.compile(
            rf'[{ARABIC_PUNCTUATION}!！?？.。,，;；:：\'\'""「」『』【】〔〕〈〉《》\(\)\[\]{{}}]'
        )
    
    def normalize_arabic(self, text: str) -> str:
        """
        Normalize Arabic text.
        
        - Converts different forms of alef to plain alef
        - Converts teh marbuta to heh
        - Normalizes yeh and waw variants
        - Removes tatweel (ـ)
        """
        if not self.config.normalize_arabic:
            return text
        
        result = []
        for char in text:
            if char in self.NORMALIZATION_MAP:
                result.append(self.NORMALIZATION_MAP[char])
            elif char == '\u0640':  # Tatweel
                continue  # Skip
            else:
                result.append(char)
        
        return ''.join(result)
    
    def tokenize_word(self, word: str) -> List[str]:
        """
        Tokenize a single word with morphological awareness.
        
        - Strips common prefixes
        - Strips common suffixes
        - Returns meaningful subwords
        """
        if word in self.vocab:
            return [word]
        
        tokens = []
        remaining = word
        
        # Strip prefixes (longest first)
        if self.config.use_morphological_split:
            for prefix in sorted(self.ARABIC_PREFIXES, key=len, reverse=True):
                if remaining.startswith(prefix) and len(remaining) > len(prefix):
                    if prefix in self.vocab:
                        tokens.append(prefix)
                        remaining = remaining[len(prefix):]
                        break
        
        # Strip suffixes (longest first)
        suffix = ""
        if self.config.use_morphological_split:
            for suf in sorted(self.ARABIC_SUFFIXES, key=len, reverse=True):
                if remaining.endswith(suf) and len(remaining) > len(suf):
                    if suf in self.vocab:
                        suffix = suf
                        remaining = remaining[:-len(suf)]
                        break
        
        # Handle remaining root
        if remaining:
            if remaining in self.vocab:
                tokens.append(remaining)
            else:
                # Character-level fallback
                tokens.extend(self._tokenize_subword(remaining))
        
        # Add suffix
        if suffix:
            tokens.append(suffix)
        
        return tokens if tokens else [word]
    
    def _tokenize_subword(self, word: str) -> List[str]:
        """Tokenize unknown word into subwords"""
        if not word:
            return []
        
        # Try to find in wordpiece vocab
        if word in self._wordpiece_vocab:
            return [word]
        
        # Split into n-grams
        n = min(3, len(word))
        for i in range(len(word) - n + 1):
            ngram = word[i:i+n]
            if ngram in self.vocab:
                return [ngram] + self._tokenize_subword(word[i+n:])
        
        # Character-level fallback
        return [self.config.special_tokens["unk"]]
    
    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        padding: bool = False,
        truncation: bool = False
    ) -> List[int]:
        """Encode text to token IDs"""
        # Normalize
        if self.config.normalize_arabic:
            text = self.normalize_arabic(text)
        
        # Tokenize
        tokens = self._tokenize(text)
        
        # Convert to IDs
        ids = []
        
        if add_special_tokens:
            ids.append(self.bos_token_id)
        
        for token in tokens:
            if token in self.vocab:
                ids.append(self.vocab[token])
            else:
                # Try subword tokenization
                subwords = self.tokenize_word(token)
                for sw in subwords:
                    ids.append(self.vocab.get(sw, self.unk_token_id))
        
        if add_special_tokens:
            ids.append(self.eos_token_id)
        
        # Truncation
        if truncation and max_length is not None and len(ids) > max_length:
            ids = ids[:max_length - 1] + [self.eos_token_id]
        
        # Padding
        if padding and max_length is not None:
            padding_length = max_length - len(ids)
            if padding_length > 0:
                ids.extend([self.pad_token_id] * padding_length)
        
        return ids
    
    def _tokenize(self, text: str) -> List[str]:
        """Core tokenization logic"""
        tokens = []
        
        # Find Arabic words
        last_end = 0
        for match in self.arabic_pattern.finditer(text):
            start, end = match.span()
            
            # Add non-Arabic text before this match
            if start > last_end:
                non_arabic = text[last_end:start]
                tokens.extend(self._tokenize_non_arabic(non_arabic))
            
            # Add Arabic word
            tokens.append(match.group())
            last_end = end
        
        # Handle remaining non-Arabic text
        if last_end < len(text):
            tokens.extend(self._tokenize_non_arabic(text[last_end:]))
        
        return tokens
    
    def _tokenize_non_arabic(self, text: str) -> List[str]:
        """Tokenize non-Arabic text"""
        tokens = []
        
        # Split on whitespace
        for word in text.split():
            # Check if it's a number
            if self.number_pattern.fullmatch(word):
                tokens.append(word)
            # Check for punctuation
            elif self.punct_pattern.search(word):
                # Split into punctuation and non-punctuation
                parts = self.punct_pattern.split(word)
                puncts = self.punct_pattern.findall(word)
                for i, part in enumerate(parts):
                    if part:
                        tokens.append(part)
                    if i < len(puncts):
                        tokens.append(puncts[i])
            else:
                tokens.append(word)
        
        return tokens
    
    def decode(
        self,
        token_ids: List[int],
        skip_special_tokens: bool = True
    ) -> str:
        """Decode token IDs to text"""
        tokens = []
        special_token_values = set(self.config.special_tokens.values())
        
        for idx in token_ids:
            if idx in self.inverse_vocab:
                token = self.inverse_vocab[idx]
                if skip_special_tokens and token in special_token_values:
                    continue
                tokens.append(token)
        
        return ' '.join(tokens)
    
    def train_from_iterator(self, iterator, vocab_size: Optional[int] = None):
        """Train tokenizer from text iterator"""
        vocab_size = vocab_size or self.config.vocab_size
        
        # Count tokens
        counter = Counter()
        for text in iterator:
            if self.config.normalize_arabic:
                text = self.normalize_arabic(text)
            tokens = self._tokenize(text)
            counter.update(tokens)
        
        # Filter by frequency
        filtered = {
            token: count for token, count in counter.items()
            if count >= self.config.min_frequency
        }
        
        # Sort by frequency and select top
        sorted_tokens = sorted(filtered.items(), key=lambda x: -x[1])
        
        # Build vocabulary
        self.vocab = {}
        
        # Add special tokens first
        for name, token in self.config.special_tokens.items():
            self.vocab[token] = len(self.vocab)
        
        # Add tokens from corpus
        for token, _ in sorted_tokens[:vocab_size - len(self.vocab)]:
            self.vocab[token] = len(self.vocab)
        
        self.inverse_vocab = {v: k for k, v in self.vocab.items()}


class RBPETokenizer(BaseTokenizer):
    """
    Regex-based Byte Pair Encoding tokenizer.
    
    Optimized for Arabic with:
    - Regex pre-tokenization
    - BPE merge rules
    - Efficient vocabulary
    """
    
    # Regex pattern for pre-tokenization (similar to GPT-2/GPT-4)
    PRETOKENIZE_PATTERN = regex.compile(
        r"""'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+""",
        regex.IGNORECASE
    )
    
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        config: Optional[TokenizerConfig] = None,
        merges: Optional[List[Tuple[str, str]]] = None
    ):
        super().__init__(vocab, config)
        
        self.merges = merges or []
        self.bpe_ranks = {merge: i for i, merge in enumerate(self.merges)}
        
        # Cache for BPE encoding
        self._cache: Dict[str, Tuple[str, ...]] = {}
    
    def pretokenize(self, text: str) -> List[str]:
        """Pre-tokenize text using regex"""
        return self.PRETOKENIZE_PATTERN.findall(text)
    
    def get_pairs(self, word: Tuple[str, ...]) -> set:
        """Get all adjacent pairs in a word"""
        pairs = set()
        prev_char = word[0]
        for char in word[1:]:
            pairs.add((prev_char, char))
            prev_char = char
        return pairs
    
    def bpe(self, token: str) -> Tuple[str, ...]:
        """Apply BPE to a token"""
        if token in self._cache:
            return self._cache[token]
        
        word = tuple(token)
        pairs = self.get_pairs(word)
        
        if not pairs:
            return tuple(token)
        
        while True:
            # Find the pair with lowest rank
            bigram = min(
                pairs,
                key=lambda pair: self.bpe_ranks.get(pair, float('inf'))
            )
            
            if bigram not in self.bpe_ranks:
                break
            
            first, second = bigram
            new_word = []
            i = 0
            
            while i < len(word):
                try:
                    j = word.index(first, i)
                    new_word.extend(word[i:j])
                    i = j
                except ValueError:
                    new_word.extend(word[i:])
                    break
                
                if (i < len(word) - 1 and 
                    word[i] == first and 
                    word[i + 1] == second):
                    new_word.append(first + second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            
            word = tuple(new_word)
            
            if len(word) == 1:
                break
            
            pairs = self.get_pairs(word)
        
        self._cache[token] = word
        return word
    
    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        padding: bool = False,
        truncation: bool = False
    ) -> List[int]:
        """Encode text to token IDs"""
        ids = []
        
        if add_special_tokens:
            ids.append(self.bos_token_id)
        
        # Pre-tokenize
        pretokens = self.pretokenize(text)
        
        # Apply BPE and convert to IDs
        for pretoken in pretokens:
            bpe_tokens = self.bpe(pretoken)
            for bpe_token in bpe_tokens:
                if bpe_token in self.vocab:
                    ids.append(self.vocab[bpe_token])
                else:
                    ids.append(self.unk_token_id)
        
        if add_special_tokens:
            ids.append(self.eos_token_id)
        
        # Truncation
        if truncation and max_length is not None and len(ids) > max_length:
            ids = ids[:max_length - 1] + [self.eos_token_id]
        
        # Padding
        if padding and max_length is not None:
            padding_length = max_length - len(ids)
            if padding_length > 0:
                ids.extend([self.pad_token_id] * padding_length)
        
        return ids
    
    def decode(
        self,
        token_ids: List[int],
        skip_special_tokens: bool = True
    ) -> str:
        """Decode token IDs to text"""
        special_token_values = set(self.config.special_tokens.values())
        
        tokens = []
        for idx in token_ids:
            if idx in self.inverse_vocab:
                token = self.inverse_vocab[idx]
                if skip_special_tokens and token in special_token_values:
                    continue
                tokens.append(token)
        
        return ''.join(tokens)
    
    def train_from_iterator(
        self,
        iterator,
        vocab_size: Optional[int] = None,
        show_progress: bool = True
    ):
        """Train BPE from text iterator"""
        vocab_size = vocab_size or self.config.vocab_size
        
        # Count pretokens
        counter = Counter()
        for text in iterator:
            pretokens = self.pretokenize(text)
            counter.update(pretokens)
        
        # Initialize vocabulary with characters
        self.vocab = {}
        for name, token in self.config.special_tokens.items():
            self.vocab[token] = len(self.vocab)
        
        # Add all characters
        chars = set()
        for token in counter.keys():
            chars.update(token)
        
        for char in sorted(chars):
            if char not in self.vocab:
                self.vocab[char] = len(self.vocab)
        
        # BPE merges
        self.merges = []
        
        # Convert counter to word frequencies
        word_freqs = {
            tuple(word): freq for word, freq in counter.items()
        }
        
        num_merges = min(
            self.config.bpe_merges,
            vocab_size - len(self.vocab)
        )
        
        for _ in range(num_merges):
            # Find best pair
            pairs = Counter()
            for word, freq in word_freqs.items():
                for i in range(len(word) - 1):
                    pairs[(word[i], word[i + 1])] += freq
            
            if not pairs:
                break
            
            best_pair = max(pairs, key=pairs.get)
            
            # Add merge
            self.merges.append(best_pair)
            merged_token = best_pair[0] + best_pair[1]
            
            if merged_token not in self.vocab:
                self.vocab[merged_token] = len(self.vocab)
            
            # Update word frequencies
            new_word_freqs = {}
            for word, freq in word_freqs.items():
                new_word = self._merge(word, best_pair)
                new_word_freqs[new_word] = freq
            word_freqs = new_word_freqs
        
        self.bpe_ranks = {merge: i for i, merge in enumerate(self.merges)}
        self.inverse_vocab = {v: k for k, v in self.vocab.items()}
    
    def _merge(
        self,
        word: Tuple[str, ...],
        pair: Tuple[str, str]
    ) -> Tuple[str, ...]:
        """Merge all occurrences of a pair in a word"""
        new_word = []
        i = 0
        while i < len(word):
            if (i < len(word) - 1 and 
                word[i] == pair[0] and 
                word[i + 1] == pair[1]):
                new_word.append(pair[0] + pair[1])
                i += 2
            else:
                new_word.append(word[i])
                i += 1
        return tuple(new_word)


class TibyanTokenizer:
    """
    Main tokenizer class for TIBYAN v9.0
    
    Automatically selects the best tokenizer based on configuration.
    """
    
    def __init__(
        self,
        vocab: Optional[Dict[str, int]] = None,
        config: Optional[TokenizerConfig] = None,
        tokenizer_type: str = "arabic",  # arabic, rbpe
        merges: Optional[List[Tuple[str, str]]] = None
    ):
        self.config = config or TokenizerConfig()
        
        if tokenizer_type == "arabic":
            self._tokenizer = ArabicTokenizer(vocab, self.config)
        else:
            self._tokenizer = RBPETokenizer(vocab, self.config, merges)
        
        self.tokenizer_type = tokenizer_type
    
    def __getattr__(self, name):
        """Delegate to internal tokenizer"""
        return getattr(self._tokenizer, name)
    
    def __len__(self) -> int:
        return len(self._tokenizer)
    
    def __call__(
        self,
        text: Union[str, List[str]],
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        padding: bool = False,
        truncation: bool = False,
        return_tensors: Optional[str] = None
    ) -> Union[List[int], Dict[str, Any]]:
        """
        Tokenize text.
        
        Args:
            text: Text or list of texts to tokenize
            add_special_tokens: Add BOS/EOS tokens
            max_length: Maximum sequence length
            padding: Pad to max_length
            truncation: Truncate to max_length
            return_tensors: Return format ('pt' for PyTorch tensors)
            
        Returns:
            Token IDs or dictionary with input_ids
        """
        if isinstance(text, str):
            text = [text]
        
        all_ids = []
        for t in text:
            ids = self._tokenizer.encode(
                t,
                add_special_tokens=add_special_tokens,
                max_length=max_length,
                padding=padding,
                truncation=truncation
            )
            all_ids.append(ids)
        
        if return_tensors == 'pt':
            return {
                "input_ids": torch.tensor(all_ids),
                "attention_mask": torch.ones_like(torch.tensor(all_ids))
            }
        
        return all_ids[0] if len(all_ids) == 1 else all_ids


def create_tokenizer(
    tokenizer_type: str = "arabic",
    vocab_path: Optional[str] = None,
    vocab_size: int = 64000,
    **kwargs
) -> TibyanTokenizer:
    """
    Factory function to create a tokenizer.
    
    Args:
        tokenizer_type: Type of tokenizer ('arabic', 'rbpe')
        vocab_path: Path to vocabulary file
        vocab_size: Target vocabulary size
        **kwargs: Additional arguments
        
    Returns:
        Initialized tokenizer
    """
    config = TokenizerConfig(vocab_size=vocab_size, **kwargs)
    
    if vocab_path:
        tokenizer = TibyanTokenizer.load(vocab_path)
        tokenizer.config = config
    else:
        tokenizer = TibyanTokenizer(
            config=config,
            tokenizer_type=tokenizer_type
        )
    
    return tokenizer
