"""
TIBYAN v9.0 AGI Micro-Engine - Data Module
==========================================

Data handling components:
- Native Arabic tokenizer
- Internet scrapers for training data
- Data processing pipelines
- Dataset classes
"""

from .tokenizer import (
    TibyanTokenizer,
    ArabicTokenizer,
    RBPETokenizer,
    create_tokenizer,
)
from .scraper import (
    ArabicWikipediaScraper,
    WebScraper,
    ArabicNewsScraper,
)
from .dataset import (
    TibyanDataset,
    IterableTextDataset,
    PretrainingDataset,
    SFTDataset,
)
from .dataloader import (
    create_dataloader,
    DistributedDataLoader,
    StreamingDataLoader,
)

__all__ = [
    # Tokenizers
    'TibyanTokenizer',
    'ArabicTokenizer',
    'RBPETokenizer',
    'create_tokenizer',
    # Scrapers
    'ArabicWikipediaScraper',
    'WebScraper',
    'ArabicNewsScraper',
    # Datasets
    'TibyanDataset',
    'IterableTextDataset',
    'PretrainingDataset',
    'SFTDataset',
    # DataLoaders
    'create_dataloader',
    'DistributedDataLoader',
    'StreamingDataLoader',
]
