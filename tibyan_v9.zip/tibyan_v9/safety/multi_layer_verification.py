#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Multi-Layer Verification
================================================================================

Multi-Layer Verification Framework

Combines multiple detection methods for robust hallucination detection:
1. Semantic Entropy
2. Knowledge Grounding
3. Temporal Logic
4. Self-Consistency
5. External Verification

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple, Callable
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class VerificationLevel(Enum):
    """Verification confidence levels"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNVERIFIED = "unverified"


@dataclass
class VerificationResult:
    """Result from verification"""
    is_valid: bool
    confidence: float
    level: VerificationLevel
    scores: Dict[str, float]
    details: Dict[str, Any]
    issues: List[str]


class MultiLayerVerifier(nn.Module):
    """
    Multi-Layer Verification Framework
    
    Combines multiple detection methods with weighted voting:
    
    Layers:
    1. Self-Consistency: Multiple generations agree?
    2. Knowledge Grounding: Grounded in context/knowledge?
    3. Semantic Entropy: Low semantic entropy?
    4. Temporal Logic: Temporally consistent?
    5. External: Passes external validators?
    
    Each layer provides a score, combined with configurable weights.
    """
    
    def __init__(
        self,
        layer_weights: Optional[Dict[str, float]] = None,
        confidence_threshold: float = 0.7,
        device: Optional[torch.device] = None
    ):
        super().__init__()
        
        self.device = device or torch.device('cpu')
        
        # Layer weights
        self.layer_weights = layer_weights or {
            'self_consistency': 0.25,
            'knowledge_grounding': 0.25,
            'semantic_entropy': 0.25,
            'temporal_logic': 0.15,
            'external': 0.10
        }
        
        self.confidence_threshold = confidence_threshold
        
        # Detectors (would be initialized with actual models)
        self.detectors = {}
    
    def register_detector(
        self,
        name: str,
        detector: Callable,
        weight: Optional[float] = None
    ):
        """Register a detector"""
        self.detectors[name] = detector
        if weight is not None:
            self.layer_weights[name] = weight
    
    def verify_self_consistency(
        self,
        outputs: List[str]
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Verify self-consistency across multiple outputs.
        
        Args:
            outputs: Multiple outputs to compare
            
        Returns:
            Tuple of (score, details)
        """
        if len(outputs) < 2:
            return 0.5, {'message': 'Not enough outputs for comparison'}
        
        # Compute pairwise similarity
        similarities = []
        for i in range(len(outputs)):
            for j in range(i + 1, len(outputs)):
                # Simple word overlap similarity
                words1 = set(outputs[i].lower().split())
                words2 = set(outputs[j].lower().split())
                
                intersection = len(words1 & words2)
                union = len(words1 | words2)
                
                sim = intersection / union if union > 0 else 0
                similarities.append(sim)
        
        avg_similarity = sum(similarities) / len(similarities) if similarities else 0.5
        
        return avg_similarity, {
            'pairwise_similarities': similarities,
            'average_similarity': avg_similarity
        }
    
    def verify_knowledge_grounding(
        self,
        output: str,
        context: str
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Verify knowledge grounding.
        
        Args:
            output: Output to verify
            context: Knowledge context
            
        Returns:
            Tuple of (score, details)
        """
        if 'knowledge_grounded' in self.detectors:
            result = self.detectors['knowledge_grounded'](output, context)
            return result.get('grounding_score', 0.5), result
        
        # Fallback: word overlap
        output_words = set(output.lower().split())
        context_words = set(context.lower().split())
        
        overlap = len(output_words & context_words)
        score = overlap / len(output_words) if output_words else 0.5
        
        return score, {'overlap_count': overlap}
    
    def verify_semantic_entropy(
        self,
        outputs: List[str]
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Verify semantic entropy.
        
        Low entropy = high confidence = high score
        
        Args:
            outputs: Multiple outputs
            
        Returns:
            Tuple of (score, details)
        """
        if 'semantic_entropy' in self.detectors:
            result = self.detectors['semantic_entropy'](outputs)
            # Convert entropy to score (low entropy = high score)
            entropy = result.get('entropy', 1.0)
            score = 1.0 - min(entropy / 2.0, 1.0)
            return score, result
        
        # Fallback: clustering-based estimation
        # Group similar outputs
        clusters = self._cluster_outputs(outputs)
        
        # Score based on cluster concentration
        if not clusters:
            return 0.5, {}
        
        largest_cluster_size = max(len(c) for c in clusters)
        score = largest_cluster_size / len(outputs)
        
        return score, {
            'num_clusters': len(clusters),
            'largest_cluster_ratio': score
        }
    
    def verify_temporal_logic(
        self,
        output: str
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Verify temporal consistency.
        
        Args:
            output: Output to verify
            
        Returns:
            Tuple of (score, details)
        """
        if 'temporal_logic' in self.detectors:
            result = self.detectors['temporal_logic'](output)
            score = 1.0 if result.get('is_temporally_consistent', True) else 0.0
            return score, result
        
        # Fallback: check for obvious temporal markers
        temporal_markers = ['before', 'after', 'during', 'when', 'while', 'until', 'since']
        has_temporal = any(marker in output.lower() for marker in temporal_markers)
        
        score = 0.7 if has_temporal else 0.9  # Slightly lower if temporal markers present
        return score, {'has_temporal_markers': has_temporal}
    
    def verify_external(
        self,
        output: str,
        validators: Optional[List[Callable]] = None
    ) -> Tuple[float, Dict[str, Any]]:
        """
        External verification.
        
        Args:
            output: Output to verify
            validators: External validator functions
            
        Returns:
            Tuple of (score, details)
        """
        if not validators:
            return 0.5, {'message': 'No external validators'}
        
        scores = []
        for validator in validators:
            try:
                result = validator(output)
                if isinstance(result, bool):
                    scores.append(1.0 if result else 0.0)
                elif isinstance(result, (int, float)):
                    scores.append(float(result))
            except Exception as e:
                logger.warning(f"External validator failed: {e}")
        
        avg_score = sum(scores) / len(scores) if scores else 0.5
        
        return avg_score, {'validator_scores': scores}
    
    def _cluster_outputs(
        self,
        outputs: List[str],
        similarity_threshold: float = 0.5
    ) -> List[List[int]]:
        """Cluster similar outputs"""
        n = len(outputs)
        if n == 0:
            return []
        
        # Compute pairwise similarity
        similarities = []
        for i in range(n):
            for j in range(i + 1, n):
                words1 = set(outputs[i].lower().split())
                words2 = set(outputs[j].lower().split())
                
                intersection = len(words1 & words2)
                union = len(words1 | words2)
                sim = intersection / union if union > 0 else 0
                
                similarities.append((i, j, sim))
        
        # Simple clustering
        clusters = [{i} for i in range(n)]
        
        for i, j, sim in similarities:
            if sim >= similarity_threshold:
                # Merge clusters
                cluster_i = next((c for c in clusters if i in c), None)
                cluster_j = next((c for c in clusters if j in c), None)
                
                if cluster_i and cluster_j and cluster_i != cluster_j:
                    cluster_i.update(cluster_j)
                    clusters.remove(cluster_j)
        
        return [list(c) for c in clusters]
    
    def verify(
        self,
        output: str,
        context: Optional[str] = None,
        multiple_outputs: Optional[List[str]] = None,
        validators: Optional[List[Callable]] = None
    ) -> VerificationResult:
        """
        Run full multi-layer verification.
        
        Args:
            output: Output to verify
            context: Knowledge context
            multiple_outputs: Multiple outputs for self-consistency
            validators: External validators
            
        Returns:
            VerificationResult
        """
        scores = {}
        details = {}
        issues = []
        
        multiple_outputs = multiple_outputs or [output]
        context = context or ""
        
        # Layer 1: Self-Consistency
        score, detail = self.verify_self_consistency(multiple_outputs)
        scores['self_consistency'] = score
        details['self_consistency'] = detail
        if score < 0.5:
            issues.append(f"Low self-consistency: {score:.2f}")
        
        # Layer 2: Knowledge Grounding
        score, detail = self.verify_knowledge_grounding(output, context)
        scores['knowledge_grounding'] = score
        details['knowledge_grounding'] = detail
        if score < 0.5:
            issues.append(f"Low knowledge grounding: {score:.2f}")
        
        # Layer 3: Semantic Entropy
        score, detail = self.verify_semantic_entropy(multiple_outputs)
        scores['semantic_entropy'] = score
        details['semantic_entropy'] = detail
        if score < 0.5:
            issues.append(f"High semantic entropy: {score:.2f}")
        
        # Layer 4: Temporal Logic
        score, detail = self.verify_temporal_logic(output)
        scores['temporal_logic'] = score
        details['temporal_logic'] = detail
        
        # Layer 5: External
        score, detail = self.verify_external(output, validators)
        scores['external'] = score
        details['external'] = detail
        
        # Compute weighted score
        total_weight = sum(self.layer_weights.values())
        weighted_score = sum(
            scores.get(name, 0.5) * weight
            for name, weight in self.layer_weights.items()
        ) / total_weight
        
        # Determine level
        if weighted_score >= 0.8:
            level = VerificationLevel.HIGH
        elif weighted_score >= 0.6:
            level = VerificationLevel.MEDIUM
        elif weighted_score >= 0.4:
            level = VerificationLevel.LOW
        else:
            level = VerificationLevel.UNVERIFIED
        
        return VerificationResult(
            is_valid=weighted_score >= self.confidence_threshold,
            confidence=weighted_score,
            level=level,
            scores=scores,
            details=details,
            issues=issues
        )
    
    def forward(
        self,
        output: str,
        context: Optional[str] = None,
        multiple_outputs: Optional[List[str]] = None,
        validators: Optional[List[Callable]] = None
    ) -> VerificationResult:
        return self.verify(output, context, multiple_outputs, validators)


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def create_default_verifier(
    confidence_threshold: float = 0.7
) -> MultiLayerVerifier:
    """Create a default multi-layer verifier"""
    return MultiLayerVerifier(
        confidence_threshold=confidence_threshold
    )


def batch_verify(
    outputs: List[str],
    contexts: Optional[List[str]] = None,
    verifier: Optional[MultiLayerVerifier] = None
) -> List[VerificationResult]:
    """Verify multiple outputs"""
    verifier = verifier or create_default_verifier()
    contexts = contexts or [''] * len(outputs)
    
    results = []
    for output, context in zip(outputs, contexts):
        result = verifier.verify(output, context)
        results.append(result)
    
    return results
