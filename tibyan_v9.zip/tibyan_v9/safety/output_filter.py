#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Output Filter
================================================================================

Output Filtering for Safety and Quality Control

Features:
- Content filtering
- PII detection and redaction
- Toxicity filtering
- Quality scoring
- Arabic-specific rules

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
import re


class FilterAction(Enum):
    """Actions to take on filtered content"""
    PASS = "pass"
    WARN = "warn"
    BLOCK = "block"
    REDACT = "redact"
    MODIFY = "modify"


@dataclass
class FilterRule:
    """A single filtering rule"""
    name: str
    pattern: str
    action: FilterAction
    replacement: Optional[str] = None
    severity: float = 1.0
    enabled: bool = True


@dataclass
class FilterResult:
    """Result of filtering"""
    original: str
    filtered: str
    action: FilterAction
    matched_rules: List[str]
    scores: Dict[str, float]
    warnings: List[str]


class OutputFilter(nn.Module):
    """
    Output Filter for Safety and Quality
    
    Components:
    1. Rule-based filtering
    2. ML-based content classification
    3. PII detection
    4. Quality scoring
    5. Arabic-specific handling
    """
    
    def __init__(
        self,
        hidden_dim: int = 768,
        device: Optional[torch.device] = None
    ):
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.device = device or torch.device('cpu')
        
        # Default rules
        self.rules: List[FilterRule] = []
        self._init_default_rules()
        
        # Content classifier
        self.content_classifier = nn.Sequential(
            nn.Linear(hidden_dim, 256),
            nn.GELU(),
            nn.Linear(256, 4)  # safe, toxic, pii, low_quality
        ).to(self.device)
        
        # PII patterns
        self.pii_patterns = {
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'phone': r'\b(?:\+?1[-.\s]?)?(?:\(?[0-9]{3}\)?[-.\s]?)?[0-9]{3}[-.\s]?[0-9]{4}\b',
            'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
            'credit_card': r'\b(?:\d{4}[-.\s]?){3}\d{4}\b',
            'ip_address': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            'arabic_phone': r'\b(?:\+966|0)?5[0-9]{8}\b'
        }
        
        # Toxicity patterns (sample)
        self.toxicity_patterns = [
            r'\b(?:damn|hell|stupid|idiot)\b',  # English
            # Arabic patterns would be added in production
        ]
    
    def _init_default_rules(self):
        """Initialize default filtering rules"""
        # PII rules
        self.add_rule(FilterRule(
            name="email_redact",
            pattern=self.pii_patterns['email'],
            action=FilterAction.REDACT,
            replacement="[EMAIL]",
            severity=0.8
        ))
        
        self.add_rule(FilterRule(
            name="phone_redact",
            pattern=self.pii_patterns['phone'],
            action=FilterAction.REDACT,
            replacement="[PHONE]",
            severity=0.8
        ))
        
        # Toxicity rules
        for pattern in self.toxicity_patterns:
            self.add_rule(FilterRule(
                name=f"toxic_{hash(pattern)}",
                pattern=pattern,
                action=FilterAction.WARN,
                severity=0.5
            ))
    
    def add_rule(
        self,
        rule: FilterRule
    ):
        """Add a filtering rule"""
        self.rules.append(rule)
    
    def remove_rule(
        self,
        name: str
    ):
        """Remove a filtering rule"""
        self.rules = [r for r in self.rules if r.name != name]
    
    def detect_pii(
        self,
        text: str
    ) -> Dict[str, List[Tuple[str, int, int]]]:
        """
        Detect PII in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary of PII type -> list of (match, start, end)
        """
        detected = {}
        
        for pii_type, pattern in self.pii_patterns.items():
            matches = []
            for match in re.finditer(pattern, text):
                matches.append((match.group(), match.start(), match.end()))
            
            if matches:
                detected[pii_type] = matches
        
        return detected
    
    def redact_pii(
        self,
        text: str,
        replacements: Optional[Dict[str, str]] = None
    ) -> Tuple[str, List[str]]:
        """
        Redact PII from text.
        
        Args:
            text: Text to redact
            replacements: Custom replacements per type
            
        Returns:
            Tuple of (redacted_text, list_of_redactions)
        """
        replacements = replacements or {
            'email': '[EMAIL]',
            'phone': '[PHONE]',
            'ssn': '[SSN]',
            'credit_card': '[CARD]',
            'ip_address': '[IP]',
            'arabic_phone': '[PHONE]'
        }
        
        redacted = text
        redaction_log = []
        
        detected = self.detect_pii(text)
        
        for pii_type, matches in detected.items():
            replacement = replacements.get(pii_type, '[REDACTED]')
            
            for match_text, start, end in matches:
                redacted = redacted[:start] + replacement + redacted[end:]
                redaction_log.append(f"Redacted {pii_type}: {match_text[:3]}...")
        
        return redacted, redaction_log
    
    def detect_toxicity(
        self,
        text: str
    ) -> Tuple[float, List[str]]:
        """
        Detect toxicity in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Tuple of (toxicity_score, matched_patterns)
        """
        matches = []
        
        for pattern in self.toxicity_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                matches.append(pattern)
        
        score = min(len(matches) * 0.3, 1.0)
        
        return score, matches
    
    def check_quality(
        self,
        text: str
    ) -> Dict[str, float]:
        """
        Check output quality.
        
        Args:
            text: Text to analyze
            
        Returns:
            Quality metrics
        """
        metrics = {}
        
        # Length check
        word_count = len(text.split())
        metrics['length_score'] = min(word_count / 50, 1.0)
        
        # Repetition check
        words = text.split()
        if len(words) > 0:
            unique_ratio = len(set(words)) / len(words)
            metrics['uniqueness_score'] = unique_ratio
        else:
            metrics['uniqueness_score'] = 0.0
        
        # Coherence (simple)
        sentences = text.split('.')
        if len(sentences) > 1:
            metrics['coherence_score'] = 0.7  # Placeholder
        else:
            metrics['coherence_score'] = 0.5
        
        # Overall quality
        metrics['overall_quality'] = (
            metrics['length_score'] * 0.3 +
            metrics['uniqueness_score'] * 0.4 +
            metrics['coherence_score'] * 0.3
        )
        
        return metrics
    
    def apply_rules(
        self,
        text: str
    ) -> Tuple[str, List[str], FilterAction]:
        """
        Apply all filtering rules.
        
        Args:
            text: Text to filter
            
        Returns:
            Tuple of (filtered_text, matched_rules, action)
        """
        filtered = text
        matched_rules = []
        max_severity = 0.0
        
        for rule in self.rules:
            if not rule.enabled:
                continue
            
            pattern = re.compile(rule.pattern, re.IGNORECASE)
            
            if pattern.search(filtered):
                matched_rules.append(rule.name)
                max_severity = max(max_severity, rule.severity)
                
                if rule.action == FilterAction.REDACT and rule.replacement:
                    filtered = pattern.sub(rule.replacement, filtered)
        
        # Determine action
        if max_severity >= 0.9:
            action = FilterAction.BLOCK
        elif max_severity >= 0.7:
            action = FilterAction.REDACT
        elif max_severity >= 0.5:
            action = FilterAction.WARN
        else:
            action = FilterAction.PASS
        
        return filtered, matched_rules, action
    
    def filter(
        self,
        text: str,
        check_pii: bool = True,
        check_toxicity: bool = True,
        check_quality: bool = True
    ) -> FilterResult:
        """
        Full filtering pipeline.
        
        Args:
            text: Text to filter
            check_pii: Whether to check for PII
            check_toxicity: Whether to check for toxicity
            check_quality: Whether to check quality
            
        Returns:
            FilterResult
        """
        original = text
        filtered = text
        warnings = []
        scores = {}
        
        # Apply rules
        filtered, matched_rules, rule_action = self.apply_rules(filtered)
        
        # PII check
        if check_pii:
            filtered, redactions = self.redact_pii(filtered)
            warnings.extend(redactions)
        
        # Toxicity check
        if check_toxicity:
            tox_score, tox_matches = self.detect_toxicity(original)
            scores['toxicity'] = tox_score
            if tox_score > 0.5:
                warnings.append(f"High toxicity detected: {tox_score:.2f}")
        
        # Quality check
        if check_quality:
            quality = self.check_quality(filtered)
            scores.update(quality)
            
            if quality['overall_quality'] < 0.5:
                warnings.append(f"Low quality score: {quality['overall_quality']:.2f}")
        
        # Determine final action
        if rule_action == FilterAction.BLOCK:
            action = FilterAction.BLOCK
        elif matched_rules or warnings:
            action = FilterAction.WARN
        else:
            action = FilterAction.PASS
        
        return FilterResult(
            original=original,
            filtered=filtered,
            action=action,
            matched_rules=matched_rules,
            scores=scores,
            warnings=warnings
        )
    
    def forward(
        self,
        text: str,
        check_pii: bool = True,
        check_toxicity: bool = True,
        check_quality: bool = True
    ) -> FilterResult:
        return self.filter(text, check_pii, check_toxicity, check_quality)


# =============================================================================
# ARABIC OUTPUT FILTER
# =============================================================================

class ArabicOutputFilter(OutputFilter):
    """
    Arabic-specific Output Filter
    
    Additional handling for:
    - Arabic diacritics
    - Arabic PII patterns
    - Arabic profanity
    - Arabic cultural sensitivity
    """
    
    def __init__(
        self,
        hidden_dim: int = 768,
        device: Optional[torch.device] = None
    ):
        super().__init__(hidden_dim, device)
        
        # Arabic-specific patterns
        self.arabic_patterns = {
            # Arabic phone numbers
            'arabic_phone': r'[\u0660-\u0669]{10,}',
            
            # Arabic ID numbers
            'arabic_id': r'[\u0660-\u0669]{10}',
            
            # Arabic email (with Arabic text)
            'arabic_email': r'[\u0600-\u06FF]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        }
        
        # Add Arabic rules
        self._add_arabic_rules()
    
    def _add_arabic_rules(self):
        """Add Arabic-specific filtering rules"""
        for name, pattern in self.arabic_patterns.items():
            self.add_rule(FilterRule(
                name=f"arabic_{name}",
                pattern=pattern,
                action=FilterAction.REDACT,
                replacement=f"[{name.upper()}]",
                severity=0.7
            ))
    
    def normalize_arabic(
        self,
        text: str
    ) -> str:
        """Normalize Arabic text for processing"""
        # Remove diacritics
        diacritics = 'ًٌٍَُِّْـ'
        for char in diacritics:
            text = text.replace(char, '')
        
        return text
    
    def filter(
        self,
        text: str,
        check_pii: bool = True,
        check_toxicity: bool = True,
        check_quality: bool = True
    ) -> FilterResult:
        """Enhanced filter with Arabic handling"""
        # Check if text contains Arabic
        has_arabic = any('\u0600' <= char <= '\u06FF' for char in text)
        
        if has_arabic:
            # Normalize for checking
            normalized = self.normalize_arabic(text)
        else:
            normalized = text
        
        # Run standard filter
        result = super().filter(
            normalized if has_arabic else text,
            check_pii,
            check_toxicity,
            check_quality
        )
        
        # Restore original if we normalized
        if has_arabic:
            result.original = text
        
        return result
