#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Safety Module
================================================================================
Complete Safety System with Anti-Hallucination and Alignment:

From v8.0 (Preserved):
- Semantic Entropy Detection (Nature 2025)
- Knowledge-Grounded Detection
- Temporal-Logic-Based Detection
- Multi-Layer Verification
- Steering Vectors

New in v9.0:
- Enhanced semantic clustering
- Arabic-specific safety checks
- Contextual consistency verification

NO SIMPLIFICATIONS - Full production code.

================================================================================
"""

from .semantic_entropy import (
    SemanticEntropyDetector,
    SemanticClusterer,
    EntropyConfig
)
from .knowledge_grounded import (
    KnowledgeGroundedDetector,
    FactChecker
)
from .temporal_logic import (
    TemporalLogicDetector,
    ConsistencyChecker
)
from .multi_layer_verification import (
    MultiLayerVerifier,
    VerificationResult
)
from .steering_vectors import (
    SteeringVectorController,
    SteeringConfig
)
from .output_filter import (
    OutputFilter,
    FilterRule
)

__all__ = [
    # Semantic Entropy
    'SemanticEntropyDetector',
    'SemanticClusterer',
    'EntropyConfig',
    
    # Knowledge Grounded
    'KnowledgeGroundedDetector',
    'FactChecker',
    
    # Temporal Logic
    'TemporalLogicDetector',
    'ConsistencyChecker',
    
    # Multi-Layer Verification
    'MultiLayerVerifier',
    'VerificationResult',
    
    # Steering Vectors
    'SteeringVectorController',
    'SteeringConfig',
    
    # Output Filter
    'OutputFilter',
    'FilterRule',
]
