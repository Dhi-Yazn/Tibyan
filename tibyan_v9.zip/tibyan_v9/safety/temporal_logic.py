#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Temporal Logic Detection
================================================================================

Temporal-Logic-Based Hallucination Detection

Checks for temporal inconsistencies in outputs:
- Contradictions across time
- Impossible sequences
- Circular references

================================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Dict, Any, List, Tuple, Set
from dataclasses import dataclass
import re
from collections import defaultdict


@dataclass
class TemporalEvent:
    """Temporal event representation"""
    text: str
    time_reference: Optional[str]
    time_value: Optional[float]
    event_type: str  # before, after, during, simultaneous


class TemporalLogicDetector(nn.Module):
    """
    Temporal Logic-Based Hallucination Detection
    
    Detects:
    1. Temporal contradictions
    2. Impossible sequences
    3. Circular references
    4. Anachronisms
    """
    
    def __init__(
        self,
        consistency_threshold: float = 0.8,
        device: Optional[torch.device] = None
    ):
        super().__init__()
        
        self.consistency_threshold = consistency_threshold
        self.device = device or torch.device('cpu')
        
        # Temporal patterns
        self.temporal_patterns = {
            'before': r'before\s+(.+?)(?:\s|$|\.|,)',
            'after': r'after\s+(.+?)(?:\s|$|\.|,)',
            'during': r'during\s+(.+?)(?:\s|$|\.|,)',
            'when': r'when\s+(.+?)(?:\s|$|\.|,)',
            'while': r'while\s+(.+?)(?:\s|$|\.|,)',
            'until': r'until\s+(.+?)(?:\s|$|\.|,)',
            'since': r'since\s+(.+?)(?:\s|$|\.|,)'
        }
        
        # Time expressions
        self.time_expressions = {
            'years': r'(\d{4})',
            'months': r'(January|February|March|April|May|June|July|August|September|October|November|December)',
            'relative': r'(yesterday|today|tomorrow|last\s+\w+|next\s+\w+|ago|later|earlier)'
        }
    
    def extract_temporal_events(
        self,
        text: str
    ) -> List[TemporalEvent]:
        """
        Extract temporal events from text.
        
        Args:
            text: Input text
            
        Returns:
            List of temporal events
        """
        events = []
        
        # Extract temporal relations
        for rel_type, pattern in self.temporal_patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                events.append(TemporalEvent(
                    text=match.group(0),
                    time_reference=match.group(1),
                    time_value=None,
                    event_type=rel_type
                ))
        
        # Extract time expressions
        for time_type, pattern in self.time_expressions.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                events.append(TemporalEvent(
                    text=match.group(0),
                    time_reference=None,
                    time_value=None,
                    event_type=time_type
                ))
        
        return events
    
    def check_consistency(
        self,
        events: List[TemporalEvent]
    ) -> Tuple[bool, List[str]]:
        """
        Check temporal consistency of events.
        
        Args:
            events: List of temporal events
            
        Returns:
            Tuple of (is_consistent, issues)
        """
        issues = []
        
        # Check for obvious contradictions
        for i, event1 in enumerate(events):
            for event2 in events[i+1:]:
                # Check for before/after contradictions
                if (event1.event_type == 'before' and event2.event_type == 'after' and
                    event1.time_reference == event2.time_reference):
                    issues.append(f"Contradiction: '{event1.text}' vs '{event2.text}'")
        
        is_consistent = len(issues) == 0
        
        return is_consistent, issues
    
    def detect_temporal_hallucination(
        self,
        text: str,
        context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Detect temporal inconsistencies.
        
        Args:
            text: Text to analyze
            context: Optional context for comparison
            
        Returns:
            Detection result
        """
        # Extract events from text
        text_events = self.extract_temporal_events(text)
        
        # Check internal consistency
        is_consistent, issues = self.check_consistency(text_events)
        
        # Check against context if provided
        context_issues = []
        if context:
            context_events = self.extract_temporal_events(context)
            
            # Cross-check
            for text_event in text_events:
                for context_event in context_events:
                    if self._events_contradict(text_event, context_event):
                        context_issues.append(
                            f"Text '{text_event.text}' contradicts context '{context_event.text}'"
                        )
        
        all_issues = issues + context_issues
        
        return {
            'text': text,
            'is_temporally_consistent': len(all_issues) == 0,
            'is_hallucination': len(all_issues) > 0,
            'confidence': 1.0 - len(all_issues) * 0.2,
            'events': [{'text': e.text, 'type': e.event_type} for e in text_events],
            'issues': all_issues
        }
    
    def _events_contradict(
        self,
        event1: TemporalEvent,
        event2: TemporalEvent
    ) -> bool:
        """Check if two events contradict"""
        # Simplified contradiction check
        contradictory_pairs = [
            ('before', 'after'),
            ('after', 'before')
        ]
        
        if (event1.event_type, event2.event_type) in contradictory_pairs:
            if event1.time_reference and event2.time_reference:
                return event1.time_reference.lower() == event2.time_reference.lower()
        
        return False
    
    def forward(
        self,
        text: str,
        context: Optional[str] = None
    ) -> Dict[str, Any]:
        return self.detect_temporal_hallucination(text, context)


class ConsistencyChecker(nn.Module):
    """
    General Consistency Checker
    
    Checks for various types of inconsistencies:
    - Logical contradictions
    - Entity state changes
    - Numerical inconsistencies
    """
    
    def __init__(
        self,
        hidden_dim: int = 256,
        device: Optional[torch.device] = None
    ):
        super().__init__()
        
        self.hidden_dim = hidden_dim
        self.device = device or torch.device('cpu')
        
        # Contradiction detector
        self.contradiction_scorer = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        ).to(self.device)
    
    def check_numerical_consistency(
        self,
        statements: List[str]
    ) -> Tuple[bool, List[str]]:
        """Check numerical consistency"""
        issues = []
        
        # Extract numbers from statements
        numbers = {}
        for i, stmt in enumerate(statements):
            nums = re.findall(r'\d+(?:\.\d+)?', stmt)
            for num in nums:
                if num in numbers:
                    if i != numbers[num]:
                        issues.append(f"Number {num} appears in multiple contexts")
                numbers[num] = i
        
        return len(issues) == 0, issues
    
    def check_entity_consistency(
        self,
        statements: List[str]
    ) -> Tuple[bool, List[str]]:
        """Check entity state consistency"""
        issues = []
        
        # Track entity states
        entity_states = defaultdict(list)
        
        for stmt in statements:
            # Extract entities and their states (simplified)
            words = stmt.split()
            for word in words:
                if word[0].isupper():  # Potential entity
                    entity_states[word].append(stmt)
        
        # Check for contradictions
        for entity, states in entity_states.items():
            if len(states) > 1:
                # Check if states are contradictory
                # Simplified: just check for negation
                has_positive = any('not' not in s.lower() for s in states)
                has_negative = any('not' in s.lower() for s in states)
                
                if has_positive and has_negative:
                    issues.append(f"Entity '{entity}' has contradictory states")
        
        return len(issues) == 0, issues
    
    def check_all(
        self,
        text: str
    ) -> Dict[str, Any]:
        """Run all consistency checks"""
        # Split into statements
        statements = re.split(r'[.!?\n]+', text)
        statements = [s.strip() for s in statements if s.strip()]
        
        # Run checks
        num_ok, num_issues = self.check_numerical_consistency(statements)
        entity_ok, entity_issues = self.check_entity_consistency(statements)
        
        all_issues = num_issues + entity_issues
        
        return {
            'is_consistent': len(all_issues) == 0,
            'numerical_issues': num_issues,
            'entity_issues': entity_issues,
            'all_issues': all_issues
        }
    
    def forward(
        self,
        text: str
    ) -> Dict[str, Any]:
        return self.check_all(text)
