#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - API Server
================================================================================

REST API and WebSocket server for TIBYAN v9.0:

Features:
- REST endpoints for generation
- WebSocket streaming
- OpenAI-compatible API
- Batch processing
- Health monitoring

Usage:
    from tibyan_v9.api import create_app
    
    app = create_app()
    app.run(host="0.0.0.0", port=8000)

NO SIMPLIFICATIONS - Full production code.

================================================================================
"""

import json
import time
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
import asyncio

logger = logging.getLogger(__name__)


# =============================================================================
# SERVER CONFIGURATION
# =============================================================================

@dataclass
class ServerConfig:
    """Server configuration"""
    
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    
    # CORS
    cors_origins: List[str] = None
    
    # Rate limiting
    rate_limit_requests: int = 100
    rate_limit_window: int = 60  # seconds
    
    # Timeout
    request_timeout: int = 120
    generation_timeout: int = 60
    
    # Model
    model_name: str = "tibyan-v9"
    model_path: Optional[str] = None
    
    # Logging
    log_level: str = "INFO"
    log_requests: bool = True
    
    def __post_init__(self):
        if self.cors_origins is None:
            self.cors_origins = ["*"]


# =============================================================================
# FASTAPI APP FACTORY
# =============================================================================

def create_app(config: Optional[ServerConfig] = None):
    """
    Create FastAPI application.
    
    Args:
        config: Server configuration
        
    Returns:
        FastAPI app
    """
    config = config or ServerConfig()
    
    try:
        from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
        from fastapi.middleware.cors import CORSMiddleware
        from fastapi.responses import StreamingResponse, JSONResponse
        from pydantic import BaseModel
    except ImportError:
        logger.warning("FastAPI not installed. Using mock app.")
        return MockApp(config)
    
    # Import API
    from .main import TibyanAPI, GenerationConfig, ChatSession
    
    # Create app
    app = FastAPI(
        title="TIBYAN v9.0 API",
        description="Arabic AGI Micro-Engine API",
        version="9.0.0"
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Initialize API
    api = TibyanAPI()
    
    # Request/Response models
    class GenerateRequest(BaseModel):
        prompt: str
        max_new_tokens: int = 512
        temperature: float = 0.7
        top_k: int = 50
        top_p: float = 0.95
        preset: Optional[str] = None
        stream: bool = False
    
    class GenerateResponse(BaseModel):
        text: str
        num_tokens: int
        generation_time: float
        tokens_per_second: float
        is_hallucination: Optional[bool] = None
        confidence: Optional[float] = None
    
    class ChatRequest(BaseModel):
        message: str
        history: Optional[List[Dict[str, str]]] = None
        system_prompt: Optional[str] = None
        max_new_tokens: int = 512
        temperature: float = 0.7
    
    class ChatResponse(BaseModel):
        response: str
        generation_time: float
    
    class HealthResponse(BaseModel):
        status: str
        model_loaded: bool
        device: str
        version: str
    
    # Routes
    @app.get("/", response_class=JSONResponse)
    async def root():
        return {"message": "TIBYAN v9.0 API", "version": "9.0.0"}
    
    @app.get("/health", response_model=HealthResponse)
    async def health():
        import torch
        return HealthResponse(
            status="healthy",
            model_loaded=api.model is not None,
            device=str(api.device),
            version="9.0.0"
        )
    
    @app.post("/generate", response_model=GenerateResponse)
    async def generate(request: GenerateRequest):
        try:
            config = GenerationConfig(
                max_new_tokens=request.max_new_tokens,
                temperature=request.temperature,
                top_k=request.top_k,
                top_p=request.top_p
            )
            
            result = api.generate(request.prompt, config, preset=request.preset)
            
            return GenerateResponse(
                text=result.text,
                num_tokens=result.num_tokens,
                generation_time=result.generation_time,
                tokens_per_second=result.tokens_per_second,
                is_hallucination=result.is_hallucination,
                confidence=result.confidence
            )
        
        except Exception as e:
            logger.error(f"Generation error: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.post("/generate/stream")
    async def generate_stream(request: GenerateRequest):
        async def stream():
            config = GenerationConfig(
                max_new_tokens=request.max_new_tokens,
                temperature=request.temperature,
                top_k=request.top_k,
                top_p=request.top_p
            )
            
            for token in api.generate_stream(request.prompt, config):
                data = json.dumps({"token": token}, ensure_ascii=False)
                yield f"data: {data}\n\n"
            
            yield f"data: {json.dumps({'done': True})}\n\n"
        
        return StreamingResponse(
            stream(),
            media_type="text/event-stream"
        )
    
    @app.post("/chat", response_model=ChatResponse)
    async def chat(request: ChatRequest):
        try:
            response = api.chat(
                message=request.message,
                history=request.history,
                system_prompt=request.system_prompt
            )
            
            return ChatResponse(
                response=response,
                generation_time=0.0  # Would track actual time
            )
        
        except Exception as e:
            logger.error(f"Chat error: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        await websocket.accept()
        
        try:
            while True:
                data = await websocket.receive_text()
                request = json.loads(data)
                
                if request.get('type') == 'generate':
                    prompt = request.get('prompt', '')
                    config = GenerationConfig(
                        max_new_tokens=request.get('max_new_tokens', 512),
                        temperature=request.get('temperature', 0.7)
                    )
                    
                    for token in api.generate_stream(prompt, config):
                        await websocket.send_json({
                            'type': 'token',
                            'content': token
                        })
                    
                    await websocket.send_json({
                        'type': 'complete'
                    })
                
                elif request.get('type') == 'ping':
                    await websocket.send_json({'type': 'pong'})
        
        except WebSocketDisconnect:
            logger.info("WebSocket disconnected")
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
    
    @app.get("/stats")
    async def stats():
        return api.get_stats()
    
    @app.post("/clear_memory")
    async def clear_memory():
        api.clear_memory()
        return {"status": "ok"}
    
    # Store API reference
    app.state.api = api
    
    return app


# =============================================================================
# TIBYAN SERVER
# =============================================================================

class TibyanServer:
    """
    TIBYAN v9.0 Server
    
    Easy-to-use server for production deployment.
    """
    
    def __init__(self, config: Optional[ServerConfig] = None):
        self.config = config or ServerConfig()
        self.app = None
    
    def start(self):
        """Start the server"""
        import uvicorn
        
        self.app = create_app(self.config)
        
        uvicorn.run(
            self.app,
            host=self.config.host,
            port=self.config.port,
            workers=self.config.workers,
            log_level=self.config.log_level.lower()
        )
    
    def start_async(self):
        """Start server asynchronously"""
        import uvicorn
        import threading
        
        def run():
            self.app = create_app(self.config)
            uvicorn.run(
                self.app,
                host=self.config.host,
                port=self.config.port,
                log_level=self.config.log_level.lower()
            )
        
        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return thread


# =============================================================================
# MOCK APP (for when FastAPI is not installed)
# =============================================================================

class MockApp:
    """Mock app for when FastAPI is not installed"""
    
    def __init__(self, config: ServerConfig):
        self.config = config
    
    def run(self, **kwargs):
        print("FastAPI not installed. Please install with: pip install fastapi uvicorn")
    
    def route(self, path, **kwargs):
        def decorator(f):
            return f
        return decorator
    
    def get(self, path, **kwargs):
        def decorator(f):
            return f
        return decorator
    
    def post(self, path, **kwargs):
        def decorator(f):
            return f
        return decorator


# =============================================================================
# OPENAI-COMPATIBLE API
# =============================================================================

def create_openai_compatible_app(config: Optional[ServerConfig] = None):
    """
    Create OpenAI-compatible API server.
    
    Allows using TIBYAN with OpenAI SDK:
        import openai
        client = openai.Client(base_url="http://localhost:8000/v1")
        response = client.chat.completions.create(
            model="tibyan-v9",
            messages=[{"role": "user", "content": "مرحبا"}]
        )
    """
    config = config or ServerConfig()
    
    try:
        from fastapi import FastAPI, HTTPException
        from fastapi.middleware.cors import CORSMiddleware
        from pydantic import BaseModel
    except ImportError:
        return MockApp(config)
    
    from .main import TibyanAPI, GenerationConfig
    
    app = FastAPI(
        title="TIBYAN v9.0 OpenAI-Compatible API",
        version="9.0.0"
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    api = TibyanAPI()
    
    # OpenAI-compatible models
    class ChatMessage(BaseModel):
        role: str
        content: str
    
    class ChatCompletionRequest(BaseModel):
        model: str = "tibyan-v9"
        messages: List[ChatMessage]
        temperature: float = 0.7
        max_tokens: int = 512
        stream: bool = False
    
    class ChatCompletionChoice(BaseModel):
        index: int
        message: ChatMessage
        finish_reason: str
    
    class ChatCompletionResponse(BaseModel):
        id: str
        object: str = "chat.completion"
        created: int
        model: str
        choices: List[ChatCompletionChoice]
    
    @app.get("/v1/models")
    async def list_models():
        return {
            "object": "list",
            "data": [
                {
                    "id": "tibyan-v9",
                    "object": "model",
                    "created": int(time.time()),
                    "owned_by": "tibyan"
                }
            ]
        }
    
    @app.post("/v1/chat/completions")
    async def chat_completions(request: ChatCompletionRequest):
        # Build prompt from messages
        history = [{"role": m.role, "content": m.content} for m in request.messages[:-1]]
        last_message = request.messages[-1].content if request.messages else ""
        
        response = api.chat(
            message=last_message,
            history=history if history else None
        )
        
        return ChatCompletionResponse(
            id=f"chatcmpl-{int(time.time())}",
            created=int(time.time()),
            model=request.model,
            choices=[
                ChatCompletionChoice(
                    index=0,
                    message=ChatMessage(role="assistant", content=response),
                    finish_reason="stop"
                )
            ]
        )
    
    return app
