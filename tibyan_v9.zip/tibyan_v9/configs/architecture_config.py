"""
TIBYAN v9.0 AGI Micro-Engine - Architecture Configuration
=========================================================

Detailed configuration classes for all architectural components:
- Attention mechanisms (Flash 2/3/4, MLA, Kimi-Linear)
- State Space Models (Mamba-2, Mamba-3, HGRN)
- Mixture of Experts (Dirichlet MoE, MoE++)
- Memory systems (Titans, Episodic, EM-LLM)
- Hybrid layer integration
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Literal, Tuple
from enum import Enum
import math


# =============================================================================
# ATTENTION CONFIGURATION
# =============================================================================

@dataclass
class AttentionConfig:
    """
    Configuration for all attention mechanisms
    
    Supports v8.0 features:
    - Multi-head Latent Attention (MLA)
    - Grouped Query Attention (GQA)
    - PagedAttention
    - Flash Attention 2/3
    
    Supports v9.0 features:
    - Flash Attention 4 (Blackwell optimized)
    - Kimi Delta Attention (Linear)
    - Sliding Window Attention
    """
    # ===== Basic Attention Parameters =====
    hidden_dim: int = 1024
    num_heads: int = 16
    num_kv_heads: int = 4  # For GQA
    head_dim: int = 64
    
    # ===== Attention Type =====
    attention_type: str = "mla"  # full, flash2, flash3, flash4, mla, kimi_delta, paged
    
    # ===== Flash Attention Configuration =====
    flash_version: int = 3
    flash_softmax_scale: Optional[float] = None
    flash_causal: bool = True
    flash_window_size: Optional[Tuple[int, int]] = None
    
    # ===== Flash Attention 4 Specific (v9.0 NEW) =====
    flash4_async_tensor_cores: bool = True
    flash4_tma_enabled: bool = True
    flash4_fp8_support: bool = True
    
    # ===== MLA Configuration (v8) =====
    mla_latent_dim: int = 512
    mla_use_absorbed: bool = True
    mla_rope_fraction: float = 0.5
    
    # ===== Kimi-Linear Configuration (v9.0 NEW) =====
    kimi_chunk_size: int = 128
    kimi_delta_init: float = 0.1
    kimi_learnable_delta: bool = True
    kimi_feature_map: str = "elu"  # elu, relu, exp
    
    # ===== PagedAttention Configuration (v8) =====
    paged_page_size: int = 16
    paged_max_pages: int = 1024
    paged_block_tables_size: int = 256
    
    # ===== Sliding Window Configuration =====
    sliding_window_size: int = 4096
    sliding_window_type: str = "local"  # local, dilated
    
    # ===== Attention Optimization =====
    use_flash_attention: bool = True
    use_memory_efficient_attention: bool = True
    attention_dropout: float = 0.1
    
    # ===== RoPE Configuration =====
    use_rope: bool = True
    rope_theta: float = 10000.0
    rope_interleaved: bool = False
    
    # ===== LongRoPE2 Configuration (v8) =====
    use_long_rope2: bool = True
    long_rope2_extended_seq_len: int = 2_000_000
    long_rope2_progressive_scaling: bool = True
    
    # ===== YaRN Configuration (v8) =====
    use_yarn: bool = False
    yarn_scale: float = 1.0
    yarn_beta: float = 0.1
    yarn_alpha: float = 1.0
    
    def __post_init__(self):
        if self.head_dim is None:
            self.head_dim = self.hidden_dim // self.num_heads
        if self.flash_softmax_scale is None:
            self.flash_softmax_scale = 1.0 / math.sqrt(self.head_dim)


@dataclass
class MultiHeadLatentAttentionConfig(AttentionConfig):
    """
    Specific configuration for Multi-head Latent Attention (MLA)
    
    Key innovation from DeepSeek-V2/V3:
    - Compress KV cache to latent representation (90% reduction)
    - Absorbed mechanism: merge projection matrices into query
    - Decoupled RoPE for position encoding
    """
    attention_type: str = "mla"
    
    # Latent compression dimensions
    kv_latent_dim: int = 512
    q_latent_dim: int = 512
    
    # RoPE components (decoupled)
    q_rope_dim: int = 64
    k_rope_dim: int = 64
    
    # Absorbed mechanism
    use_absorbed: bool = True
    absorbed_merge_threshold: float = 0.1
    
    # Cache compression
    cache_compression_ratio: float = 0.1  # 90% reduction


# =============================================================================
# STATE SPACE MODEL CONFIGURATION
# =============================================================================

@dataclass
class SSMConfig:
    """
    Configuration for State Space Model layers
    
    Supports:
    - Mamba-2 SSD (v8)
    - Mamba-3 improvements (v9.0 NEW)
    - HGRN (v8)
    - DenseSSM (v9.0 NEW)
    """
    # ===== Basic SSM Parameters =====
    hidden_dim: int = 1024
    state_dim: int = 16
    head_dim: int = 64
    expand: int = 2
    
    # ===== SSM Type =====
    ssm_type: str = "mamba3"  # mamba2, mamba3, hgrn, dense_ssm
    
    # ===== Mamba-2 Configuration (v8) =====
    mamba2_chunk_size: int = 256
    mamba2_use_conv1d: bool = True
    mamba2_conv_kernel: int = 4
    
    # ===== Mamba-3 Improvements (v9.0 NEW) =====
    mamba3_structured_sparse: bool = True
    mamba3_sparse_pattern: str = "diagonal"  # diagonal, tridiagonal, custom
    mamba3_improved_scan: bool = True
    mamba3_state_tracking: bool = True
    
    # ===== HGRN Configuration (v8) =====
    hgrn_num_levels: int = 3
    hgrn_forget_gate_min: float = 0.1
    hgrn_use_output_gate: bool = True
    
    # ===== DenseSSM Configuration (v9.0 NEW) =====
    dense_ssm_hidden_connection: bool = True
    dense_ssm_connection_ratio: float = 0.25
    
    # ===== DeltaNet-style Updates =====
    use_delta_updates: bool = True
    delta_decay_init: float = 0.9
    
    # ===== A Parameter Configuration =====
    a_init: str = "learned"  # learned, fixed, diagonal
    a_range: Tuple[float, float] = (-10.0, -1.0)
    
    # ===== D Parameter (skip connection) =====
    d_init: float = 1.0
    d_learnable: bool = True
    
    # ===== Dropout =====
    dropout: float = 0.1


@dataclass
class Mamba3Config(SSMConfig):
    """
    Mamba-3 specific configuration with all improvements
    
    Key innovations:
    - Structured sparse transition matrices
    - Improved state tracking
    - DenseSSM-style hidden connections
    """
    ssm_type: str = "mamba3"
    
    # Sparse transition matrix configuration
    sparsity_pattern: str = "tridiagonal"
    sparsity_density: float = 0.3
    
    # State tracking improvements
    state_tracking_method: str = "ibm_expressive"  # IBM's method
    state_tracking_layers: List[int] = field(default_factory=lambda: [3, 4, 5])
    
    # Hardware optimization
    use_chunk_parallel: bool = True
    chunk_size: int = 256


# =============================================================================
# MOE CONFIGURATION
# =============================================================================

class RoutingType(Enum):
    """MoE routing types"""
    TOP_K = "top_k"
    DIRICHLET = "dirichlet"
    EXPERT_CHOICE = "expert_choice"
    SOFT_MOE = "soft_moe"


@dataclass
class MoEConfig:
    """
    Configuration for Mixture of Experts
    
    Supports v8.0 features:
    - Dirichlet routing
    - SEER-MoE compression
    - RS-MoE
    - Load balancing
    
    Supports v9.0 features:
    - MoE++ with zero-computation experts
    - Expert choice routing
    - SimSMoE for training stability
    """
    # ===== Basic MoE Parameters =====
    hidden_dim: int = 1024
    intermediate_dim: int = 2816
    num_experts: int = 8
    num_active_experts: int = 2
    expert_dropout: float = 0.1
    
    # ===== Routing Configuration =====
    routing_type: RoutingType = RoutingType.DIRICHLET
    
    # ===== Dirichlet Routing (v8) =====
    dirichlet_concentration: float = 1.0
    dirichlet_temperature: float = 1.0
    dirichlet_stochastic: bool = True
    
    # ===== Top-K Routing =====
    top_k: int = 2
    top_k_renorm: bool = True
    
    # ===== Expert Choice Routing (v9.0 NEW) =====
    expert_choice_capacity: float = 1.25  # capacity factor
    expert_choice_random_selection: bool = False
    
    # ===== MoE++ Configuration (v9.0 NEW) =====
    use_moe_plus_plus: bool = True
    num_identity_experts: int = 1  # Pass-through expert
    num_zero_experts: int = 1  # Zero-output expert
    
    # ===== SEER-MoE Configuration (v8) =====
    use_seer_moe: bool = True
    seer_compression_ratio: float = 0.5
    seer_warmup_steps: int = 1000
    
    # ===== RS-MoE Configuration (v8) =====
    use_rs_moe: bool = True
    rs_rank: int = 64
    rs_update_frequency: int = 100
    
    # ===== SimSMoE Configuration (v9.0 NEW) =====
    use_sim_smoe: bool = True
    sim_smoe_similarity_threshold: float = 0.9
    sim_smoe_penalty_weight: float = 0.01
    
    # ===== Load Balancing =====
    load_balance_coef: float = 0.01
    load_balance_method: str = "aux_loss"  # aux_loss, router_z_loss, none
    
    # ===== Expert Architecture =====
    expert_type: str = "mlp"  # mlp, glu, ge_glu
    expert_activation: str = "silu"
    
    # ===== Shared Expert (DeepSeek-style) =====
    use_shared_expert: bool = True
    shared_expert_weight: float = 1.0
    
    # ===== Capacity Management =====
    expert_capacity: Optional[int] = None
    drop_tokens: bool = False
    drop_policy: str = "random"  # random, lowest_prob
    
    # ===== Communication Optimization =====
    use_tensor_parallel: bool = False
    tp_size: int = 1
    
    def __post_init__(self):
        if isinstance(self.routing_type, str):
            self.routing_type = RoutingType(self.routing_type)
        
        # Calculate effective number of experts including MoE++ additions
        if self.use_moe_plus_plus:
            self.effective_num_experts = (
                self.num_experts + 
                self.num_identity_experts + 
                self.num_zero_experts
            )
        else:
            self.effective_num_experts = self.num_experts


# =============================================================================
# MEMORY CONFIGURATION
# =============================================================================

@dataclass
class MemoryConfig:
    """
    Configuration for all memory systems
    
    Supports:
    - Titans neural memory (v9.0 NEW)
    - Episodic memory (v9.0 NEW)
    - EM-LLM (v9.0 NEW)
    - KV cache management (v8)
    - PagedAttention (v8)
    """
    # ===== Titans Neural Memory (v9.0 NEW) =====
    use_titans_memory: bool = True
    titans_memory_dim: int = 1024
    titans_surprise_threshold: float = 0.5
    titans_update_rate: float = 0.1
    titans_forget_rate: float = 0.01
    titans_memory_layers: List[int] = field(default_factory=lambda: [0, 1, 2])
    
    # ===== Episodic Memory (v9.0 NEW) =====
    use_episodic_memory: bool = True
    episodic_num_episodes: int = 100
    episodic_episode_size: int = 512
    episodic_segment_method: str = "surprise"  # surprise, boundary, fixed
    episodic_retrieval_k: int = 5
    
    # ===== EM-LLM Configuration (v9.0 NEW) =====
    use_em_llm: bool = True
    em_llm_window_size: int = 512
    em_llm_segment_threshold: float = 0.3
    em_llm_boundary_method: str = "neural"  # neural, surprise, linguistic
    
    # ===== KV Cache Management (v8) =====
    kv_cache_dtype: str = "float16"
    kv_cache_max_len: int = 8192
    
    # ===== PagedAttention (v8) =====
    use_paged_attention: bool = True
    page_size: int = 16
    max_pages: int = 1024
    block_tables_size: int = 256
    
    # ===== PagedEviction (v9 enhancement) =====
    use_paged_eviction: bool = True
    eviction_policy: str = "lru"  # lru, lfu, surprise_based
    
    # ===== Memory Compression =====
    compress_kv_cache: bool = True
    compression_ratio: float = 0.5
    compression_method: str = "mla"  # mla, quantization, pruning
    
    # ===== Infinite Context =====
    infinite_context: bool = True
    infinite_context_method: str = "em_llm"  # em_llm, infini_attention, memorizing_transformers
    context_segment_size: int = 2048
    context_overlap: int = 256


@dataclass
class TitansMemoryConfig(MemoryConfig):
    """
    Specific configuration for Google Titans-style memory
    """
    # Memory architecture
    memory_hidden_dim: int = 1024
    memory_num_layers: int = 2
    memory_activation: str = "silu"
    
    # Surprise computation
    surprise_method: str = "prediction_error"  # prediction_error, kl_divergence, cosine
    surprise_history_size: int = 100
    surprise_normalization: bool = True
    
    # Memory update strategy
    update_strategy: str = "selective"  # selective, all, surprise_gated
    update_gate_init: float = 0.5
    
    # Memory retrieval
    retrieval_method: str = "attention"  # attention, similarity, surprise_weighted
    retrieval_top_k: int = 10


# =============================================================================
# HYBRID LAYER CONFIGURATION
# =============================================================================

@dataclass
class HybridLayerConfig:
    """
    Configuration for hybrid layer integration strategy
    
    This implements the progressive layer integration approach
    to avoid conflicts between different architectural components.
    """
    # ===== Layer Distribution =====
    num_layers: int = 16
    hidden_dim: int = 1024
    
    # ===== Layer Type Assignment =====
    # Strategy: "manual", "auto_balanced", "performance_optimized"
    layer_assignment_strategy: str = "manual"
    
    # Manual layer type distribution
    layer_types: Dict[int, str] = field(default_factory=lambda: {
        0: "titans",
        1: "titans", 
        2: "titans",
        3: "mamba3",
        4: "mamba3",
        5: "mamba3",
        6: "kimi_linear",
        7: "kimi_linear",
        8: "kimi_linear",
        9: "moe_plus_plus",
        10: "moe_plus_plus",
        11: "moe_plus_plus",
        12: "mla",
        13: "mla",
        14: "mla",
        15: "diffusion",
    })
    
    # ===== Parallel Modules =====
    # Modules that run in parallel with main layer computation
    parallel_modules: List[str] = field(default_factory=lambda: [
        "sparse_autoencoder",
        "world_model", 
        "steering_vectors",
        "episodic_memory"
    ])
    
    # ===== Layer Skip Configuration =====
    use_layer_skip: bool = True
    layer_skip_threshold: float = 0.95
    layer_skip_min_layer: int = 6
    layer_skip_early_exit: bool = True
    
    # ===== Cross-Layer Connections =====
    use_cross_layer_connections: bool = True
    cross_layer_connection_ratio: float = 0.25
    cross_layer_connection_pattern: str = "dense"  # dense, sparse, residual
    
    # ===== Normalization =====
    norm_type: str = "rms_norm"  # rms_norm, layer_norm
    norm_position: str = "pre"  # pre, post
    norm_eps: float = 1e-6
    
    # ===== Residual =====
    residual_type: str = "standard"  # standard, pre_norm, parallel
    residual_dropout: float = 0.1
    
    def get_layer_type(self, layer_idx: int) -> str:
        """Get the type of layer at given index"""
        if self.layer_assignment_strategy == "manual":
            return self.layer_types.get(layer_idx, "transformer")
        elif self.layer_assignment_strategy == "auto_balanced":
            return self._auto_assign_layer(layer_idx)
        else:
            return "transformer"
    
    def _auto_assign_layer(self, layer_idx: int) -> str:
        """Automatically assign layer type based on position"""
        ratio = layer_idx / self.num_layers
        
        if ratio < 0.2:
            return "titans"
        elif ratio < 0.4:
            return "mamba3"
        elif ratio < 0.6:
            return "kimi_linear"
        elif ratio < 0.8:
            return "moe_plus_plus"
        elif ratio < 0.95:
            return "mla"
        else:
            return "diffusion"
    
    def get_config_for_layer(self, layer_idx: int, layer_type: str) -> Dict[str, Any]:
        """Get configuration dictionary for a specific layer"""
        base_config = {
            "layer_idx": layer_idx,
            "hidden_dim": self.hidden_dim,
            "norm_type": self.norm_type,
            "norm_eps": self.norm_eps,
            "residual_type": self.residual_type,
            "residual_dropout": self.residual_dropout,
        }
        
        # Add layer-type-specific configurations
        if layer_type in ["titans"]:
            base_config.update({
                "use_titans_memory": True,
                "memory_dim": 1024,
            })
        elif layer_type in ["mamba3", "mamba2"]:
            base_config.update({
                "ssm_type": layer_type,
                "state_dim": 16,
            })
        elif layer_type == "kimi_linear":
            base_config.update({
                "attention_type": "kimi_delta",
                "chunk_size": 128,
            })
        elif layer_type in ["moe", "moe_plus_plus"]:
            base_config.update({
                "num_experts": 8,
                "num_active_experts": 2,
                "use_moe_plus_plus": layer_type == "moe_plus_plus",
            })
        elif layer_type == "mla":
            base_config.update({
                "attention_type": "mla",
                "latent_dim": 512,
            })
        elif layer_type == "diffusion":
            base_config.update({
                "diffusion_steps": 100,
            })
        
        return base_config


@dataclass
class DiffusionOutputConfig:
    """
    Configuration for diffusion-based output layer
    
    Enables parallel text generation using discrete diffusion
    """
    # Basic diffusion parameters
    hidden_dim: int = 1024
    vocab_size: int = 64000
    num_steps: int = 100
    
    # Noise schedule
    noise_schedule: str = "linear"  # linear, cosine, sigmoid
    beta_start: float = 0.0001
    beta_end: float = 0.02
    
    # Denoising network
    denoiser_layers: int = 4
    denoiser_heads: int = 8
    
    # Generation
    sampling_method: str = "ddpm"  # ddpm, ddim, dpm_solver
    guidance_scale: float = 1.0
    
    # Masking strategy for discrete diffusion
    mask_strategy: str = "random"  # random, progressive, block
    mask_ratio: float = 0.15
    
    # Parallel generation
    parallel_generation: bool = True
    num_parallel_tokens: int = 16
