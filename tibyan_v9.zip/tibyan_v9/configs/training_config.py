"""
TIBYAN v9.0 AGI Micro-Engine - Training Configuration
======================================================

Comprehensive training configuration supporting all methods:
- GRPO++ and GSPO (v8)
- RLVR and Self-Rewarding (v8)
- Forward-Only Training (v9.0 NEW)
- Mobile/Edge Training (v9.0 NEW)
- Federated Learning (v9.0 NEW)
- Knowledge Distillation (v8)
- Quantization-Aware Training
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple, Literal, Callable
from enum import Enum
import math


class RewardType(Enum):
    """Types of reward signals for RL training"""
    ACCURACY = "accuracy"
    PREFERENCE = "preference"
    VERIFICATION = "verification"
    SELF_GENERATED = "self_generated"
    CONSTITUTIONAL = "constitutional"


class DistillationType(Enum):
    """Knowledge distillation approaches"""
    RESPONSE = "response"
    FEATURE = "feature"
    RELATION = "relation"
    SPECULATIVE = "speculative"


# =============================================================================
# GRPO++ CONFIGURATION
# =============================================================================

@dataclass
class GRPOConfig:
    """
    Group Relative Policy Optimization Configuration
    
    Full implementation of GRPO++ from DeepSeek-R1:
    - Value function clipping (from PPO)
    - Proper group-level advantage computation
    - KL penalty scheduling (adaptive)
    - Dynamic temperature
    - Advantage normalization with clipping
    """
    # ===== Basic RL Parameters =====
    learning_rate: float = 1e-5
    gamma: float = 1.0  # Discount factor
    lam: float = 0.95  # GAE lambda
    
    # ===== Group Configuration =====
    group_size: int = 4  # Number of samples per question
    group_comparison: bool = True  # Compare within groups
    
    # ===== Clipping Parameters =====
    clip_range: float = 0.2
    clip_range_vf: Optional[float] = None  # Value function clipping
    
    # ===== KL Divergence =====
    kl_coef: float = 0.1  # Initial KL coefficient
    kl_target: float = 0.1  # Target KL divergence
    kl_horizon: int = 100  # Steps for KL averaging
    kl_adaptive: bool = True  # Adaptive KL scheduling
    
    # ===== Advantage Computation =====
    advantage_normalization: bool = True
    advantage_clip: float = 3.0  # Clip extreme advantages
    
    # ===== Temperature =====
    temperature: float = 1.0
    temperature_decay: float = 0.99
    min_temperature: float = 0.5
    
    # ===== Reward Configuration =====
    reward_type: RewardType = RewardType.ACCURACY
    reward_scaling: bool = True
    reward_clip: float = 10.0
    
    # ===== Training Loop =====
    num_epochs: int = 4  # PPO epochs per update
    mini_batch_size: int = 8
    gradient_accumulation_steps: int = 1
    
    # ===== Reference Model =====
    use_reference_model: bool = True
    reference_freeze: bool = True
    
    # ===== Logging =====
    log_kl: bool = True
    log_advantages: bool = True
    log_rewards: bool = True
    
    def compute_adaptive_kl_coef(self, current_kl: float) -> float:
        """
        Compute adaptive KL penalty based on observed divergence
        
        - If KL > 2 * target: increase penalty
        - If KL < 0.5 * target: decrease penalty
        """
        if current_kl > 2 * self.kl_target:
            return self.kl_coef * 1.5
        elif current_kl < 0.5 * self.kl_target:
            return self.kl_coef * 0.75
        return self.kl_coef


# =============================================================================
# DISTILLATION CONFIGURATION
# =============================================================================

@dataclass
class DistillationConfig:
    """
    Knowledge Distillation Configuration
    
    Supports multiple distillation methods:
    - Response-based: Match output distributions
    - Feature-based: Match intermediate representations
    - Relation-based: Preserve sample relationships
    - Speculative: Student proposes, teacher verifies
    """
    # ===== Basic Configuration =====
    enabled: bool = False
    teacher_model: str = ""
    teacher_hidden_dim: int = 4096
    
    # ===== Distillation Type =====
    distillation_type: DistillationType = DistillationType.RESPONSE
    
    # ===== Temperature =====
    temperature: float = 2.0
    temperature_decay: float = 0.99
    min_temperature: float = 1.0
    
    # ===== Loss Weights =====
    alpha: float = 0.5  # Balance KD vs task loss
    feature_weight: float = 0.1
    relation_weight: float = 0.1
    
    # ===== Layer Mapping (for feature distillation) =====
    layer_mapping: Dict[int, int] = field(default_factory=dict)
    # Example: {teacher_layer: student_layer}
    
    # ===== Speculative Distillation (v9.0 enhanced) =====
    speculative_draft_tokens: int = 10
    speculative_temperature: float = 0.8
    speculative_verification_threshold: float = 0.9
    
    # ===== Progressive Distillation =====
    progressive: bool = True
    progressive_stages: int = 3
    current_stage: int = 0
    
    # ===== Teacher Frozen =====
    freeze_teacher: bool = True
    teacher_offload: bool = False  # Offload to CPU for memory


# =============================================================================
# QUANTIZATION CONFIGURATION
# =============================================================================

@dataclass
class QuantizationConfig:
    """
    Quantization Configuration
    
    Supports all quantization methods:
    - BitNet b1.58 (v8)
    - NF4, BOF4, AF4 (v8)
    - AWQ (v8)
    - QuaRot (v8)
    - ParetoQ (v8)
    - PT-BitNet (v9.0 NEW)
    """
    # ===== Quantization Method =====
    method: str = "bitnet_158"  # bitnet_158, nf4, bof4, af4, awq, quarot, paretoq, pt_bitnet, fp8
    
    # ===== BitNet Configuration =====
    bitnet_bits: float = 1.58
    bitnet_learned_scale: bool = True
    bitnet_threshold_init: float = 0.5
    bitnet_ste: bool = True  # Straight-Through Estimator
    
    # ===== Block-wise Quantization =====
    block_size: int = 64
    block_mode: str = "per_tensor"  # per_tensor, per_channel, per_block
    
    # ===== NF4 Specific =====
    nf4_quantiles: Optional[List[float]] = None  # Precomputed quantiles
    
    # ===== AWQ Configuration =====
    awq_activation_scales: bool = True
    awq_calibration_samples: int = 512
    
    # ===== QuaRot Configuration =====
    quarot_rotation: bool = True
    quarot_rotation_type: str = "hadamard"  # hadamard, random, learned
    
    # ===== PT-BitNet Configuration (v9.0 NEW) =====
    pt_bitnet_finetune_steps: int = 1000
    pt_bitnet_learning_rate: float = 1e-5
    
    # ===== Activation Quantization =====
    quantize_activations: bool = True
    activation_bits: int = 8
    
    # ===== KV Cache Quantization =====
    quantize_kv_cache: bool = True
    kv_cache_bits: int = 4
    
    # ===== Training-Aware =====
    quantization_aware_training: bool = True
    qat_start_step: int = 0
    qat_warmup_steps: int = 1000
    
    def get_compression_ratio(self) -> float:
        """Calculate compression ratio vs FP16"""
        if self.method == "bitnet_158":
            return 16.0 / 1.58  # ~10x
        elif self.method in ["nf4", "bof4", "af4"]:
            return 16.0 / 4.0  # 4x
        elif self.method == "fp8":
            return 16.0 / 8.0  # 2x
        else:
            return 1.0


# =============================================================================
# MOBILE TRAINING CONFIGURATION
# =============================================================================

@dataclass
class MobileTrainingConfig:
    """
    Mobile/Edge Training Configuration (v9.0 NEW)
    
    Enables training on resource-constrained devices:
    - Memory-efficient backpropagation
    - CPU offloading
    - Chunked training
    - Forward-only alternatives
    """
    # ===== Mobile Mode =====
    enabled: bool = False
    max_memory_mb: int = 500  # Maximum memory budget
    
    # ===== Gradient Checkpointing =====
    gradient_checkpointing: bool = True
    selective_checkpointing: bool = True
    checkpoint_every_n_layers: int = 2
    
    # ===== CPU Offloading =====
    cpu_offload: bool = True
    cpu_offload_threshold_mb: int = 200
    
    # ===== Chunked Training =====
    chunk_size: int = 100  # Samples per chunk
    chunk_overlap: int = 10
    clear_cache_between_chunks: bool = True
    
    # ===== Mixed Precision =====
    mixed_precision: bool = True
    precision: str = "fp16"  # fp16, bf16, fp32
    
    # ===== Forward-Only Training =====
    forward_only: bool = False
    forward_only_method: str = "feedback_alignment"  # feedback_alignment, synthetic_gradients, evolution
    
    # ===== QAST (Quantized Adapter Side-Tuning) =====
    use_qast: bool = True
    qast_adapter_dim: int = 64
    qast_quantization_bits: int = 4
    qast_adapter_layers: List[int] = field(default_factory=lambda: [0, 4, 8, 12])
    
    # ===== Frozen Backbone =====
    freeze_backbone: bool = True
    trainable_modules: List[str] = field(default_factory=lambda: ["adapters", "heads"])
    
    # ===== Battery Optimization =====
    battery_aware: bool = True
    low_battery_threshold: float = 0.2  # Pause at 20%
    power_saving_mode: bool = False
    
    # ===== Progress Tracking =====
    checkpoint_interval: int = 100
    resume_from_checkpoint: Optional[str] = None


# =============================================================================
# FORWARD-ONLY TRAINING CONFIGURATION
# =============================================================================

@dataclass
class ForwardOnlyConfig:
    """
    Forward-Only Training Configuration (v9.0 NEW)
    
    Training without backpropagation for extreme memory efficiency:
    - Feedback Alignment
    - Synthetic Gradients
    - Evolution Strategies
    - Perturbation-based gradient estimation
    """
    # ===== Method Selection =====
    method: str = "feedback_alignment"  # feedback_alignment, synthetic_gradients, evolution, perturbation
    
    # ===== Feedback Alignment =====
    feedback_init: str = "random"  # random, orthogonal, learned
    feedback_scale: float = 1.0
    
    # ===== Synthetic Gradients =====
    synthetic_gradient_hidden_dim: int = 256
    synthetic_gradient_layers: int = 2
    
    # ===== Evolution Strategies =====
    population_size: int = 20
    mutation_rate: float = 0.1
    selection_pressure: float = 0.5
    
    # ===== Perturbation-based =====
    perturbation_scale: float = 0.01
    num_perturbation_samples: int = 10
    antithetic_sampling: bool = True  # Use both +noise and -noise
    
    # ===== Learning Rate =====
    learning_rate: float = 1e-3
    
    # ===== Memory Optimization =====
    estimate_gradient_memory_mb: int = 100  # Target memory usage


# =============================================================================
# FEDERATED LEARNING CONFIGURATION
# =============================================================================

@dataclass
class FederatedConfig:
    """
    Federated Learning Configuration (v9.0 NEW)
    
    Enables distributed training across multiple devices:
    - FedAvg aggregation
    - Privacy preservation
    - Communication efficiency
    """
    # ===== Basic Configuration =====
    enabled: bool = False
    num_clients: int = 10
    num_rounds: int = 100
    
    # ===== Local Training =====
    local_epochs: int = 5
    local_batch_size: int = 32
    local_learning_rate: float = 1e-4
    
    # ===== Aggregation =====
    aggregation_method: str = "fedavg"  # fedavg, fedprox, fedadam, scaffold
    fedprox_mu: float = 0.01  # For FedProx
    
    # ===== Client Selection =====
    client_fraction: float = 1.0  # Fraction of clients per round
    client_selection: str = "random"  # random, importance, round_robin
    
    # ===== Communication =====
    compression: bool = True
    compression_method: str = "top_k"  # top_k, quantization, sparsification
    compression_ratio: float = 0.1
    
    # ===== Privacy =====
    differential_privacy: bool = False
    dp_noise_scale: float = 0.1
    dp_clip_norm: float = 1.0
    
    # ===== Async Support =====
    asynchronous: bool = False
    stale_threshold: int = 5  # Max rounds of staleness


# =============================================================================
# CONTINUAL LEARNING CONFIGURATION
# =============================================================================

@dataclass
class ContinualLearningConfig:
    """
    Continual Learning Configuration
    
    Supports MESU and other continual learning methods:
    - Memory replay
    - Elastic weight consolidation
    - Progressive networks
    """
    # ===== MESU Configuration (v8) =====
    use_mesu: bool = True
    mesu_memory_size: int = 1000
    mesu_update_frequency: int = 100
    mesu_importance_decay: float = 0.9
    
    # ===== Elastic Weight Consolidation =====
    use_ewc: bool = False
    ewc_lambda: float = 0.1
    ewc_online: bool = True
    
    # ===== Memory Replay =====
    use_replay: bool = True
    replay_buffer_size: int = 10000
    replay_ratio: float = 0.25
    
    # ===== Progressive Networks =====
    use_progressive: bool = False
    num_columns: int = 1
    
    # ===== Task Detection =====
    task_detection: bool = True
    task_detection_threshold: float = 0.5
