"""
TIBYAN v9.0 AGI Micro-Engine - Inference Configuration
=======================================================

Comprehensive inference configuration supporting:
- Multiple decoding strategies
- Test-time compute scaling
- Speculative decoding (CARD, EasySpec, SWIFT)
- Latent reasoning
- Multi-token prediction
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple, Literal, Callable
from enum import Enum
import math


class DecodingStrategy(Enum):
    """Available decoding strategies"""
    GREEDY = "greedy"
    BEAM_SEARCH = "beam_search"
    SAMPLING = "sampling"
    TOP_K = "top_k"
    TOP_P = "top_p"
    TYPICAL = "typical"
    CONTRASTIVE = "contrastive"
    SPECULATIVE = "speculative"
    DIFFUSION = "diffusion"


class TestTimeComputeStrategy(Enum):
    """Test-time compute scaling strategies"""
    BEST_OF_N = "best_of_n"
    BEAM_SEARCH = "beam_search"
    TREE_SEARCH = "tree_search"
    SELF_CONSISTENCY = "self_consistency"
    CHAIN_OF_THOUGHT = "chain_of_thought"
    VERIFICATION = "verification"


# =============================================================================
# DECODING CONFIGURATION
# =============================================================================

@dataclass
class DecodingConfig:
    """
    Comprehensive Decoding Configuration
    
    Supports all decoding strategies:
    - Greedy, Beam Search, Sampling
    - Top-k, Top-p (Nucleus), Typical
    - Contrastive, Speculative, Diffusion
    """
    # ===== Basic Configuration =====
    strategy: DecodingStrategy = DecodingStrategy.SAMPLING
    max_new_tokens: int = 512
    min_new_tokens: int = 1
    
    # ===== Sampling Parameters =====
    temperature: float = 1.0
    top_k: int = 50
    top_p: float = 0.95
    typical_p: float = 0.2  # For typical sampling
    
    # ===== Beam Search =====
    num_beams: int = 4
    beam_group_size: int = 1  # For diverse beam search
    diversity_penalty: float = 0.0
    length_penalty: float = 1.0
    early_stopping: bool = True
    
    # ===== Repetition Control =====
    repetition_penalty: float = 1.0
    no_repeat_ngram_size: int = 0
    encoder_repetition_penalty: float = 1.0
    
    # ===== Bad Words/Forced Words =====
    bad_words_ids: Optional[List[List[int]]] = None
    force_words_ids: Optional[List[List[int]]] = None
    
    # ===== Contrastive Decoding =====
    contrastive_alpha: float = 0.5
    contrastive_beta: float = 0.5
    
    # ===== Constrained Decoding =====
    prefix_allowed_tokens_fn: Optional[Callable] = None
    logits_processor: Optional[List] = None
    
    # ===== Streaming =====
    streaming: bool = True
    stream_chunk_size: int = 10
    
    # ===== Stop Conditions =====
    stop_strings: List[str] = field(default_factory=list)
    stop_token_ids: List[int] = field(default_factory=list)
    eos_token_id: int = 2
    
    def __post_init__(self):
        if isinstance(self.strategy, str):
            self.strategy = DecodingStrategy(self.strategy)


# =============================================================================
# TEST-TIME COMPUTE CONFIGURATION
# =============================================================================

@dataclass
class TestTimeComputeConfig:
    """
    Test-Time Compute Scaling Configuration
    
    Implements methods to improve output quality during inference:
    - Best-of-N with verification
    - Self-consistency
    - Tree search (MCTS-style)
    - Chain-of-thought reasoning
    """
    # ===== Enable Test-Time Compute =====
    enabled: bool = True
    strategy: TestTimeComputeStrategy = TestTimeComputeStrategy.BEST_OF_N
    
    # ===== Compute Budget =====
    compute_budget: int = 8  # Number of compute units
    adaptive_budget: bool = True  # Adjust based on difficulty
    
    # ===== Best-of-N =====
    num_samples: int = 8
    verification_method: str = "confidence"  # confidence, verifier_model, self
    
    # ===== Self-Consistency =====
    num_consistency_samples: int = 10
    consistency_threshold: float = 0.7
    
    # ===== Tree Search =====
    tree_width: int = 4
    tree_depth: int = 5
    exploration_weight: float = 1.0
    value_function: str = "learned"  # learned, rollout, heuristic
    
    # ===== Chain-of-Thought =====
    cot_max_tokens: int = 1024
    cot_num_steps: int = 5
    cot_self_reflection: bool = True
    
    # ===== Dynamic Scaling =====
    difficulty_estimator: str = "entropy"  # entropy, confidence, oracle
    easy_budget: int = 2
    medium_budget: int = 4
    hard_budget: int = 16
    
    # ===== Verification =====
    use_verification: bool = True
    verifier_model: Optional[str] = None
    verification_threshold: float = 0.8
    
    # ===== Early Exit =====
    early_exit: bool = True
    early_exit_threshold: float = 0.95
    
    # ===== Self-Correction =====
    self_correction: bool = True
    max_correction_attempts: int = 3
    correction_temperature: float = 0.7


# =============================================================================
# SPECULATIVE DECODING CONFIGURATION
# =============================================================================

@dataclass
class SpeculativeDecodingConfig:
    """
    Speculative Decoding Configuration
    
    Supports multiple speculative decoding methods:
    - CARD (v8)
    - EasySpec (v9.0 NEW)
    - SWIFT (v9.0 NEW)
    - Self-speculative
    """
    # ===== Basic Configuration =====
    enabled: bool = True
    method: str = "easy_spec"  # card, easy_spec, swift, self
    
    # ===== Draft Configuration =====
    draft_model: Optional[str] = None  # None for self-speculative
    num_draft_tokens: int = 5
    draft_temperature: float = 0.8
    
    # ===== Acceptance =====
    acceptance_method: str = "threshold"  # threshold, distribution, hybrid
    acceptance_threshold: float = 0.9
    
    # ===== CARD Configuration (v8) =====
    card_attention_threshold: float = 0.8
    card_position_aware: bool = True
    
    # ===== EasySpec Configuration (v9.0 NEW) =====
    easy_spec_skip_layers: List[int] = field(default_factory=lambda: [8, 10, 12])
    easy_spec_layer_parallel: bool = True
    easy_spec_verification_layers: int = 2
    
    # ===== SWIFT Configuration (v9.0 NEW) =====
    swift_adaptive_skipping: bool = True
    swift_skip_threshold: float = 0.95
    swift_max_skip_ratio: float = 0.5
    
    # ===== Performance =====
    target_speedup: float = 3.0
    max_speculative_rounds: int = 10
    
    # ===== Medusa Heads (Alternative) =====
    use_medusa: bool = False
    medusa_num_heads: int = 4
    medusa_heads_layers: List[int] = field(default_factory=lambda: [0, 1, 2, 3])


# =============================================================================
# LATENT REASONING CONFIGURATION
# =============================================================================

@dataclass
class LatentReasoningConfig:
    """
    Latent Reasoning Configuration
    
    Enables reasoning in continuous latent space:
    - State space reasoning
    - Hidden state exploration
    - Dynamic computation allocation
    """
    # ===== Enable Latent Reasoning =====
    enabled: bool = True
    
    # ===== Reasoning Steps =====
    num_reasoning_steps: int = 3
    adaptive_steps: bool = True
    min_steps: int = 1
    max_steps: int = 8
    
    # ===== Reasoning Dimension =====
    reasoning_dim: int = 256
    reasoning_hidden_dim: int = 512
    
    # ===== State Space Reasoning =====
    state_space_reasoning: bool = True
    ssm_state_dim: int = 16
    
    # ===== Exploration =====
    exploration_noise: float = 0.1
    exploration_decay: float = 0.9
    
    # ===== Computation Allocation =====
    dynamic_computation: bool = True
    computation_early_exit: bool = True
    exit_threshold: float = 0.95
    
    # ===== Special Tokens =====
    think_start_token: int = 3
    think_end_token: int = 4
    latent_think_token: int = 5
    
    # ===== Output Integration =====
    output_integration: str = "concat"  # concat, attention, gate
    output_gate_init: float = 0.5


# =============================================================================
# MULTI-TOKEN PREDICTION CONFIGURATION
# =============================================================================

@dataclass
class MultiTokenPredictionConfig:
    """
    Multi-Token Prediction Configuration
    
    Predict multiple future tokens simultaneously:
    - Improves training signal
    - Better long-range coherence
    - Speculative decoding compatible
    """
    # ===== Enable MTP =====
    enabled: bool = True
    num_future_tokens: int = 4
    
    # ===== Loss Configuration =====
    loss_weights: List[float] = field(default_factory=lambda: [1.0, 0.8, 0.6, 0.4])
    use_distance_weighting: bool = True
    distance_weight_decay: float = 0.8
    
    # ===== Architecture =====
    shared_projection: bool = True
    separate_heads: bool = False
    head_hidden_dim: int = 256
    
    # ===== Training =====
    train_mtp_from_start: bool = True
    mtp_warmup_steps: int = 0


# =============================================================================
# INFERENCE OPTIMIZATION CONFIGURATION
# =============================================================================

@dataclass
class InferenceOptimizationConfig:
    """
    Inference Optimization Configuration
    
    Hardware and algorithmic optimizations for efficient inference:
    - KV cache management
    - Batch optimization
    - Memory planning
    """
    # ===== KV Cache =====
    use_kv_cache: bool = True
    kv_cache_dtype: str = "float16"
    max_cache_length: int = 8192
    
    # ===== Paged Attention =====
    use_paged_attention: bool = True
    page_size: int = 16
    max_num_pages: int = 1024
    max_num_seqs: int = 256
    
    # ===== Batch Optimization =====
    max_batch_size: int = 32
    dynamic_batching: bool = True
    continuous_batching: bool = True
    
    # ===== Memory =====
    max_memory_utilization: float = 0.9
    prefill_chunk_size: int = 1024
    
    # ===== Quantization =====
    quantize_weights: bool = True
    quantize_kv_cache: bool = True
    quantization_bits: int = 4
    
    # ===== Kernel Optimization =====
    use_flash_attention: bool = True
    flash_attention_version: int = 3
    use_custom_kernels: bool = True
    
    # ===== Async =====
    async_inference: bool = True
    num_async_workers: int = 4
