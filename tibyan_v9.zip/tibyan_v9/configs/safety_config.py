"""
TIBYAN v9.0 AGI Micro-Engine - Safety Configuration
====================================================

Comprehensive safety configuration supporting:
- Hallucination detection (Semantic Entropy)
- Steering vectors for behavior control
- Multi-layer verification
- Content safety filtering
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple, Literal
from enum import Enum


class HallucinationDetectionMethod(Enum):
    """Methods for detecting hallucinations"""
    SEMANTIC_ENTROPY = "semantic_entropy"
    KNOWLEDGE_GROUNDED = "knowledge_grounded"
    TEMPORAL_LOGIC = "temporal_logic"
    SELF_CONSISTENCY = "self_consistency"
    CONFIDENCE_CALIBRATION = "confidence_calibration"


class SteeringDirection(Enum):
    """Behavioral steering directions"""
    HELPFULNESS = "helpfulness"
    HONESTY = "honesty"
    HARMLESSNESS = "harmlessness"
    CREATIVITY = "creativity"
    FORMALITY = "formality"


# =============================================================================
# HALLUCINATION DETECTION CONFIGURATION
# =============================================================================

@dataclass
class HallucinationDetectionConfig:
    """
    Hallucination Detection Configuration
    
    Implements multiple detection methods:
    - Semantic Entropy (Nature 2025) - v8
    - Knowledge-Grounded Detection - v8
    - Temporal-Logic Detection - v8
    - Self-Consistency - v9.0 NEW
    """
    # ===== Enable Detection =====
    enabled: bool = True
    detection_method: HallucinationDetectionMethod = HallucinationDetectionMethod.SEMANTIC_ENTROPY
    
    # ===== Semantic Entropy Configuration (v8) =====
    num_samples: int = 5
    similarity_threshold: float = 0.7
    entropy_threshold: float = 1.5
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    
    # ===== Clustering Configuration =====
    clustering_method: str = "agglomerative"  # agglomerative, kmeans
    cluster_distance_metric: str = "cosine"
    min_cluster_size: int = 2
    
    # ===== Knowledge-Grounded Configuration (v8) =====
    kg_verification: bool = True
    kg_database: str = "wikipedia"
    kg_confidence_threshold: float = 0.8
    
    # ===== Temporal-Logic Configuration (v8) =====
    temporal_verification: bool = True
    temporal_window: int = 3
    temporal_consistency_threshold: float = 0.9
    
    # ===== Self-Consistency Configuration (v9.0 NEW) =====
    self_consistency_samples: int = 5
    self_consistency_temperature: float = 0.7
    consistency_threshold: float = 0.7
    
    # ===== Multi-Layer Verification Framework =====
    multi_layer_verification: bool = True
    verification_layers: List[str] = field(default_factory=lambda: [
        "semantic_entropy",
        "knowledge_grounded",
        "temporal_logic"
    ])
    layer_voting: str = "majority"  # majority, unanimous, weighted
    
    # ===== Action on Detection =====
    detection_action: str = "flag"  # flag, reject, regenerate, clarify
    max_regeneration_attempts: int = 3
    
    # ===== Logging =====
    log_detections: bool = True
    log_samples: bool = False
    
    def __post_init__(self):
        if isinstance(self.detection_method, str):
            self.detection_method = HallucinationDetectionMethod(self.detection_method)


# =============================================================================
# STEERING VECTOR CONFIGURATION
# =============================================================================

@dataclass
class SteeringConfig:
    """
    Steering Vectors Configuration
    
    Control model behavior through representation engineering:
    - Pre-defined steering directions
    - Learnable steering vectors
    - Multi-concept steering
    """
    # ===== Enable Steering =====
    enabled: bool = True
    
    # ===== Steering Dimensions =====
    steering_dim: int = 256
    num_steering_vectors: int = 8
    
    # ===== Steering Directions =====
    available_directions: List[SteeringDirection] = field(default_factory=lambda: [
        SteeringDirection.HELPFULNESS,
        SteeringDirection.HONESTY,
        SteeringDirection.HARMLESSNESS,
    ])
    active_directions: List[str] = field(default_factory=lambda: ["helpfulness", "honesty"])
    
    # ===== Steering Strength =====
    default_strength: float = 1.0
    min_strength: float = 0.0
    max_strength: float = 3.0
    adaptive_strength: bool = True
    
    # ===== Steering Layers =====
    steering_layers: List[int] = field(default_factory=lambda: [10, 12, 14])
    layer_weights: List[float] = field(default_factory=lambda: [0.5, 0.75, 1.0])
    
    # ===== Vector Learning =====
    learnable_vectors: bool = True
    learning_rate: float = 1e-4
    regularization: float = 0.01
    
    # ===== Multi-Concept =====
    multi_concept_steering: bool = True
    concept_orthogonality: bool = True
    orthogonality_penalty: float = 0.1
    
    # ===== Contrastive Steering =====
    contrastive_steering: bool = True
    positive_examples: int = 10
    negative_examples: int = 10
    
    # ===== Activation Steering =====
    activation_steering: bool = True
    steering_hook_position: str = "post"  # pre, post, residual


# =============================================================================
# VERIFICATION CONFIGURATION
# =============================================================================

@dataclass
class VerificationConfig:
    """
    Multi-Layer Verification Framework Configuration
    
    Comprehensive output verification:
    - Factual verification
    - Logical consistency
    - Safety verification
    - Quality verification
    """
    # ===== Enable Verification =====
    enabled: bool = True
    
    # ===== Verification Layers =====
    factual_verification: bool = True
    logical_verification: bool = True
    safety_verification: bool = True
    quality_verification: bool = True
    
    # ===== Factual Verification =====
    fact_database: str = "wikipedia"
    fact_confidence_threshold: float = 0.8
    fact_retrieval_top_k: int = 5
    
    # ===== Logical Verification =====
    logic_checker: str = "rule_based"  # rule_based, nli_model, llm_verifier
    logic_consistency_threshold: float = 0.9
    detect_contradictions: bool = True
    
    # ===== Safety Verification =====
    safety_classifier: str = "multilingual"  # multilingual, ensemble
    safety_categories: List[str] = field(default_factory=lambda: [
        "violence", "hate_speech", "sexual_content", "self_harm", "harassment"
    ])
    safety_threshold: float = 0.5
    block_unsafe: bool = True
    
    # ===== Quality Verification =====
    quality_metrics: List[str] = field(default_factory=lambda: [
        "coherence", "relevance", "fluency", "conciseness"
    ])
    quality_threshold: float = 0.7
    
    # ===== Ensemble Verification =====
    ensemble_method: str = "weighted_vote"  # weighted_vote, cascade, parallel
    verification_weights: Dict[str, float] = field(default_factory=lambda: {
        "factual": 0.3,
        "logical": 0.2,
        "safety": 0.3,
        "quality": 0.2
    })
    
    # ===== Action on Failure =====
    failure_action: str = "regenerate"  # reject, regenerate, clarify, warn
    max_regeneration_attempts: int = 3
    fallback_response: str = "I cannot provide a verified response to this query."


# =============================================================================
# CONTENT SAFETY CONFIGURATION
# =============================================================================

@dataclass
class ContentSafetyConfig:
    """
    Content Safety Configuration
    
    Input/output filtering and moderation:
    - Content classification
    - PII detection
    - Jailbreak detection
    """
    # ===== Enable Content Safety =====
    enabled: bool = True
    
    # ===== Input Filtering =====
    filter_input: bool = True
    input_categories: List[str] = field(default_factory=lambda: [
        "violence", "hate_speech", "sexual_content", "self_harm", 
        "harassment", "dangerous_content", "pii"
    ])
    input_block_threshold: float = 0.7
    
    # ===== Output Filtering =====
    filter_output: bool = True
    output_categories: List[str] = field(default_factory=lambda: [
        "violence", "hate_speech", "sexual_content", "self_harm", "harassment"
    ])
    output_block_threshold: float = 0.5
    
    # ===== PII Detection =====
    detect_pii: bool = True
    pii_types: List[str] = field(default_factory=lambda: [
        "email", "phone", "ssn", "credit_card", "address", "name"
    ])
    pii_redaction: bool = True
    pii_replacement: str = "[REDACTED]"
    
    # ===== Jailbreak Detection =====
    detect_jailbreak: bool = True
    jailbreak_patterns: List[str] = field(default_factory=lambda: [
        "ignore_previous",
        "system_prompt",
        "developer_mode",
        "dan_prompt"
    ])
    jailbreak_block: bool = True
    
    # ===== Multilingual Support =====
    multilingual_safety: bool = True
    supported_languages: List[str] = field(default_factory=lambda: [
        "en", "ar", "fr", "es", "de", "zh", "ja"
    ])
    
    # ===== Logging =====
    log_violations: bool = True
    log_samples: bool = False  # Privacy consideration
