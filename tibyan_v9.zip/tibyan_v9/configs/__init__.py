"""
TIBYAN v9.0 AGI Micro-Engine - Configuration Module
====================================================

This module contains all configuration classes for the complete
TIBYAN v9.0 architecture, including backward compatibility with
all v8.0 features and new 2025-2026 SOTA techniques.
"""

from .base_config import TibyanV9Config, ModelConfig, TrainingConfig
from .architecture_config import (
    AttentionConfig,
    SSMConfig,
    MoEConfig,
    MemoryConfig,
    HybridLayerConfig
)
from .training_config import (
    GRPOConfig,
    DistillationConfig,
    QuantizationConfig,
    MobileTrainingConfig
)
from .inference_config import (
    DecodingConfig,
    TestTimeComputeConfig,
    SpeculativeDecodingConfig
)
from .safety_config import (
    HallucinationDetectionConfig,
    SteeringConfig,
    VerificationConfig
)

__all__ = [
    'TibyanV9Config',
    'ModelConfig',
    'TrainingConfig',
    'AttentionConfig',
    'SSMConfig',
    'MoEConfig',
    'MemoryConfig',
    'HybridLayerConfig',
    'GRPOConfig',
    'DistillationConfig',
    'QuantizationConfig',
    'MobileTrainingConfig',
    'DecodingConfig',
    'TestTimeComputeConfig',
    'SpeculativeDecodingConfig',
    'HallucinationDetectionConfig',
    'SteeringConfig',
    'VerificationConfig',
]
