#!/usr/bin/env python3
"""
================================================================================
TIBYAN v9.0 AGI Micro-Engine - Main Entry Point
================================================================================

Run TIBYAN v9.0 from command line:

    python -m tibyan_v9 [command] [options]

Commands:
    generate    Generate text from prompt
    chat        Interactive chat mode
    server      Start API server
    demo        Run demonstration
    info        Show system information

Examples:
    python -m tibyan_v9 generate "مرحبا بك"
    python -m tibyan_v9 chat
    python -m tibyan_v9 server --port 8000
    python -m tibyan_v9 demo

================================================================================
"""

import sys
import argparse
import logging
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def print_banner():
    """Print TIBYAN banner"""
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║    ████████╗██╗   ██╗██╗    ████████╗███████╗██╗   ██╗                      ║
║    ╚══██╔══╝██║   ██║██║    ╚══██╔══╝██╔════╝██║   ██║                      ║
║       ██║   ████████║██║       ██║   █████╗  ████████║                      ║
║       ██║   ██╔══██║██║       ██║   ██╔══╝  ╚════██║                      ║
║       ██║   ██║  ██║██║       ██║   ███████╗     ██║                      ║
║       ╚═╝   ╚═╝  ╚═╝╚═╝       ╚═╝   ╚══════╝     ╚═╝                      ║
║                                                                              ║
║              ███████╗ █████╗ ██████╗ ██╗                                     ║
║              ██╔════╝██╔══██╗██╔══██╗██║                                     ║
║              █████╗  ███████║██████╔╝██║                                     ║
║              ██╔══╝  ██╔══██║██╔══██╗██║                                     ║
║              ██║     ██║  ██║██║  ██║███████╗                                ║
║              ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝                                ║
║                                                                              ║
║                      v9.0 AGI Micro-Engine                                  ║
║                   The Ultimate Arabic LLM                                   ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    print(banner)


def cmd_generate(args):
    """Generate text from prompt"""
    print_banner()
    
    from .api import TibyanAPI, GenerationConfig
    
    print(f"\n📝 Prompt: {args.prompt}")
    print(f"🎯 Max tokens: {args.max_tokens}")
    print(f"🌡️ Temperature: {args.temperature}")
    print(f"🎨 Preset: {args.preset or 'default'}")
    print("\n⏳ Generating...\n")
    
    api = TibyanAPI()
    
    config = GenerationConfig(
        max_new_tokens=args.max_tokens,
        temperature=args.temperature
    )
    
    result = api.generate(args.prompt, config, preset=args.preset)
    
    print("=" * 60)
    print("📝 Generated Text:")
    print("=" * 60)
    print(result.text)
    print("=" * 60)
    print(f"\n📊 Statistics:")
    print(f"   • Tokens: {result.num_tokens}")
    print(f"   • Time: {result.generation_time:.2f}s")
    print(f"   • Speed: {result.tokens_per_second:.1f} tokens/s")
    
    if result.is_hallucination is not None:
        status = "⚠️ Potential hallucination" if result.is_hallucination else "✅ Confident"
        print(f"   • Safety: {status}")


def cmd_chat(args):
    """Interactive chat mode"""
    print_banner()
    
    from .api import TibyanAPI, ChatSession, GenerationConfig
    
    print("\n💬 Interactive Chat Mode")
    print("   Type 'exit' or 'quit' to end the session")
    print("   Type 'clear' to clear conversation history")
    print("   Type 'stats' to show statistics\n")
    
    api = TibyanAPI()
    session = ChatSession(api)
    
    config = GenerationConfig(
        temperature=args.temperature,
        max_new_tokens=args.max_tokens
    )
    
    print("🤖 TIBYAN: مرحبا! كيف يمكنني مساعدتك؟\n")
    
    while True:
        try:
            user_input = input("👤 You: ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ['exit', 'quit']:
                print("\n👋 مع السلامة!")
                break
            
            if user_input.lower() == 'clear':
                session.clear()
                print("🧹 Conversation cleared.\n")
                continue
            
            if user_input.lower() == 'stats':
                stats = api.get_stats()
                print(f"\n📊 Statistics:")
                for key, value in stats.items():
                    print(f"   • {key}: {value}")
                print()
                continue
            
            # Generate response
            print("🤖 TIBYAN: ", end="", flush=True)
            
            response = session.send(user_input, config)
            print(response)
            print()
        
        except KeyboardInterrupt:
            print("\n\n👋 مع السلامة!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}\n")


def cmd_server(args):
    """Start API server"""
    print_banner()
    
    from .api.server import TibyanServer, ServerConfig
    
    config = ServerConfig(
        host=args.host,
        port=args.port,
        workers=args.workers
    )
    
    print(f"\n🌐 Starting TIBYAN API Server")
    print(f"   • Host: {config.host}")
    print(f"   • Port: {config.port}")
    print(f"   • Workers: {config.workers}")
    print(f"\n📚 API Endpoints:")
    print(f"   • http://{config.host}:{config.port}/")
    print(f"   • http://{config.host}:{config.port}/generate")
    print(f"   • http://{config.host}:{config.port}/chat")
    print(f"   • http://{config.host}:{config.port}/health")
    print(f"\n🔌 WebSocket: ws://{config.host}:{config.port}/ws")
    print()
    
    server = TibyanServer(config)
    server.start()


def cmd_demo(args):
    """Run demonstration"""
    print_banner()
    
    print("\n🎬 TIBYAN v9.0 Demonstration")
    print("=" * 60)
    
    from . import get_version_info, check_installation
    
    # Version info
    print("\n📦 Version Information:")
    info = get_version_info()
    for key, value in info.items():
        print(f"   • {key}: {value}")
    
    # Check installation
    print("\n🔍 Installation Check:")
    install = check_installation()
    print(f"   • All required packages: {'✅' if install['all_required_installed'] else '❌'}")
    
    for pkg, installed in install['required'].items():
        print(f"   • {pkg}: {'✅' if installed else '❌'}")
    
    print("\n📦 Optional Packages:")
    for pkg, installed in install['optional'].items():
        print(f"   • {pkg}: {'✅' if installed else '❌'}")
    
    # Quick generation demo
    print("\n🎯 Quick Generation Demo:")
    print("-" * 40)
    
    try:
        from .api import TibyanAPI
        
        api = TibyanAPI()
        
        demo_prompts = [
            "مرحبا بك",
            "ما هو الذكاء الاصطناعي؟",
            "Hello, how are you?",
        ]
        
        for prompt in demo_prompts:
            print(f"\n📝 Prompt: {prompt}")
            result = api.generate(prompt, max_new_tokens=50)
            print(f"🤖 Response: {result.text[:100]}...")
            print(f"   ⚡ {result.tokens_per_second:.1f} tokens/s")
    
    except Exception as e:
        print(f"   ⚠️ Demo generation skipped: {e}")
    
    print("\n" + "=" * 60)
    print("✅ Demonstration complete!")


def cmd_info(args):
    """Show system information"""
    print_banner()
    
    import torch
    
    print("\n💻 System Information:")
    print("-" * 40)
    
    print(f"\n🖥️ Hardware:")
    print(f"   • PyTorch version: {torch.__version__}")
    print(f"   • CUDA available: {'✅' if torch.cuda.is_available() else '❌'}")
    
    if torch.cuda.is_available():
        print(f"   • CUDA version: {torch.version.cuda}")
        print(f"   • GPU: {torch.cuda.get_device_name(0)}")
        print(f"   • GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    
    print(f"\n🐍 Python:")
    print(f"   • Version: {sys.version.split()[0]}")
    
    # Check TIBYAN info
    from . import get_version_info, check_installation
    
    print(f"\n📦 TIBYAN v9.0:")
    info = get_version_info()
    for key, value in info.items():
        print(f"   • {key}: {value}")
    
    # Installation check
    print(f"\n📚 Dependencies:")
    install = check_installation()
    
    all_ok = install['all_required_installed']
    print(f"   • Status: {'✅ Ready' if all_ok else '⚠️ Missing dependencies'}")
    
    missing = [pkg for pkg, ok in install['required'].items() if not ok]
    if missing:
        print(f"   • Missing: {', '.join(missing)}")
        print(f"   • Install with: pip install {' '.join(missing)}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="TIBYAN v9.0 AGI Micro-Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Generate command
    gen_parser = subparsers.add_parser('generate', help='Generate text from prompt')
    gen_parser.add_argument('prompt', help='Input prompt')
    gen_parser.add_argument('--max-tokens', type=int, default=512, help='Maximum tokens to generate')
    gen_parser.add_argument('--temperature', type=float, default=0.7, help='Sampling temperature')
    gen_parser.add_argument('--preset', choices=['creative', 'precise', 'balanced', 'reasoning', 'arabic'],
                           help='Generation preset')
    
    # Chat command
    chat_parser = subparsers.add_parser('chat', help='Interactive chat mode')
    chat_parser.add_argument('--max-tokens', type=int, default=512, help='Maximum tokens per response')
    chat_parser.add_argument('--temperature', type=float, default=0.7, help='Sampling temperature')
    
    # Server command
    server_parser = subparsers.add_parser('server', help='Start API server')
    server_parser.add_argument('--host', default='0.0.0.0', help='Server host')
    server_parser.add_argument('--port', type=int, default=8000, help='Server port')
    server_parser.add_argument('--workers', type=int, default=1, help='Number of workers')
    
    # Demo command
    subparsers.add_parser('demo', help='Run demonstration')
    
    # Info command
    subparsers.add_parser('info', help='Show system information')
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return
    
    # Execute command
    commands = {
        'generate': cmd_generate,
        'chat': cmd_chat,
        'server': cmd_server,
        'demo': cmd_demo,
        'info': cmd_info
    }
    
    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
